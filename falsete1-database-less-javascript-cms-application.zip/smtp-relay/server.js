// Servidor de envio (relay) SMTP do Pica-Pau CMS — Node.js puro, sem dependências.
// O navegador não consegue abrir conexões SMTP; o site envia o e-mail para este servidor,
// que o entrega ao seu provedor SMTP com as configurações feitas no painel.
//
// Uso:  RELAY_KEY=uma-chave-secreta ALLOWED_ORIGIN=https://seusite.com node smtp-relay/server.js
// Variáveis: PORT (padrão 3001), RELAY_KEY (recomendado), ALLOWED_ORIGIN (padrão *),
//            SMTP_INSECURE_TLS=1 (só para testes com certificado autoassinado)
import http from "node:http";
import { sendSmtp } from "./smtp.js";

const PORT = Number(process.env.PORT) || 3001;
const KEY = process.env.RELAY_KEY || "";
const ORIGIN = process.env.ALLOWED_ORIGIN || "*";
const INSECURE = process.env.SMTP_INSECURE_TLS === "1";
const hits = new Map(); // limite simples: 30 envios/minuto por IP

function send(res, status, obj) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": ORIGIN,
    "Access-Control-Allow-Headers": "Content-Type, X-Relay-Key",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  });
  res.end(obj === undefined ? "" : JSON.stringify(obj));
}

const isEmail = (s) => /^[^@\s<>]+@[^@\s<>]+\.[^@\s<>]+$/.test(String(s || ""));

const server = http.createServer((req, res) => {
  if (req.method === "OPTIONS") return send(res, 204);
  const url = new URL(req.url, "http://x");
  if (req.method === "GET" && url.pathname === "/health") return send(res, 200, { ok: true, service: "pica-pau-smtp-relay", keyRequired: !!KEY });
  if (req.method !== "POST" || url.pathname !== "/send") return send(res, 404, { ok: false, error: "Rota não encontrada" });

  if (KEY && req.headers["x-relay-key"] !== KEY) return send(res, 401, { ok: false, error: "Chave do servidor de envio inválida." });
  const ip = req.socket.remoteAddress || "?";
  const now = Date.now();
  const list = (hits.get(ip) || []).filter((t) => now - t < 60000);
  if (list.length >= 30) return send(res, 429, { ok: false, error: "Muitos envios. Aguarde um minuto." });
  hits.set(ip, [...list, now]);

  let body = "";
  req.on("data", (c) => {
    body += c;
    if (body.length > 1_000_000) req.destroy();
  });
  req.on("end", async () => {
    let payload;
    try {
      payload = JSON.parse(body || "{}");
    } catch {
      return send(res, 400, { ok: false, error: "JSON inválido." });
    }
    const { smtp = {}, message = {} } = payload;
    const to = (Array.isArray(message.to) ? message.to : [message.to]).filter(Boolean);
    if (!to.length || !to.every(isEmail)) return send(res, 400, { ok: false, error: "Destinatário inválido." });
    if (!isEmail(message.fromEmail)) return send(res, 400, { ok: false, error: "E-mail do remetente inválido." });
    try {
      const r = await sendSmtp(smtp, { ...message, to }, { insecureTls: INSECURE });
      console.log(`[relay] enviado para ${to.join(", ")} via ${smtp.host}:${smtp.port}`);
      send(res, 200, { ok: true, response: r.response });
    } catch (e) {
      console.error(`[relay] falha: ${e.message}`);
      send(res, 502, { ok: false, error: e.message });
    }
  });
});

server.listen(PORT, () => {
  console.log(`Pica-Pau SMTP relay ouvindo em http://localhost:${PORT} (chave ${KEY ? "exigida" : "NÃO configurada — defina RELAY_KEY"})`);
});
