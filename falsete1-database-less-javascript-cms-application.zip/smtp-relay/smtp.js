// Cliente SMTP mínimo em Node.js puro (sem dependências).
// Suporta: conexão direta (porta 25/2525), SSL/TLS implícito (465) e STARTTLS (587),
// AUTH PLAIN / AUTH LOGIN e mensagens multipart (texto + HTML) em UTF-8.
import net from "node:net";
import tls from "node:tls";
import os from "node:os";
import crypto from "node:crypto";

function connection(socket, timeoutMs) {
  let buf = "";
  let lines = [];
  const ready = [];
  const waiters = [];
  let failure = null;

  const onData = (chunk) => {
    buf += chunk.toString("utf8");
    let i;
    while ((i = buf.indexOf("\r\n")) >= 0) {
      const line = buf.slice(0, i);
      buf = buf.slice(i + 2);
      lines.push(line);
      if (/^\d{3}( |$)/.test(line)) {
        const resp = { code: Number(line.slice(0, 3)), text: lines.join("\n") };
        lines = [];
        const w = waiters.shift();
        w ? w.resolve(resp) : ready.push(resp);
      }
    }
  };
  const onError = (err) => {
    failure = err;
    while (waiters.length) waiters.shift().reject(err);
  };
  const attach = (s) => {
    s.on("data", onData);
    s.on("error", onError);
    s.setTimeout(timeoutMs, () => onError(new Error("Tempo esgotado na conexão SMTP")));
  };
  attach(socket);

  return {
    get socket() {
      return socket;
    },
    read() {
      if (failure) return Promise.reject(failure);
      if (ready.length) return Promise.resolve(ready.shift());
      return new Promise((resolve, reject) => waiters.push({ resolve, reject }));
    },
    write(line) {
      socket.write(line + "\r\n");
    },
    upgrade(newSocket) {
      socket.removeListener("data", onData);
      socket.removeListener("error", onError);
      socket = newSocket;
      attach(socket);
    },
  };
}

async function expect(conn, codes, what) {
  const r = await conn.read();
  if (!codes.includes(r.code)) throw new Error(`${what}: servidor respondeu ${r.text}`);
  return r;
}

const b64 = (s) => Buffer.from(s, "utf8").toString("base64");
const encWord = (s) => (/^[\x20-\x7e]*$/.test(s) ? s : `=?UTF-8?B?${b64(s)}?=`);
const wrap76 = (s) => s.replace(/.{1,76}/g, "$&\r\n").trim();

export function buildMessage({ fromName, fromEmail, to, replyTo, subject, text, html }) {
  const boundary = "pp-" + crypto.randomBytes(8).toString("hex");
  const domain = (fromEmail.split("@")[1] || "localhost").trim();
  const headers = [
    `From: ${fromName ? `"${encWord(fromName).replace(/"/g, "")}" ` : ""}<${fromEmail}>`,
    `To: ${to.join(", ")}`,
    replyTo ? `Reply-To: ${replyTo}` : null,
    `Subject: ${encWord(subject || "(sem assunto)")}`,
    `Date: ${new Date().toUTCString()}`,
    `Message-ID: <${crypto.randomUUID()}@${domain}>`,
    "MIME-Version: 1.0",
    `Content-Type: multipart/alternative; boundary="${boundary}"`,
  ].filter(Boolean);
  const plain = text || String(html || "").replace(/<br\s*\/?>/gi, "\n").replace(/<[^>]+>/g, "").trim();
  const parts = [
    `--${boundary}`,
    "Content-Type: text/plain; charset=UTF-8",
    "Content-Transfer-Encoding: base64",
    "",
    wrap76(b64(plain)),
  ];
  if (html) parts.push(`--${boundary}`, "Content-Type: text/html; charset=UTF-8", "Content-Transfer-Encoding: base64", "", wrap76(b64(html)));
  parts.push(`--${boundary}--`);
  return headers.join("\r\n") + "\r\n\r\n" + parts.join("\r\n");
}

/**
 * Envia um e-mail.
 * smtp: { host, port, security: "starttls" | "ssl" | "none", user, pass }
 * message: { fromName, fromEmail, to: [..], replyTo, subject, text, html }
 */
export async function sendSmtp(smtp, message, { timeoutMs = 20000, insecureTls = false } = {}) {
  const host = String(smtp.host || "").trim();
  const port = Number(smtp.port) || (smtp.security === "ssl" ? 465 : 587);
  if (!host) throw new Error("Servidor SMTP não informado.");
  if (!message.fromEmail) throw new Error("E-mail do remetente não informado.");
  if (!message.to?.length) throw new Error("Destinatário não informado.");
  const tlsOpts = { servername: host, rejectUnauthorized: !insecureTls };

  const socket = await new Promise((resolve, reject) => {
    const s = smtp.security === "ssl" ? tls.connect({ host, port, ...tlsOpts }) : net.connect({ host, port });
    s.once(smtp.security === "ssl" ? "secureConnect" : "connect", () => resolve(s));
    s.once("error", reject);
  });
  const conn = connection(socket, timeoutMs);
  const me = os.hostname() || "localhost";
  try {
    await expect(conn, [220], "Saudação");
    conn.write(`EHLO ${me}`);
    let ehlo = await expect(conn, [250], "EHLO");

    if (smtp.security === "starttls") {
      if (!/STARTTLS/i.test(ehlo.text)) throw new Error("O servidor não oferece STARTTLS (tente SSL/TLS na porta 465).");
      conn.write("STARTTLS");
      await expect(conn, [220], "STARTTLS");
      const secure = await new Promise((resolve, reject) => {
        const t = tls.connect({ socket: conn.socket, ...tlsOpts }, () => resolve(t));
        t.once("error", reject);
      });
      conn.upgrade(secure);
      conn.write(`EHLO ${me}`);
      ehlo = await expect(conn, [250], "EHLO (após STARTTLS)");
    }

    if (smtp.user) {
      if (/AUTH[ =-][^\n]*PLAIN/i.test(ehlo.text)) {
        conn.write("AUTH PLAIN " + Buffer.from(`\u0000${smtp.user}\u0000${smtp.pass || ""}`, "utf8").toString("base64"));
        await expect(conn, [235], "Autenticação (PLAIN) — verifique usuário e senha");
      } else {
        conn.write("AUTH LOGIN");
        await expect(conn, [334], "AUTH LOGIN");
        conn.write(b64(smtp.user));
        await expect(conn, [334], "AUTH LOGIN (usuário)");
        conn.write(b64(smtp.pass || ""));
        await expect(conn, [235], "Autenticação (LOGIN) — verifique usuário e senha");
      }
    }

    conn.write(`MAIL FROM:<${message.fromEmail}>`);
    await expect(conn, [250], "MAIL FROM");
    for (const rcpt of message.to) {
      conn.write(`RCPT TO:<${rcpt}>`);
      await expect(conn, [250, 251], `Destinatário ${rcpt}`);
    }
    conn.write("DATA");
    await expect(conn, [354], "DATA");
    const data = buildMessage(message).replace(/\r\n\./g, "\r\n.."); // dot-stuffing
    conn.socket.write(data + "\r\n.\r\n");
    const done = await expect(conn, [250], "Envio da mensagem");
    conn.write("QUIT");
    return { ok: true, response: done.text };
  } finally {
    setTimeout(() => conn.socket.destroy(), 200);
  }
}
