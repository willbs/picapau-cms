// Liga a conta de login (usuário do site) ao seu perfil público (página de usuário em /forum/u/:usuario).
// Se o usuário ainda não tem perfil, ele é criado na primeira vez em que acessa "Meu perfil".
import { loadState, updateState } from "./store.js";
import { navigate } from "./router.js";
import { uid, slugify } from "./utils.js";

const ME_KEY = "picapau_forum_me_v1"; // mesma chave do "Participar como" do fórum

/** Retorna (criando se necessário) o perfil público do usuário logado. */
export function ensureUserProfile(user) {
  const st = loadState();
  const existing = (st.forum?.profiles || []).find((p) => p.userId === user.id);
  if (existing) return existing;
  const local = user.email.split("@")[0];
  const base = slugify(local).replace(/-/g, "") || "usuario";
  let username = base;
  let n = 1;
  while ((st.forum?.profiles || []).some((p) => p.username === username)) username = `${base}${++n}`;
  const profile = {
    id: uid(),
    userId: user.id,
    username,
    name: local.charAt(0).toUpperCase() + local.slice(1),
    bio: "",
    avatar: "",
    cover: "",
    template: "classico",
    following: [],
    videos: [],
    wishlist: [],
    createdAt: new Date().toISOString(),
  };
  updateState((s) => { s.forum.profiles.push(profile); });
  return profile;
}

/** Abre a página do usuário logado (e o define como sua identidade no fórum). */
export function goToMyProfile(user) {
  const p = ensureUserProfile(user);
  localStorage.setItem(ME_KEY, p.id);
  window.dispatchEvent(new Event("cms:changed"));
  navigate(`/forum/u/${p.username}`);
}
