// Utilitários gerais em JavaScript puro (ES6+)
import { getLocale } from "./i18n.js";

/** Gera um identificador único. */
export function uid() {
  if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID();
  return "id-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 10);
}

/** Converte um texto em slug amigável para URL. */
export function slugify(text) {
  return String(text || "")
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

/** Formata uma data ISO para pt-BR. */
export function formatDate(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return d.toLocaleDateString(getLocale(), {
    day: "2-digit",
    month: "long",
    year: "numeric",
  });
}

/** Data/hora atual em ISO (input datetime-local usa formato local). */
export function nowLocalInput() {
  const d = new Date();
  d.setSeconds(0, 0);
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

/** Converte URL do YouTube/Vimeo em URL de embed. Retorna null se for arquivo direto. */
export function videoEmbedUrl(url) {
  if (!url) return null;
  const yt = url.match(
    /(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([A-Za-z0-9_-]{6,})/
  );
  if (yt) return `https://www.youtube.com/embed/${yt[1]}`;
  const vimeo = url.match(/vimeo\.com\/(?:video\/)?(\d+)/);
  if (vimeo) return `https://player.vimeo.com/video/${vimeo[1]}`;
  return null;
}

/** Verdadeiro se a URL é um arquivo de vídeo direto (mp4, webm, etc.). */
export function isDirectVideo(url) {
  return !!url && /\.(mp4|webm|ogg|ogv|mov|m4v)(\?.*)?$/i.test(url);
}

/** Concatena classes CSS (substitui o antigo cn.ts). */
export function cn(...args) {
  return args.filter(Boolean).join(" ");
}

/** Estima o tempo de leitura a partir do HTML. */
export function readingTime(html) {
  const text = String(html || "").replace(/<[^>]*>/g, " ");
  const words = text.trim().split(/\s+/).filter(Boolean).length;
  const mins = Math.max(1, Math.round(words / 200));
  return `${mins} min de leitura`;
}

/** Faz download de um arquivo de texto no navegador. */
export function download(filename, text, type = "text/plain") {
  const blob = new Blob([text], { type: type + ";charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/** Extrai um resumo do HTML (texto puro). */
export function excerptFromHtml(html, max = 160) {
  const text = String(html || "").replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
  if (text.length <= max) return text;
  return text.slice(0, max).replace(/\s+\S*$/, "") + "…";
}

/** Injeta uma figura de imagem logo após o primeiro parágrafo do HTML. */
export function injectAfterFirstParagraph(html, figureHtml) {
  const i = String(html || "").indexOf("</p>");
  if (i === -1) return (html || "") + figureHtml;
  return html.slice(0, i + 4) + figureHtml + html.slice(i + 4);
}

/** Rótulos amigáveis para os tipos de artigo. */
export const TYPE_LABELS = {
  image: "Imagem",
  video: "Vídeo",
  audio: "Áudio",
};

export const TYPE_ICONS = {
  image: "🖼️",
  video: "🎬",
  audio: "🎧",
};

export const STATUS_LABELS = {
  rascunho: "Rascunho",
  publicado: "Publicado",
  agendado: "Agendado",
};
