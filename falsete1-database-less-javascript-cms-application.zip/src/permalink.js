// Estrutura de URLs (permalinks) dos artigos — configurada em Painel → SEO.
// Opções: "titulo" (padrão: /slug-do-artigo), "categoria" (/categoria/slug) e
// "categoria-subcategoria" (/categoria/subcategoria/slug), com prefixo opcional (ex.: /blog/...).
// A antiga base "/artigo/" deixou de ser padrão; URLs antigas são redirecionadas.
import { loadState } from "./store.js";
import { slugify } from "./utils.js";

export const PERMALINK_OPTIONS = [
  { id: "titulo", name: "Somente o título", example: "/titulo-do-artigo", desc: "URL curta, apenas o slug do artigo (padrão)." },
  { id: "categoria", name: "Categoria / título", example: "/tecnologia/titulo-do-artigo", desc: "Inclui a categoria principal do artigo." },
  { id: "categoria-subcategoria", name: "Categoria / subcategoria / título", example: "/tecnologia/ia/titulo-do-artigo", desc: "Usa a categoria-mãe e a subcategoria (ou a 2ª categoria marcada)." },
];

/** Prefixos proibidos (colidem com rotas do sistema). */
export const RESERVED_BASES = ["categoria", "admin", "login", "pica-pau", "forum", "loja", "podcasts", "feed", "inicio"];

export function getPermalink(state) {
  const pl = (state || loadState()).seo?.permalink || {};
  return {
    structure: PERMALINK_OPTIONS.some((o) => o.id === pl.structure) ? pl.structure : "titulo",
    base: (pl.base || "").split("/").map(slugify).filter(Boolean).join("/"),
  };
}

/** Segmentos de categoria conforme a estrutura escolhida. */
function categorySegments(article, state, structure) {
  const cats = (article.categories || [])
    .map((s) => (state.categories || []).find((c) => c.slug === s))
    .filter(Boolean);
  const primary = cats[0];
  if (!primary || structure === "titulo") return [];
  if (structure === "categoria") return [primary.slug];
  // categoria/subcategoria
  const parent = primary.parent ? state.categories.find((c) => c.slug === primary.parent) : null;
  if (parent) return [parent.slug, primary.slug];
  return cats[1] ? [primary.slug, cats[1].slug] : [primary.slug];
}

/**
 * Caminho público de um artigo (aceita o objeto do artigo ou só o slug).
 * Ex.: "/titulo", "/tecnologia/titulo", "/blog/tecnologia/ia/titulo".
 */
export function articlePath(articleOrSlug, stateArg) {
  const state = stateArg || loadState();
  let a = articleOrSlug;
  if (typeof a === "string") {
    a = (state.articles || []).find((x) => x.slug === a) || { slug: a, categories: [] };
  }
  if (!a || !a.slug) return "/";
  const { structure, base } = getPermalink(state);
  const segs = [];
  if (base) segs.push(...base.split("/"));
  segs.push(...categorySegments(a, state, structure), a.slug);
  return "/" + segs.join("/");
}

/**
 * Resolve uma rota para um artigo publicado.
 * Retorna { article, canonical } — se canonical !== route, a rota é antiga/alternativa
 * (ex.: /artigo/slug) e deve ser redirecionada para a URL canônica.
 */
export function resolveArticle(route, state) {
  const segs = route.split("/").filter(Boolean);
  if (!segs.length) return null;
  const slug = decodeURIComponent(segs[segs.length - 1]);
  const article = (state.articles || []).find((a) => a.slug === slug && a.status === "publicado");
  if (!article) return null;
  const canonical = articlePath(article, state);
  if (canonical === route) return { article, canonical };
  // aceita URLs antigas (/artigo/slug) ou de outra estrutura e redireciona
  return { article, canonical, redirect: true };
}
