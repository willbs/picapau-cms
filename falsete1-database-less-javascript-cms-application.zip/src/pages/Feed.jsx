// Página Feed (/feed/imagens, /feed/videos, /feed/audios): reúne as imagens, os vídeos e os áudios
// que os usuários adicionaram aos seus perfis. Para cada tipo, o leitor escolhe entre 3 layouts.
import { useRef, useState } from "react";
import PublicLayout from "../components/Layout.jsx";
import VideoEmbed, { VIDEO_PLATFORMS } from "../components/VideoEmbed.jsx";
import { navigate } from "../router.js";
import { cn, formatDate } from "../utils.js";
import { StoredImage, StoredAudio } from "./ProfileMedia.jsx";
import { useMediaUrl, formatMB } from "../mediaStore.js";

const LAYOUT_KEY = "picapau_feed_layout_v1";

export const FEED_TABS = [
  { id: "imagens", label: "Imagens", icon: "🖼️" },
  { id: "videos", label: "Vídeos", icon: "🎬" },
  { id: "audios", label: "Áudios", icon: "🎧" },
];

export const FEED_LAYOUTS = {
  imagens: [
    { id: "grade", label: "Grade", icon: "▦" },
    { id: "mosaico", label: "Mosaico", icon: "▥" },
    { id: "galeria", label: "Galeria", icon: "▭" },
  ],
  videos: [
    { id: "grade", label: "Grade", icon: "▦" },
    { id: "lista", label: "Lista", icon: "☰" },
    { id: "cinema", label: "Cinema", icon: "🎞️" },
  ],
  audios: [
    { id: "lista", label: "Lista", icon: "☰" },
    { id: "cartoes", label: "Cartões", icon: "▦" },
    { id: "playlist", label: "Playlist", icon: "🎶" },
  ],
};

function getLayouts() {
  try {
    return { imagens: "grade", videos: "grade", audios: "lista", ...(JSON.parse(localStorage.getItem(LAYOUT_KEY)) || {}) };
  } catch {
    return { imagens: "grade", videos: "grade", audios: "lista" };
  }
}

/** Junta as mídias de todos os perfis, mais recentes primeiro. */
function collect(state, key) {
  const out = [];
  (state.forum?.profiles || []).forEach((p) => (p[key] || []).forEach((m) => out.push({ ...m, author: p })));
  return out.sort((a, b) => String(b.createdAt || "").localeCompare(String(a.createdAt || "")));
}

function Author({ p, light }) {
  return (
    <a href={`/forum/u/${p.username}`} onClick={(e) => { e.preventDefault(); navigate(`/forum/u/${p.username}`); }}
      className={cn("inline-flex items-center gap-1.5 text-xs font-semibold hover:underline", light ? "text-white" : "text-indigo-600 dark:text-indigo-300")}>
      {p.avatar ? <img src={p.avatar} alt="" className="h-5 w-5 rounded-full object-cover" /> : <span aria-hidden="true">👤</span>}
      {p.name}
    </a>
  );
}

function Empty({ text }) {
  return <p className="rounded-2xl border border-dashed border-slate-300 bg-white p-12 text-center text-sm text-slate-400 dark:border-slate-700 dark:bg-slate-900">{text}</p>;
}

/* ---------------------------- Imagens ---------------------------- */

function Images({ items, layout }) {
  const [open, setOpen] = useState(null);
  if (!items.length) return <Empty text="Nenhuma imagem publicada pelos usuários ainda." />;
  const card = (it, cls, imgCls) => (
    <figure key={it.id} className={cn("group overflow-hidden rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900", cls)} data-feed-item>
      <button type="button" onClick={() => setOpen(it)} className="block w-full" aria-label={`Ampliar ${it.title}`}>
        <StoredImage item={it} className={cn("w-full transition-transform duration-300 group-hover:scale-[1.02]", imgCls)} />
      </button>
      <figcaption className="flex items-center justify-between gap-2 px-3 py-2">
        <span className="truncate text-sm font-semibold text-slate-800 dark:text-slate-100">{it.title}</span>
        <Author p={it.author} />
      </figcaption>
    </figure>
  );
  return (
    <>
      {layout === "mosaico" ? (
        <div className="columns-2 gap-4 md:columns-3 lg:columns-4 [&>figure]:mb-4 [&>figure]:break-inside-avoid">{items.map((it) => card(it, "", "h-auto"))}</div>
      ) : layout === "galeria" ? (
        <div className="mx-auto max-w-3xl space-y-8">{items.map((it) => card(it, "", "max-h-[70vh] object-contain bg-black"))}</div>
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">{items.map((it) => card(it, "", "aspect-square object-cover"))}</div>
      )}
      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4" role="dialog" aria-modal="true" aria-label={open.title} onClick={() => setOpen(null)}>
          <figure onClick={(e) => e.stopPropagation()} className="max-w-5xl">
            <StoredImage item={open} className="max-h-[80vh] w-auto rounded-xl object-contain" />
            <figcaption className="mt-2 flex items-center justify-center gap-3 text-sm text-white">{open.title} · <Author p={open.author} light /></figcaption>
          </figure>
          <button type="button" onClick={() => setOpen(null)} className="absolute right-4 top-4 text-2xl text-white" aria-label="Fechar">✕</button>
        </div>
      )}
    </>
  );
}

/* ---------------------------- Vídeos ---------------------------- */

const platformOf = (v) => VIDEO_PLATFORMS.find((p) => p.id === v.platform);

function Videos({ items, layout }) {
  const [cur, setCur] = useState(0);
  if (!items.length) return <Empty text="Nenhum vídeo publicado pelos usuários ainda." />;
  const info = (v) => (
    <div className="flex flex-wrap items-center gap-2 px-3 py-2">
      <span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs font-semibold text-slate-600 dark:bg-slate-800 dark:text-slate-300">{platformOf(v)?.icon} {platformOf(v)?.label}</span>
      <span className="min-w-0 flex-1 truncate text-sm font-semibold text-slate-800 dark:text-slate-100">{v.title}</span>
      <Author p={v.author} />
    </div>
  );
  if (layout === "cinema") {
    const v = items[Math.min(cur, items.length - 1)];
    return (
      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_320px]" data-feed-cinema>
        <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900" data-feed-item>
          <VideoEmbed key={v.id} url={v.url} platform={v.platform} title={v.title} className="rounded-none" />
          {info(v)}
        </div>
        <ol className="max-h-[70vh] space-y-2 overflow-y-auto" aria-label="Próximos vídeos">
          {items.map((x, i) => (
            <li key={x.id}>
              <button type="button" onClick={() => setCur(i)} aria-current={i === cur}
                className={cn("flex w-full items-center gap-3 rounded-xl border p-3 text-left text-sm", i === cur ? "border-indigo-500 bg-indigo-50 dark:bg-indigo-500/10" : "border-slate-200 bg-white hover:border-slate-400 dark:border-slate-800 dark:bg-slate-900")}>
                <span className="text-lg" aria-hidden="true">{i === cur ? "▶" : platformOf(x)?.icon}</span>
                <span className="min-w-0 flex-1 truncate font-semibold text-slate-800 dark:text-slate-100">{x.title}</span>
              </button>
            </li>
          ))}
        </ol>
      </div>
    );
  }
  if (layout === "lista") {
    return (
      <div className="mx-auto max-w-4xl space-y-5">
        {items.map((v) => (
          <article key={v.id} className="grid overflow-hidden rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 md:grid-cols-[360px_1fr]" data-feed-item>
            <VideoEmbed url={v.url} platform={v.platform} title={v.title} className="rounded-none" />
            <div className="flex flex-col justify-center gap-2 p-4">
              <span className="text-xs font-semibold text-slate-500">{platformOf(v)?.icon} {platformOf(v)?.label}</span>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">{v.title}</h3>
              <Author p={v.author} />
            </div>
          </article>
        ))}
      </div>
    );
  }
  return (
    <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
      {items.map((v) => (
        <article key={v.id} className="overflow-hidden rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900" data-feed-item>
          <VideoEmbed url={v.url} platform={v.platform} title={v.title} className="rounded-none" />
          {info(v)}
        </article>
      ))}
    </div>
  );
}

/* ---------------------------- Áudios ---------------------------- */

function PlaylistPlayer({ items }) {
  const [cur, setCur] = useState(0);
  const ref = useRef(null);
  const it = items[Math.min(cur, items.length - 1)];
  const url = useMediaUrl(it.mediaId);
  return (
    <div className="mx-auto max-w-3xl overflow-hidden rounded-3xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900" data-feed-playlist>
      <div className="bg-gradient-to-br from-emerald-500 to-teal-600 p-6 text-white">
        <p className="text-xs font-bold uppercase tracking-widest opacity-80">Tocando agora</p>
        <p className="mt-1 text-2xl font-extrabold" data-now-playing>{it.title}</p>
        <div className="mt-1"><Author p={it.author} light /></div>
        {url && <audio ref={ref} key={url} controls src={url} className="mt-4 w-full" onEnded={() => setCur((c) => (c + 1) % items.length)} />}
      </div>
      <ol className="divide-y divide-slate-100 dark:divide-slate-800">
        {items.map((x, i) => (
          <li key={x.id}>
            <button type="button" onClick={() => setCur(i)} aria-current={i === cur} data-track
              className={cn("flex w-full items-center gap-3 px-5 py-3 text-left text-sm", i === cur ? "bg-emerald-50 font-bold text-emerald-800 dark:bg-emerald-500/10 dark:text-emerald-300" : "text-slate-700 hover:bg-slate-50 dark:text-slate-200 dark:hover:bg-slate-800")}>
              <span className="w-6 text-center text-xs text-slate-400">{i === cur ? "▶" : i + 1}</span>
              <span className="min-w-0 flex-1 truncate">{x.title}</span>
              <span className="text-xs text-slate-400">{x.author.name}</span>
            </button>
          </li>
        ))}
      </ol>
    </div>
  );
}

function Audios({ items, layout }) {
  if (!items.length) return <Empty text="Nenhum áudio publicado pelos usuários ainda." />;
  if (layout === "playlist") return <PlaylistPlayer items={items} />;
  if (layout === "cartoes") {
    return (
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((it) => (
          <article key={it.id} className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900" data-feed-item>
            <div className="flex h-28 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-400 to-teal-600 text-5xl" aria-hidden="true">🎵</div>
            <h3 className="mt-3 truncate font-bold text-slate-900 dark:text-white">{it.title}</h3>
            <div className="mt-1 flex items-center justify-between"><Author p={it.author} /><span className="text-xs text-slate-400">{formatMB(it.size)}</span></div>
            <StoredAudio item={it} className="mt-3 w-full" />
          </article>
        ))}
      </div>
    );
  }
  return (
    <ul className="mx-auto max-w-4xl space-y-3">
      {items.map((it) => (
        <li key={it.id} className="flex flex-wrap items-center gap-3 rounded-2xl border border-slate-200 bg-white p-3 dark:border-slate-800 dark:bg-slate-900" data-feed-item>
          <span className="text-xl" aria-hidden="true">🎵</span>
          <div className="min-w-0 flex-1 basis-56">
            <p className="truncate text-sm font-bold text-slate-900 dark:text-white">{it.title}</p>
            <p className="text-xs text-slate-400"><Author p={it.author} /> · {formatDate(it.createdAt)}</p>
          </div>
          <StoredAudio item={it} className="w-full sm:w-80" />
        </li>
      ))}
    </ul>
  );
}

/* ---------------------------- Página ---------------------------- */

export default function Feed({ state, tab = "imagens" }) {
  const [layouts, setLayouts] = useState(getLayouts);
  const active = FEED_TABS.some((t) => t.id === tab) ? tab : "imagens";
  const data = {
    imagens: collect(state, "images"),
    videos: collect(state, "videos"),
    audios: collect(state, "audios"),
  };
  const layout = layouts[active];
  const choose = (id) => {
    const next = { ...layouts, [active]: id };
    setLayouts(next);
    localStorage.setItem(LAYOUT_KEY, JSON.stringify(next));
  };

  return (
    <PublicLayout state={state}>
      <section className="relative overflow-hidden bg-slate-950 text-white">
        <div className="pointer-events-none absolute inset-0 opacity-40"
          style={{ background: "radial-gradient(60% 80% at 20% 10%, rgba(99,102,241,.3), transparent 60%), radial-gradient(50% 70% at 85% 20%, rgba(16,185,129,.22), transparent 60%)" }} aria-hidden="true" />
        <div className="relative mx-auto max-w-7xl px-4 py-12">
          <p className="text-xs font-bold uppercase tracking-[0.25em] text-indigo-300">📡 Feed</p>
          <h1 className="mt-2 text-4xl font-extrabold tracking-tight">Feed da comunidade</h1>
          <p className="mt-2 max-w-xl text-slate-300">Imagens, vídeos e áudios publicados pelos usuários do site.</p>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 py-8">
        <div className="mb-6 flex flex-wrap items-center gap-3">
          <nav className="flex flex-wrap gap-2" aria-label="Feed">
            {FEED_TABS.map((t) => (
              <a key={t.id} href={`/feed/${t.id}`} onClick={(e) => { e.preventDefault(); navigate(`/feed/${t.id}`); }}
                aria-current={active === t.id ? "page" : undefined} data-feed-tab={t.id}
                className={cn("rounded-full px-4 py-2 text-sm font-bold transition", active === t.id ? "bg-indigo-600 text-white" : "border border-slate-300 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800")}>
                {t.icon} {t.label} <span className="opacity-70">({data[t.id].length})</span>
              </a>
            ))}
          </nav>
          <div className="ml-auto flex items-center gap-1 rounded-xl border border-slate-200 bg-white p-1 dark:border-slate-800 dark:bg-slate-900" role="radiogroup" aria-label="Layout de exibição">
            <span className="px-2 text-xs font-semibold text-slate-500">Layout</span>
            {FEED_LAYOUTS[active].map((l) => (
              <button key={l.id} type="button" role="radio" aria-checked={layout === l.id} onClick={() => choose(l.id)} data-layout-option={l.id}
                className={cn("rounded-lg px-3 py-1.5 text-xs font-semibold", layout === l.id ? "bg-amber-500 text-slate-950" : "text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800")}>
                {l.icon} {l.label}
              </button>
            ))}
          </div>
        </div>
        <div data-feed-type={active} data-feed-layout={layout}>
          {active === "imagens" && <Images items={data.imagens} layout={layout} />}
          {active === "videos" && <Videos items={data.videos} layout={layout} />}
          {active === "audios" && <Audios items={data.audios} layout={layout} />}
        </div>
      </div>
    </PublicLayout>
  );
}
