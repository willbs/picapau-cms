// Extras dos artigos públicos:
// - HtmlBlock: códigos HTML / textos alternativos do início e do final de cada artigo (Painel → HTML)
// - Comments: comentários dos leitores no final do artigo (com moderação opcional)
// - useViewCounter: contador de visualizações de cada artigo (LocalStorage)
import { useEffect, useRef, useState } from "react";
import { updateState } from "../store.js";
import { uid, formatDate } from "../utils.js";
import { articlePath } from "../permalink.js";
import { navigate } from "../router.js";
import { NETWORK_BY_ID } from "../data/socialNetworks.js";
import { SHARE_EXTRA_ICONS } from "../data/shareIcons.js";
import SocialLinks from "../components/SocialIcon.jsx";
import { getCurrentUser } from "../auth.js";

/** Escapa HTML (modo "texto"). */
function escapeHtml(s) {
  return String(s || "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

/** Variáveis disponíveis nos blocos: {{titulo}} {{autor}} {{data}} {{categoria}} {{url}} {{site}} */
export const HTML_VARIABLES = ["{{titulo}}", "{{autor}}", "{{data}}", "{{categoria}}", "{{url}}", "{{site}}"];

export function renderBlock(block, article, state) {
  if (!block || !block.enabled || !String(block.content || "").trim()) return "";
  const cat = (state.categories || []).find((c) => c.slug === (article.categories || [])[0]);
  const vars = {
    titulo: article.title || "",
    autor: article.author || "",
    data: formatDate(article.date),
    categoria: cat?.name || "",
    url: (typeof location !== "undefined" ? location.origin : "") + articlePath(article, state),
    site: state.branding?.siteName || state.seo?.title || "",
  };
  const isText = block.mode === "texto";
  let out = isText ? escapeHtml(block.content).replace(/\n/g, "<br />") : block.content;
  out = out.replace(/\{\{\s*(titulo|autor|data|categoria|url|site)\s*\}\}/g, (_, k) => (isText ? vars[k] : escapeHtml(vars[k])));
  return out;
}

/** Bloco de HTML/texto no início ou no final do artigo. */
export function HtmlBlock({ position, article, state }) {
  const html = renderBlock(state.html?.[position], article, state);
  if (!html) return null;
  return (
    <div
      className="article-html-block my-6 rounded-xl"
      data-html-block={position}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
}

/** Conta uma visualização por acesso à página do artigo e retorna o total. */
export function useViewCounter(article, state) {
  const counted = useRef("");
  const [fresh, setFresh] = useState(null); // valor recém-incrementado (independe da ordem dos efeitos)
  useEffect(() => {
    if (!article || counted.current === article.id) return;
    counted.current = article.id;
    const next = updateState((s) => {
      s.views = s.views || {};
      s.views[article.id] = (s.views[article.id] || 0) + 1;
    });
    setFresh({ id: article.id, n: next.views[article.id] });
  }, [article?.id]);
  if (!article) return 0;
  const stored = state.views?.[article.id] || 0;
  return fresh && fresh.id === article.id ? Math.max(fresh.n, stored) : stored;
}

/** Comentários dos leitores no final do artigo. */
export function Comments({ article, state }) {
  const cfg = state.html?.comments || { enabled: true, requireApproval: true };
  const logged = getCurrentUser();
  const [name, setName] = useState(() => (logged ? logged.email.split("@")[0] : ""));
  const [email, setEmail] = useState(() => (logged ? logged.email : ""));
  const [body, setBody] = useState("");
  const [trap, setTrap] = useState(""); // honeypot anti-spam
  const [msg, setMsg] = useState(null);
  if (cfg.enabled === false) return null;

  const list = (state.comments || [])
    .filter((c) => c.articleId === article.id && c.status === "aprovado")
    .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));

  const submit = (e) => {
    e.preventDefault();
    setMsg(null);
    if (trap) return; // bot
    if (!name.trim()) return setMsg({ type: "err", text: "Informe seu nome." });
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email.trim())) return setMsg({ type: "err", text: "Informe um e-mail válido." });
    if (body.trim().length < 2) return setMsg({ type: "err", text: "Escreva seu comentário." });
    const status = cfg.requireApproval !== false ? "pendente" : "aprovado";
    updateState((s) => {
      s.comments = s.comments || [];
      s.comments.push({
        id: uid(),
        articleId: article.id,
        name: name.trim().slice(0, 60),
        email: email.trim().toLowerCase().slice(0, 120), // não é exibido publicamente
        body: body.trim().slice(0, 2000),
        createdAt: new Date().toISOString(),
        status,
      });
    });
    setBody("");
    setMsg({
      type: "ok",
      text: status === "pendente" ? "Comentário enviado! Ele aparecerá após aprovação da moderação." : "Comentário publicado. Obrigado!",
    });
  };

  const inputCls =
    "w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 placeholder-slate-400 focus:border-amber-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white";

  return (
    <section className="mt-12 border-t border-slate-200 pt-8 dark:border-slate-800" aria-labelledby="comentarios-titulo" data-comments>
      <h2 id="comentarios-titulo" className="text-xl font-bold text-slate-900 dark:text-white">
        💬 Comentários ({list.length})
      </h2>
      <ul className="mt-4 space-y-3">
        {list.map((c) => (
          <li key={c.id} className="flex gap-3 rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-amber-100 text-sm font-bold text-amber-700 dark:bg-amber-500/15 dark:text-amber-300" aria-hidden="true">
              {c.name[0]?.toUpperCase()}
            </span>
            <div className="min-w-0">
              <p className="text-xs text-slate-400"><strong className="text-slate-600 dark:text-slate-300">{c.name}</strong> · {formatDate(c.createdAt)}</p>
              <p className="mt-1 whitespace-pre-wrap text-sm leading-relaxed text-slate-700 dark:text-slate-300">{c.body}</p>
            </div>
          </li>
        ))}
        {list.length === 0 && <li className="text-sm text-slate-400">Seja o primeiro a comentar.</li>}
      </ul>

      <form onSubmit={submit} className="mt-6 space-y-3 rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100">Deixe seu comentário</h3>
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <label htmlFor={`c-name-${article.id}`} className="mb-1 block text-xs font-semibold text-slate-500 dark:text-slate-400">Nome *</label>
            <input id={`c-name-${article.id}`} className={inputCls} placeholder="Seu nome" value={name} onChange={(e) => setName(e.target.value)} aria-label="Seu nome" maxLength={60} required autoComplete="name" />
          </div>
          <div>
            <label htmlFor={`c-email-${article.id}`} className="mb-1 block text-xs font-semibold text-slate-500 dark:text-slate-400">E-mail * <span className="font-normal">(não será publicado)</span></label>
            <input id={`c-email-${article.id}`} type="email" className={inputCls} placeholder="voce@exemplo.com" value={email} onChange={(e) => setEmail(e.target.value)} aria-label="Seu e-mail" maxLength={120} required autoComplete="email" />
          </div>
        </div>
        <label htmlFor={`c-body-${article.id}`} className="-mb-2 block text-xs font-semibold text-slate-500 dark:text-slate-400">Comentário *</label>
        <textarea id={`c-body-${article.id}`} required className={inputCls} rows={4} placeholder="Escreva seu comentário…" value={body} onChange={(e) => setBody(e.target.value)} aria-label="Seu comentário" maxLength={2000} />
        {/* campo invisível anti-spam */}
        <input type="text" value={trap} onChange={(e) => setTrap(e.target.value)} className="hidden" tabIndex={-1} autoComplete="off" aria-hidden="true" />
        {msg && (
          <p role="status" className={`text-sm ${msg.type === "ok" ? "text-emerald-600 dark:text-emerald-400" : "text-rose-500"}`}>{msg.text}</p>
        )}
        <button type="submit" className="rounded-xl bg-amber-500 px-5 py-2 text-sm font-bold text-slate-950 transition hover:bg-amber-400">
          Publicar comentário
        </button>
        {cfg.requireApproval !== false && <p className="text-xs text-slate-400">Os comentários passam por moderação antes de aparecer. Seu e-mail não será publicado.</p>}
      </form>
    </section>
  );
}

/* ======================= Compartilhamento social ======================= */

/** Redes de compartilhamento (ordem de exibição). */
export const SHARE_NETWORKS = [
  { id: "facebook", name: "Facebook", build: (u, t) => `https://www.facebook.com/sharer/sharer.php?u=${u}` },
  { id: "x", name: "X (antigo Twitter)", build: (u, t) => `https://x.com/intent/post?url=${u}&text=${t}` },
  { id: "mastodon", name: "Mastodon", build: (u, t) => `https://mastodonshare.com/?text=${t}&url=${u}` },
  { id: "bluesky", name: "Bluesky", build: (u, t) => `https://bsky.app/intent/compose?text=${t}%20${u}` },
  { id: "telegram", name: "Telegram", build: (u, t) => `https://t.me/share/url?url=${u}&text=${t}` },
  { id: "whatsapp", name: "WhatsApp", build: (u, t) => `https://api.whatsapp.com/send?text=${t}%20${u}` },
  { id: "reddit", name: "Reddit", build: (u, t) => `https://www.reddit.com/submit?url=${u}&title=${t}` },
  { id: "pinterest", name: "Pinterest", build: (u, t, img) => `https://pinterest.com/pin/create/button/?url=${u}&media=${img}&description=${t}` },
  { id: "tumblr", name: "Tumblr", build: (u, t) => `https://www.tumblr.com/widgets/share/tool?canonicalUrl=${u}&title=${t}` },
];

function shareIcon(id) {
  const extra = SHARE_EXTRA_ICONS[id];
  if (extra) return extra;
  const n = NETWORK_BY_ID[id];
  return n ? { color: n.color, path: n.path } : null;
}

/** Copia texto para a área de transferência (com fallback). */
async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    let ok = false;
    try { ok = document.execCommand("copy"); } catch { ok = false; }
    ta.remove();
    return ok;
  }
}

/** Botões de compartilhamento — exibidos no início e no final de cada artigo. */
export function ShareButtons({ article, state, position }) {
  const [copied, setCopied] = useState(false);
  if (state.html?.share === false) return null;
  const url = (typeof location !== "undefined" ? location.origin : "") + articlePath(article, state);
  const u = encodeURIComponent(url);
  const t = encodeURIComponent(article.title || "");
  const img = encodeURIComponent(article.cover || "");

  const copy = async () => {
    const ok = await copyText(url);
    setCopied(ok ? "ok" : "erro");
    setTimeout(() => setCopied(false), 2200);
  };

  return (
    <div
      className={`flex flex-wrap items-center gap-2 ${position === "before" ? "mb-6" : "mt-8 border-t border-slate-200 pt-6 dark:border-slate-800"}`}
      data-share={position}
      aria-label="Compartilhar este artigo"
      role="group"
    >
      <span className="mr-1 text-xs font-semibold uppercase tracking-wide text-slate-400">Compartilhar</span>
      {SHARE_NETWORKS.map((n) => {
        const ic = shareIcon(n.id);
        return (
          <a
            key={n.id}
            href={n.build(u, t, img)}
            target="_blank"
            rel="noopener noreferrer"
            title={`Compartilhar no ${n.name}`}
            aria-label={`Compartilhar no ${n.name} (abre em nova aba)`}
            data-share-net={n.id}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-100 text-slate-600 transition hover:-translate-y-0.5 hover:text-white dark:bg-slate-800 dark:text-slate-300"
            onMouseEnter={(e) => { e.currentTarget.style.background = ic.color; }}
            onMouseLeave={(e) => { e.currentTarget.style.background = ""; }}
          >
            <svg viewBox="0 0 24 24" className="h-4 w-4" aria-hidden="true"><path fill="currentColor" d={ic.path} /></svg>
          </a>
        );
      })}
      <button
        type="button"
        onClick={copy}
        data-share-net="copy"
        title="Copiar link"
        aria-label="Copiar link do artigo"
        className="flex h-8 items-center gap-1.5 rounded-full bg-slate-100 px-3 text-xs font-semibold text-slate-600 transition hover:bg-amber-500 hover:text-slate-950 dark:bg-slate-800 dark:text-slate-300"
      >
        <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
          <path d="M10 13a5 5 0 0 0 7.07 0l2.83-2.83a5 5 0 0 0-7.07-7.07L11.5 4.43" />
          <path d="M14 11a5 5 0 0 0-7.07 0L4.1 13.83a5 5 0 0 0 7.07 7.07l1.33-1.33" />
        </svg>
        {copied === "ok" ? "Link copiado!" : copied === "erro" ? "Copie da barra" : "Copiar link"}
      </button>
      <span className="sr-only" aria-live="polite">{copied === "ok" ? "Link copiado para a área de transferência" : ""}</span>
    </div>
  );
}

/* ======================= Sidebars do artigo ======================= */

/** Os 5 layouts de artigo (Painel → HTML). */
export const ARTICLE_LAYOUTS = [
  { id: "none", name: "Sem sidebar", desc: "Conteúdo centralizado, largura de leitura." },
  { id: "left", name: "Sidebar à esquerda", desc: "Uma coluna lateral à esquerda do conteúdo." },
  { id: "right", name: "Sidebar à direita", desc: "Uma coluna lateral à direita do conteúdo." },
  { id: "two-left", name: "Duas sidebars à esquerda", desc: "Duas colunas laterais à esquerda." },
  { id: "two-right", name: "Duas sidebars à direita", desc: "Duas colunas laterais à direita." },
];

function Widget({ title, children }) {
  return (
    <section className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900">
      <h2 className="mb-3 text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">{title}</h2>
      {children}
    </section>
  );
}

function MiniList({ items, state, meta }) {
  return (
    <ul className="space-y-3">
      {items.map((a) => (
        <li key={a.id}>
          <button type="button" onClick={() => navigate(articlePath(a, state))} className="group flex w-full items-center gap-3 text-left">
            {a.cover ? <img src={a.cover} alt="" className="h-11 w-11 shrink-0 rounded-lg object-cover" loading="lazy" />
              : <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-slate-100 dark:bg-slate-800">📄</span>}
            <span className="min-w-0">
              <span className="line-clamp-2 text-sm font-semibold text-slate-800 group-hover:text-amber-600 dark:text-slate-100">{a.title}</span>
              <span className="text-xs text-slate-400">{meta(a)}</span>
            </span>
          </button>
        </li>
      ))}
    </ul>
  );
}

/** Sidebar principal: mais lidos + categorias. Sidebar secundária: últimos artigos + redes. */
export function ArticleSidebar({ which = 1, article, state }) {
  const pub = (state.articles || []).filter((a) => a.status === "publicado" && a.id !== article.id);
  if (which === 1) {
    const views = state.views || {};
    const top = [...pub].sort((a, b) => (views[b.id] || 0) - (views[a.id] || 0)).slice(0, 5);
    return (
      <aside className="space-y-5" aria-label="Barra lateral principal" data-sidebar="1">
        <Widget title="🔥 Mais lidos">
          <MiniList items={top} state={state} meta={(a) => `👁 ${views[a.id] || 0} visualizações`} />
        </Widget>
        <Widget title="🗂️ Categorias">
          <ul className="flex flex-wrap gap-1.5">
            {(state.categories || []).map((c) => (
              <li key={c.id}>
                <button type="button" onClick={() => navigate(`/categoria/${c.slug}`)}
                  className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-600 hover:bg-amber-100 hover:text-amber-800 dark:bg-slate-800 dark:text-slate-300">
                  {c.icon} {c.name}
                </button>
              </li>
            ))}
          </ul>
        </Widget>
      </aside>
    );
  }
  const latest = [...pub].sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 5);
  return (
    <aside className="space-y-5" aria-label="Barra lateral secundária" data-sidebar="2">
      <Widget title="🆕 Últimos artigos">
        <MiniList items={latest} state={state} meta={(a) => formatDate(a.date)} />
      </Widget>
      {state.social?.enabled !== false && (
        <Widget title="🌐 Siga nas redes">
          <SocialLinks state={state} variant="light" />
        </Widget>
      )}
    </aside>
  );
}
