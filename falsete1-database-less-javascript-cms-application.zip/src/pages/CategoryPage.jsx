// Listagem pública de artigos de uma categoria.
import PublicLayout, { ArticleCard } from "../components/Layout.jsx";
import NotFound from "./NotFound.jsx";
import { formatDate } from "../utils.js";

export default function CategoryPage({ state, slug }) {
  const cat = (state.categories || []).find((c) => c.slug === slug);
  if (!cat) return <NotFound />;

  const articles = (state.articles || [])
    .filter((a) => a.status === "publicado" && (a.categories || []).includes(slug))
    .sort((a, b) => new Date(b.date) - new Date(a.date));

  return (
    <PublicLayout state={state}>
      <section
        className="relative overflow-hidden"
        style={{ background: `linear-gradient(120deg, ${cat.color}26, ${cat.color}0d 55%, transparent)` }}
      >
        <div className="mx-auto max-w-7xl px-4 py-14">
          <p className="text-xs font-bold uppercase tracking-[0.25em] text-slate-400">
            Categoria · {formatDate(new Date().toISOString()) && ""}
          </p>
          <div className="mt-2 flex items-center gap-4">
            <span
              className="flex h-14 w-14 items-center justify-center rounded-2xl text-3xl shadow"
              style={{ background: `${cat.color}22` }}
              aria-hidden="true"
            >
              {cat.icon}
            </span>
            <div>
              <h1 className="text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white sm:text-4xl">
                {cat.name}
              </h1>
              <p className="mt-1 max-w-2xl text-slate-500 dark:text-slate-400">{cat.description}</p>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-10">
        {articles.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-12 text-center dark:border-slate-700 dark:bg-slate-900">
            <p className="text-4xl" aria-hidden="true">🗂️</p>
            <p className="mt-3 font-semibold text-slate-700 dark:text-slate-200">
              Ainda não há artigos publicados nesta categoria.
            </p>
            <p className="mt-1 text-sm text-slate-400">Volte em breve!</p>
          </div>
        ) : (
          <>
            <p className="mb-5 text-sm text-slate-400">
              {articles.length} artigo{articles.length === 1 ? "" : "s"} publicado{articles.length === 1 ? "" : "s"}
            </p>
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {articles.map((a) => (
                <ArticleCard key={a.id} article={a} />
              ))}
            </div>
          </>
        )}
      </section>
    </PublicLayout>
  );
}
