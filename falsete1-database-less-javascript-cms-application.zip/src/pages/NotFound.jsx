// Página 404 — também usada para esconder rotas administrativas sem autenticação.
import PublicLayout from "../components/Layout.jsx";
import { navigate } from "../router.js";

export default function NotFound({ state }) {
  const content = (
    <div className="mx-auto flex max-w-2xl flex-col items-center px-4 py-28 text-center">
      <p className="text-7xl font-black tracking-tight text-amber-500">404</p>
      <h1 className="mt-4 text-2xl font-bold text-slate-900 dark:text-white">Página não encontrada</h1>
      <p className="mt-2 text-slate-500 dark:text-slate-400">
        O endereço que você procurou não existe ou não está disponível.
      </p>
      <button
        type="button"
        onClick={() => navigate("/")}
        className="mt-8 rounded-xl bg-amber-500 px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-amber-500/25 transition hover:bg-amber-400"
      >
        Voltar para a página inicial
      </button>
    </div>
  );
  return state ? <PublicLayout state={state}>{content}</PublicLayout> : content;
}
