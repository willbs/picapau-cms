// Campos de Imagens e Áudios da página de perfil (até 15 MB por arquivo, guardados no IndexedDB).
import { useRef, useState } from "react";
import { updateState } from "../store.js";
import { uid, formatDate, cn } from "../utils.js";
import { saveMediaFile, deleteMediaFile, useMediaUrl, formatMB, MAX_MEDIA_BYTES } from "../mediaStore.js";

const inputCls =
  "w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 placeholder-slate-400 focus:border-indigo-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white";

function patchProfile(id, key, fn) {
  updateState((s) => {
    const p = s.forum.profiles.find((x) => x.id === id);
    if (p) p[key] = fn(p[key] || []);
  });
}

/** Imagem guardada no navegador. */
export function StoredImage({ item, className, alt }) {
  const url = useMediaUrl(item.mediaId);
  if (!url) return <span className={cn("block animate-pulse bg-slate-200 dark:bg-slate-800", className)} aria-hidden="true" />;
  return <img src={url} alt={alt ?? item.title ?? ""} className={className} loading="lazy" />;
}

/** Player de um áudio guardado no navegador. */
export function StoredAudio({ item, className, audioRef, autoPlay }) {
  const url = useMediaUrl(item.mediaId);
  if (!url) return <span className="text-xs text-slate-400">carregando…</span>;
  return <audio ref={audioRef} controls preload="metadata" src={url} className={className} autoPlay={autoPlay} style={{ height: 40 }} />;
}

function UploadForm({ kind, onAdd }) {
  const ref = useRef(null);
  const [title, setTitle] = useState("");
  const [file, setFile] = useState(null);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const label = kind === "image" ? "imagem" : "áudio";
  const submit = async (e) => {
    e.preventDefault();
    setErr("");
    if (!file) return setErr(`Selecione um arquivo de ${label}.`);
    setBusy(true);
    try {
      const meta = await saveMediaFile(file, kind);
      onAdd({ ...meta, id: uid(), title: title.trim() || file.name.replace(/\.[^.]+$/, ""), createdAt: new Date().toISOString() });
      setTitle("");
      setFile(null);
      if (ref.current) ref.current.value = "";
    } catch (e2) {
      setErr(e2.message);
    }
    setBusy(false);
  };
  return (
    <form onSubmit={submit} className="mb-6 space-y-3 rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900" data-media-upload={kind}>
      <p className="text-sm font-bold text-slate-800 dark:text-slate-100">➕ Adicionar {label} <span className="font-normal text-slate-400">(máx. 15 MB)</span></p>
      <input ref={ref} type="file" accept={kind === "image" ? "image/*" : "audio/*"} aria-label={`Arquivo de ${label}`}
        onChange={(e) => { const f = e.target.files?.[0] || null; setFile(f); setErr(f && f.size > MAX_MEDIA_BYTES ? `Arquivo muito grande (${formatMB(f.size)}). O limite é 15 MB por arquivo.` : ""); }}
        className="block w-full text-sm text-slate-600 file:mr-3 file:rounded-lg file:border-0 file:bg-indigo-600 file:px-3 file:py-2 file:text-sm file:font-semibold file:text-white dark:text-slate-300" />
      <input className={inputCls} value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Título (opcional)" aria-label={`Título da ${label}`} />
      {file && !err && <p className="text-xs text-slate-500">{file.name} · {formatMB(file.size)}</p>}
      {err && <p role="alert" className="text-xs text-rose-500">{err}</p>}
      <button type="submit" disabled={busy || !!err} className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-bold text-white hover:bg-indigo-500 disabled:opacity-50">
        {busy ? "Enviando…" : `Adicionar ${label}`}
      </button>
    </form>
  );
}

export function ImagesSection({ profile, isOwner }) {
  const items = profile.images || [];
  const [open, setOpen] = useState(null);
  const remove = async (it) => {
    patchProfile(profile.id, "images", (l) => l.filter((x) => x.id !== it.id));
    deleteMediaFile(it.mediaId).catch(() => {});
  };
  return (
    <div data-profile-images>
      {isOwner && <UploadForm kind="image" onAdd={(it) => patchProfile(profile.id, "images", (l) => [it, ...l])} />}
      {items.length === 0 ? (
        <p className="rounded-2xl border border-dashed border-slate-300 p-8 text-center text-sm text-slate-400 dark:border-slate-700">Nenhuma imagem ainda.</p>
      ) : (
        <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {items.map((it) => (
            <li key={it.id} className="group relative overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900" data-image-item>
              <button type="button" onClick={() => setOpen(it)} className="block w-full" aria-label={`Ampliar ${it.title}`}>
                <StoredImage item={it} className="aspect-square w-full object-cover" />
              </button>
              <p className="truncate px-2 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200">{it.title}</p>
              {isOwner && (
                <button type="button" onClick={() => remove(it)} aria-label={`Remover imagem ${it.title}`}
                  className="absolute right-2 top-2 rounded-full bg-rose-600 px-2 py-0.5 text-xs font-bold text-white opacity-90 hover:opacity-100">✕</button>
              )}
            </li>
          ))}
        </ul>
      )}
      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4" role="dialog" aria-modal="true" aria-label={open.title} onClick={() => setOpen(null)}>
          <figure className="max-h-full max-w-5xl" onClick={(e) => e.stopPropagation()}>
            <StoredImage item={open} className="max-h-[80vh] w-auto rounded-xl object-contain" />
            <figcaption className="mt-2 text-center text-sm text-white">{open.title}</figcaption>
          </figure>
          <button type="button" onClick={() => setOpen(null)} className="absolute right-4 top-4 text-2xl text-white" aria-label="Fechar">✕</button>
        </div>
      )}
    </div>
  );
}

export function AudiosSection({ profile, isOwner }) {
  const items = profile.audios || [];
  const remove = (it) => {
    patchProfile(profile.id, "audios", (l) => l.filter((x) => x.id !== it.id));
    deleteMediaFile(it.mediaId).catch(() => {});
  };
  return (
    <div data-profile-audios>
      {isOwner && <UploadForm kind="audio" onAdd={(it) => patchProfile(profile.id, "audios", (l) => [it, ...l])} />}
      {items.length === 0 ? (
        <p className="rounded-2xl border border-dashed border-slate-300 p-8 text-center text-sm text-slate-400 dark:border-slate-700">Nenhum áudio ainda.</p>
      ) : (
        <ul className="space-y-3">
          {items.map((it) => (
            <li key={it.id} className="flex flex-wrap items-center gap-3 rounded-2xl border border-slate-200 bg-white p-3 dark:border-slate-800 dark:bg-slate-900" data-audio-item>
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500/15 text-xl" aria-hidden="true">🎵</span>
              <div className="min-w-0 flex-1 basis-60">
                <p className="truncate text-sm font-bold text-slate-900 dark:text-white">{it.title}</p>
                <p className="text-xs text-slate-400">{formatDate(it.createdAt)} · {formatMB(it.size)}</p>
              </div>
              <StoredAudio item={it} className="w-full sm:w-72" />
              {isOwner && (
                <button type="button" onClick={() => remove(it)} className="text-xs text-rose-500 hover:underline" aria-label={`Remover áudio ${it.title}`}>remover</button>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
