// Redefinição de senha via link: /login/redefinir/:token
// (o link é "enviado por e-mail" — como não há servidor de e-mail, ele é exibido
// na tela de "esqueci a senha" em modo demo e salvo no LocalStorage por 30 min).
import { useState } from "react";
import { getResetToken, resetPasswordWithToken } from "../auth.js";
import { navigate } from "../router.js";

export default function ResetPassword({ token }) {
  const valid = !!getResetToken(token);
  const [pass, setPass] = useState("");
  const [pass2, setPass2] = useState("");
  const [error, setError] = useState("");
  const [done, setDone] = useState(false);
  const [loading, setLoading] = useState(false);

  const inputCls =
    "w-full rounded-xl border border-slate-700/60 bg-slate-900/70 px-4 py-3 text-sm text-slate-100 placeholder-slate-500 outline-none transition focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/30";

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    if (pass !== pass2) return setError("As senhas não coincidem.");
    setLoading(true);
    const res = await resetPasswordWithToken(token, pass);
    setLoading(false);
    if (res.ok) setDone(true);
    else setError(res.error || "Não foi possível redefinir a senha.");
  };

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#070b18] px-4 py-10">
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(70% 90% at 50% 0%, rgba(99,102,241,.16), transparent 60%), linear-gradient(180deg, #070b18 0%, #0a1024 100%)",
        }}
        aria-hidden="true"
      />
      <div className="animate-fade-up relative w-full max-w-md">
        <div className="glass-dark rounded-3xl p-8 shadow-2xl shadow-indigo-950/50">
          <div className="text-center">
            <span className="text-4xl" aria-hidden="true">🔑</span>
            <h1 className="mt-3 text-2xl font-bold tracking-tight text-white">Redefinir senha</h1>
            <p className="mt-1 text-sm text-slate-400">Crie uma nova senha para sua conta</p>
          </div>

          {!valid ? (
            <div className="mt-8">
              <p role="alert" className="rounded-xl border border-rose-500/40 bg-rose-500/10 px-4 py-3 text-sm text-rose-300">
                Este link é inválido ou já expirou (vale por 30 minutos). Solicite um novo na página de acesso.
              </p>
              <button
                type="button"
                onClick={() => navigate("/login")}
                className="mt-5 w-full rounded-xl bg-gradient-to-r from-indigo-500 to-violet-500 px-4 py-3 text-sm font-semibold text-white transition hover:from-indigo-400 hover:to-violet-400"
              >
                Ir para o acesso
              </button>
            </div>
          ) : done ? (
            <div className="mt-8">
              <p role="status" className="rounded-xl border border-emerald-500/40 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-300">
                ✅ Senha redefinida com sucesso! Você já pode entrar com a nova senha.
              </p>
              <button
                type="button"
                onClick={() => navigate("/login")}
                className="mt-5 w-full rounded-xl bg-gradient-to-r from-indigo-500 to-violet-500 px-4 py-3 text-sm font-semibold text-white transition hover:from-indigo-400 hover:to-violet-400"
              >
                Ir para o acesso
              </button>
            </div>
          ) : (
            <form onSubmit={submit} className="mt-8 space-y-4" noValidate>
              <div>
                <label htmlFor="rp-pass" className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Nova senha
                </label>
                <input
                  id="rp-pass"
                  type="password"
                  autoComplete="new-password"
                  className={inputCls}
                  value={pass}
                  onChange={(e) => setPass(e.target.value)}
                  placeholder="mínimo 6 caracteres"
                  required
                  minLength={6}
                  autoFocus
                />
              </div>
              <div>
                <label htmlFor="rp-pass2" className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Confirmar nova senha
                </label>
                <input
                  id="rp-pass2"
                  type="password"
                  autoComplete="new-password"
                  className={inputCls}
                  value={pass2}
                  onChange={(e) => setPass2(e.target.value)}
                  placeholder="repita a nova senha"
                  required
                />
              </div>
              {error && (
                <p role="alert" className="animate-fade-up rounded-lg border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-sm text-rose-300">
                  {error}
                </p>
              )}
              <button
                type="submit"
                disabled={loading}
                className="w-full rounded-xl bg-gradient-to-r from-indigo-500 to-violet-500 px-4 py-3 text-sm font-semibold text-white shadow-lg shadow-indigo-500/30 transition hover:from-indigo-400 hover:to-violet-400 disabled:opacity-50"
              >
                {loading ? "Salvando…" : "Salvar nova senha"}
              </button>
              <button
                type="button"
                onClick={() => navigate("/login")}
                className="w-full text-center text-xs text-slate-500 transition hover:text-slate-300"
              >
                ← Voltar ao acesso
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
