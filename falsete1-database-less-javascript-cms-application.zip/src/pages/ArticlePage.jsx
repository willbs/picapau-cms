// Página pública de artigo: compartilhamento (início e fim), blocos HTML, artigo no modelo
// escolhido, visualizações, comentários e layout com 0, 1 ou 2 sidebars (Painel → HTML).
import PublicLayout from "../components/Layout.jsx";
import ArticleView from "../templates/ArticleView.jsx";
import NotFound from "./NotFound.jsx";
import { HtmlBlock, Comments, useViewCounter, ShareButtons, ArticleSidebar } from "./ArticleExtras.jsx";

// Classes literais (necessárias para o Tailwind gerar o CSS)
const GRID = {
  left: "lg:grid-cols-[260px_minmax(0,1fr)]",
  right: "lg:grid-cols-[minmax(0,1fr)_260px]",
  "two-left": "lg:grid-cols-[220px_220px_minmax(0,1fr)]",
  "two-right": "lg:grid-cols-[minmax(0,1fr)_220px_220px]",
};
const ORDER = {
  left: { main: "lg:order-2", s1: "lg:order-1", s2: "" },
  right: { main: "lg:order-1", s1: "lg:order-2", s2: "" },
  "two-left": { main: "lg:order-3", s1: "lg:order-1", s2: "lg:order-2" },
  "two-right": { main: "lg:order-1", s1: "lg:order-2", s2: "lg:order-3" },
};

export default function ArticlePage({ state, slug }) {
  const article = (state.articles || []).find((a) => a.slug === slug);
  const valid = !!article && article.status === "publicado";
  const views = useViewCounter(valid ? article : null, state);
  if (!valid) return <NotFound />;

  const cats = (state.categories || []).filter((c) => (article.categories || []).includes(c.slug));
  const related = (state.articles || [])
    .filter((a) => a.id !== article.id && a.status === "publicado" && a.type === article.type &&
      (a.categories || []).some((c) => (article.categories || []).includes(c)))
    .slice(0, 4);
  const relatedFinal = related.length
    ? related
    : (state.articles || []).filter((a) => a.id !== article.id && a.status === "publicado" && a.type === article.type).slice(0, 4);
  const showViews = state.html?.showViews !== false;
  const layout = GRID[state.html?.layout] ? state.html.layout : "none";

  const main = (
    <div className="min-w-0">
      <HtmlBlock position="before" article={article} state={state} />
      <ShareButtons position="before" article={article} state={state} />
      <ArticleView article={showViews ? { ...article, __views: views } : article} related={relatedFinal} categories={cats} />
      <ShareButtons position="after" article={article} state={state} />
      <HtmlBlock position="after" article={article} state={state} />
      <Comments article={article} state={state} />
    </div>
  );

  if (layout === "none") {
    return (
      <PublicLayout state={state}>
        <div className="mx-auto max-w-4xl px-4 py-10" data-article-layout="none">{main}</div>
      </PublicLayout>
    );
  }

  const o = ORDER[layout];
  const two = layout.startsWith("two");
  return (
    <PublicLayout state={state}>
      <div className={`mx-auto grid max-w-7xl grid-cols-1 gap-8 px-4 py-10 ${GRID[layout]}`} data-article-layout={layout}>
        <div className={`min-w-0 ${o.main}`}>{main}</div>
        <div className={`lg:sticky lg:top-24 lg:self-start ${o.s1}`}>
          <ArticleSidebar which={1} article={article} state={state} />
        </div>
        {two && (
          <div className={`lg:sticky lg:top-24 lg:self-start ${o.s2}`}>
            <ArticleSidebar which={2} article={article} state={state} />
          </div>
        )}
      </div>
    </PublicLayout>
  );
}
