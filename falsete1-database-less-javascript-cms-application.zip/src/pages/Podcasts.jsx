// Página pública de Podcasts: todos os artigos do tipo "áudio" (episódios)
// publicados, separados por categoria. só existe se a feature estiver habilitada
// no painel (Painel → Podcasts → botão habilitar/desabilitar).
import PublicLayout from "../components/Layout.jsx";
import NotFound from "./NotFound.jsx";
import { navigate } from "../router.js";
import { articlePath } from "../permalink.js";
import { formatDate } from "../utils.js";

function EpisodeCard({ ep, cat }) {
  const cover = ep.media?.audio?.cover || ep.cover;
  return (
    <article className="group flex items-center gap-4 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md dark:border-slate-800 dark:bg-slate-900">
      <button
        type="button"
        onClick={() => navigate(articlePath(ep))}
        className="relative h-20 w-20 shrink-0 overflow-hidden rounded-xl bg-slate-100 dark:bg-slate-800"
        aria-label={`Ouvir ${ep.title}`}
      >
        {cover ? (
          <img src={cover} alt="" loading="lazy" className="h-full w-full object-cover" />
        ) : (
          <span className="flex h-full w-full items-center justify-center text-3xl" aria-hidden="true">🎧</span>
        )}
        <span
          className="absolute inset-0 flex items-center justify-center bg-black/40 text-white opacity-0 transition group-hover:opacity-100"
          aria-hidden="true"
        >
          ▶
        </span>
      </button>
      <div className="min-w-0 flex-1">
        <button type="button" onClick={() => navigate(articlePath(ep))} className="block w-full text-left">
          <h3 className="truncate font-bold text-slate-900 group-hover:text-amber-600 dark:text-white">
            {ep.title}
          </h3>
        </button>
        <p className="mt-0.5 line-clamp-1 text-sm text-slate-500 dark:text-slate-400">
          {ep.excerpt || ""}
        </p>
        <p className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-slate-400">
          <span>📅 {formatDate(ep.date)}</span>
          {ep.media?.audio?.duration && <span>⏱ {ep.media.audio.duration}</span>}
          {cat && <span className="rounded-full bg-amber-100 px-2 py-0.5 font-semibold text-amber-800 dark:bg-amber-500/15 dark:text-amber-300">{cat.icon} {cat.name}</span>}
        </p>
      </div>
      <button
        type="button"
        onClick={() => navigate(articlePath(ep))}
        className="shrink-0 rounded-full bg-amber-500 px-3.5 py-2 text-sm font-bold text-white shadow transition hover:bg-amber-400"
      >
        ▶ Ouvir
      </button>
    </article>
  );
}

export default function Podcasts({ state }) {
  // Feature flag: se desabilitada no painel, a página não existe (404).
  if (state.features?.podcast === false) return <NotFound state={state} />;

  const episodes = (state.articles || [])
    .filter((a) => a.type === "audio" && a.status === "publicado")
    .sort((a, b) => new Date(b.date) - new Date(a.date));

  // Agrupa os episódios por categoria (na ordem das categorias do CMS)
  // Agrupa pelas categorias EXCLUSIVAS de podcast (Painel → Podcasts → Categorias de podcast)
  const pcats = state.podcast?.categories || [];
  const byCategory = pcats
    .map((cat) => ({ cat, eps: episodes.filter((a) => a.podcastCategory === cat.slug) }))
    .filter((g) => g.eps.length > 0);
  // Episódios sem categoria de podcast vão para "Outros"
  const others = episodes.filter((a) => !pcats.some((c) => c.slug === a.podcastCategory));

  const featured = episodes[0];

  return (
    <PublicLayout state={state}>
      {/* Hero */}
      <section className="relative overflow-hidden bg-slate-950 text-white">
        <div
          className="pointer-events-none absolute inset-0 opacity-40"
          style={{
            background:
              "radial-gradient(60% 80% at 15% 10%, rgba(16,185,129,.28), transparent 60%), radial-gradient(50% 70% at 85% 20%, rgba(245,158,11,.22), transparent 60%)",
          }}
          aria-hidden="true"
        />
        <div className="relative mx-auto max-w-7xl px-4 py-16 sm:py-20">
          <p className="animate-fade-up text-xs font-bold uppercase tracking-[0.25em] text-emerald-400">
            🎧 Podcasts
          </p>
          <h1 className="animate-fade-up mt-3 max-w-3xl text-4xl font-extrabold tracking-tight sm:text-5xl">
            Todos os episódios, por categoria
          </h1>
          <p className="animate-fade-up mt-4 max-w-2xl text-lg text-slate-300" style={{ animationDelay: "80ms" }}>
            {episodes.length} episódio{episodes.length === 1 ? "" : "s"} publicado
            {episodes.length === 1 ? "" : "s"} em {byCategory.length + (others.length ? 1 : 0)} categoria
            {byCategory.length + (others.length ? 1 : 0) === 1 ? "" : "s"}.
          </p>
        </div>
      </section>

      {/* Episódio em destaque */}
      {featured && (
        <section className="mx-auto max-w-7xl px-4 pt-10">
          <div className="flex flex-col gap-6 overflow-hidden rounded-3xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900 sm:flex-row sm:items-center">
            {(() => {
              const cover = featured.media?.audio?.cover || featured.cover;
              return cover ? (
                <img src={cover} alt="" className="h-40 w-full rounded-2xl object-cover sm:h-36 sm:w-36" loading="lazy" />
              ) : (
                <span className="flex h-40 w-full items-center justify-center rounded-2xl bg-slate-100 text-6xl dark:bg-slate-800 sm:h-36 sm:w-36" aria-hidden="true">🎧</span>
              );
            })()}
            <div className="min-w-0 flex-1">
              <p className="text-xs font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
                ⭐ Em destaque
              </p>
              <button type="button" onClick={() => navigate(articlePath(featured))} className="mt-1 block text-left">
                <h2 className="text-2xl font-extrabold text-slate-900 hover:text-amber-600 dark:text-white">
                  {featured.title}
                </h2>
              </button>
              <p className="mt-1 line-clamp-2 text-slate-500 dark:text-slate-400">{featured.excerpt}</p>
              <div className="mt-3">
                {featured.media?.audio?.url ? (
                  <audio controls preload="metadata" src={featured.media.audio.url} className="w-full max-w-md" style={{ height: 44 }}>
                    Seu navegador não suporta áudio HTML5.
                  </audio>
                ) : (
                  <button
                    type="button"
                    onClick={() => navigate(articlePath(featured))}
                    className="rounded-xl bg-amber-500 px-4 py-2 text-sm font-bold text-white hover:bg-amber-400"
                  >
                    ▶ Abrir episódio
                  </button>
                )}
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Episódios separados por categoria */}
      <div className="mx-auto max-w-7xl space-y-12 px-4 py-12">
        {byCategory.map(({ cat, eps }) => (
          <section key={cat.id} data-podcast-cat={cat.slug} aria-labelledby={`podcast-cat-${cat.slug}`}>
            <div className="mb-5 flex flex-wrap items-center gap-3">
              <span
                className="flex h-11 w-11 items-center justify-center rounded-xl text-2xl shadow-inner"
                style={{ background: `${cat.color}1f` }}
                aria-hidden="true"
              >
                {cat.icon}
              </span>
              <div>
                <h2 id={`podcast-cat-${cat.slug}`} className="text-2xl font-extrabold text-slate-900 dark:text-white">
                  {cat.name}
                </h2>
                <p className="text-sm text-slate-400">
                  {eps.length} episódio{eps.length === 1 ? "" : "s"}
                </p>
              </div>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              {eps.map((ep) => (
                <EpisodeCard key={ep.id} ep={ep} cat={cat} />
              ))}
            </div>
          </section>
        ))}

        {others.length > 0 && (
          <section aria-labelledby="podcast-outros">
            <h2 id="podcast-outros" className="mb-5 text-2xl font-extrabold text-slate-900 dark:text-white">
              📁 Outros episódios
            </h2>
            <div className="grid gap-4 md:grid-cols-2">
              {others.map((ep) => (
                <EpisodeCard key={ep.id} ep={ep} cat={null} />
              ))}
            </div>
          </section>
        )}

        {episodes.length === 0 && (
          <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-14 text-center dark:border-slate-700 dark:bg-slate-900">
            <p className="text-5xl" aria-hidden="true">🎙️</p>
            <p className="mt-3 font-semibold text-slate-700 dark:text-slate-200">
              Nenhum episódio publicado ainda.
            </p>
            <p className="mt-1 text-sm text-slate-400">Os podcasts adicionados no painel aparecem aqui.</p>
          </div>
        )}
      </div>
    </PublicLayout>
  );
}
