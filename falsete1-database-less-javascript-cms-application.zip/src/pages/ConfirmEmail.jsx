// Confirmação de e-mail: /login/confirmar/:token (link enviado no cadastro).
import { useEffect, useState } from "react";
import { verifyEmail } from "../auth.js";
import { navigate } from "../router.js";

export default function ConfirmEmail({ token }) {
  const [res, setRes] = useState(null);
  useEffect(() => { setRes(verifyEmail(token)); }, [token]);
  return (
    <div className="relative flex min-h-screen items-center justify-center bg-[#070b18] px-4 py-10">
      <div className="glass-dark w-full max-w-md rounded-3xl p-8 text-center shadow-2xl" data-confirm-result={res ? (res.ok ? "ok" : "erro") : "carregando"}>
        <span className="text-5xl" aria-hidden="true">{!res ? "⏳" : res.ok ? "✅" : "⚠️"}</span>
        <h1 className="mt-3 text-2xl font-bold text-white">{!res ? "Confirmando…" : res.ok ? "E-mail confirmado!" : "Não foi possível confirmar"}</h1>
        {res && (
          <p className={`mt-3 text-sm ${res.ok ? "text-slate-300" : "text-rose-300"}`}>
            {res.ok ? <>Sua conta <strong>{res.user.email}</strong> está ativa. Agora você já pode entrar no site.</> : res.error}
          </p>
        )}
        <button type="button" onClick={() => navigate("/login")}
          className="mt-6 w-full rounded-xl bg-gradient-to-r from-indigo-500 to-violet-500 px-4 py-3 text-sm font-semibold text-white">
          Ir para o login
        </button>
      </div>
    </div>
  );
}
