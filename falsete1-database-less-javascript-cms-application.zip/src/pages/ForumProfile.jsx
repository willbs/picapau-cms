// Página de perfil do usuário do fórum: /forum/u/:username
// - 5 modelos de página (clássico, moderno, minimal, neon, revista)
// - foto de perfil e foto de capa (URL ou upload)
// - seguir / deixar de seguir, lista de seguidores e seguindo (o dono pode REMOVER seguidores)
// - vídeos: alternar entre YouTube, Vimeo, Dailymotion, X, Facebook ou URL personalizada (com upload)
import { useState } from "react";
import PublicLayout from "../components/Layout.jsx";
import NotFound from "./NotFound.jsx";
import UploadField from "../components/UploadField.jsx";
import VideoEmbed, { VIDEO_PLATFORMS, getEmbed } from "../components/VideoEmbed.jsx";
import { navigate } from "../router.js";
import { updateState } from "../store.js";
import { uid, formatDate, cn } from "../utils.js";
import { getMe, setMeId, Avatar } from "./Forum.jsx";
import { ImagesSection, AudiosSection } from "./ProfileMedia.jsx";

// Plataformas de vídeo do perfil (sem "URL personalizada")
const PROFILE_PLATFORMS = VIDEO_PLATFORMS.filter((p) => p.id !== "custom");
import { brl } from "./Loja.jsx";
import { toggleWishlist } from "../components/WishHeart.jsx";

/** Os 5 modelos de página de perfil. */
export const PROFILE_TEMPLATES = [
  { id: "classico", name: "Clássico", icon: "🧾", desc: "Capa no topo, avatar à esquerda, conteúdo abaixo." },
  { id: "moderno", name: "Moderno", icon: "✨", desc: "Capa arredondada, avatar grande centralizado." },
  { id: "minimal", name: "Minimal", icon: "◻", desc: "Visual limpo, faixa de capa discreta, muito respiro." },
  { id: "neon", name: "Neon", icon: "🌌", desc: "Fundo escuro, bordas neon e avatar com brilho." },
  { id: "revista", name: "Revista", icon: "📰", desc: "Barra lateral fixa com o perfil e conteúdo ao lado." },
];

const inputCls =
  "w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 placeholder-slate-400 focus:border-indigo-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white";
const labelCls = "mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400";

/* ----------------------------- Ações (persistidas) ----------------------------- */

export function followUser(meId, targetId) {
  updateState((s) => {
    const me = s.forum.profiles.find((p) => p.id === meId);
    if (me && meId !== targetId && !me.following.includes(targetId)) me.following.push(targetId);
  });
}
export function unfollowUser(meId, targetId) {
  updateState((s) => {
    const me = s.forum.profiles.find((p) => p.id === meId);
    if (me) me.following = me.following.filter((id) => id !== targetId);
  });
}
/** Remove um seguidor: tira o meu id da lista "following" dele. */
export function removeFollower(myId, followerId) {
  updateState((s) => {
    const f = s.forum.profiles.find((p) => p.id === followerId);
    if (f) f.following = f.following.filter((id) => id !== myId);
  });
}
export function updateProfile(id, patch) {
  updateState((s) => {
    const p = s.forum.profiles.find((x) => x.id === id);
    if (p) Object.assign(p, patch);
  });
}

/* ----------------------------- Formulário de personalização ----------------------------- */

/** Formulário de personalização (usado na página de perfil e no painel → Fórum). */
export function ProfileForm({ profile, onSaved, onCancel, allProfiles = [] }) {
  const [f, setF] = useState(() => ({
    name: profile.name || "",
    username: profile.username || "",
    bio: profile.bio || "",
    avatar: profile.avatar || "",
    cover: profile.cover || "",
    template: profile.template || "classico",
  }));
  const [err, setErr] = useState("");
  const set = (k, v) => setF((x) => ({ ...x, [k]: v }));

  const save = (e) => {
    e.preventDefault();
    if (!f.name.trim()) return setErr("O nome é obrigatório.");
    const username = f.username.trim().toLowerCase().replace(/[^a-z0-9_]/g, "");
    if (!username) return setErr("Informe um @usuário válido (letras, números e _).");
    if (allProfiles.some((p) => p.username === username && p.id !== profile.id)) return setErr("Esse @usuário já existe.");
    onSaved({ ...f, name: f.name.trim(), username });
  };

  return (
    <form onSubmit={save} className="space-y-4">
      {err && <p role="alert" className="rounded-lg bg-rose-500/10 px-3 py-2 text-sm text-rose-500">{err}</p>}
      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label htmlFor="pf-name" className={labelCls}>Nome</label>
          <input id="pf-name" className={inputCls} value={f.name} onChange={(e) => set("name", e.target.value)} />
        </div>
        <div>
          <label htmlFor="pf-user" className={labelCls}>@usuário (URL do perfil)</label>
          <input id="pf-user" className={inputCls} value={f.username} onChange={(e) => set("username", e.target.value)} />
        </div>
      </div>
      <div>
        <label htmlFor="pf-bio" className={labelCls}>Bio</label>
        <textarea id="pf-bio" className={inputCls} rows={2} value={f.bio} onChange={(e) => set("bio", e.target.value)} placeholder="Fale um pouco sobre você…" />
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label htmlFor="pf-avatar" className={labelCls}>Foto de perfil — URL ou upload</label>
          <div className="flex items-center gap-2">
            <input id="pf-avatar" className={`${inputCls} min-w-0 flex-1`} value={f.avatar} onChange={(e) => set("avatar", e.target.value)} placeholder="https://…/foto.jpg" />
            <UploadField kind="image" label="Upload" maxDim={400} onUploaded={(d) => set("avatar", d)} />
          </div>
          {f.avatar && <img src={f.avatar} alt="Prévia da foto de perfil" className="mt-2 h-16 w-16 rounded-full object-cover" />}
        </div>
        <div>
          <label htmlFor="pf-cover" className={labelCls}>Foto de capa — URL ou upload</label>
          <div className="flex items-center gap-2">
            <input id="pf-cover" className={`${inputCls} min-w-0 flex-1`} value={f.cover} onChange={(e) => set("cover", e.target.value)} placeholder="https://…/capa.jpg" />
            <UploadField kind="image" label="Upload" maxDim={1600} onUploaded={(d) => set("cover", d)} />
          </div>
          {f.cover && <img src={f.cover} alt="Prévia da capa" className="mt-2 h-16 w-full rounded-lg object-cover" />}
        </div>
      </div>
      <div>
        <span className={labelCls}>Modelo da página de perfil (5 opções)</span>
        <div className="grid gap-2 sm:grid-cols-5" role="radiogroup" aria-label="Modelo da página de perfil">
          {PROFILE_TEMPLATES.map((t) => (
            <button key={t.id} type="button" role="radio" aria-checked={f.template === t.id} onClick={() => set("template", t.id)}
              className={cn("rounded-xl border p-2 text-left text-xs transition",
                f.template === t.id ? "border-indigo-500 bg-indigo-500/10 ring-2 ring-indigo-500/30" : "border-slate-300 hover:border-indigo-400 dark:border-slate-700")}>
              <span className="block text-lg">{t.icon}</span>
              <span className="block font-bold text-slate-800 dark:text-slate-100">{t.name}</span>
              <span className="block text-[11px] leading-tight text-slate-500 dark:text-slate-400">{t.desc}</span>
            </button>
          ))}
        </div>
      </div>
      <div className="flex justify-end gap-2">
        {onCancel && <button type="button" onClick={onCancel} className="rounded-lg border border-slate-300 px-4 py-2 text-sm text-slate-600 dark:border-slate-700 dark:text-slate-300">Cancelar</button>}
        <button type="submit" className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-bold text-white hover:bg-indigo-500">Salvar perfil</button>
      </div>
    </form>
  );
}

/* ----------------------------- Vídeos ----------------------------- */

function VideosSection({ profile, isOwner, dark }) {
  const [filter, setFilter] = useState("all");
  const [platform, setPlatform] = useState("youtube");
  const [url, setUrl] = useState("");
  const [title, setTitle] = useState("");
  const [err, setErr] = useState("");
  const videos = profile.videos || [];
  const shown = filter === "all" ? videos : videos.filter((v) => v.platform === filter);
  const plat = PROFILE_PLATFORMS.find((p) => p.id === platform) || PROFILE_PLATFORMS[0];

  const add = (e) => {
    e.preventDefault();
    setErr("");
    if (!url.trim()) return setErr("Informe a URL do vídeo (ou faça upload em URL personalizada).");
    if (getEmbed(url.trim(), platform).kind === "invalid") return setErr(`A URL não é válida para ${plat.label}.`);
    const v = { id: uid(), platform, url: url.trim(), title: title.trim() || `Vídeo do ${plat.label}` };
    updateProfile(profile.id, { videos: [v, ...videos] });
    setUrl("");
    setTitle("");
    setFilter("all");
  };

  const remove = (id) => updateProfile(profile.id, { videos: videos.filter((v) => v.id !== id) });

  return (
    <div>
      {/* Alternar entre plataformas */}
      <div className="mb-4 flex flex-wrap gap-2" role="tablist" aria-label="Filtrar vídeos por plataforma">
        {[{ id: "all", label: "Todos", icon: "🎬" }, ...PROFILE_PLATFORMS].map((p) => {
          const n = p.id === "all" ? videos.length : videos.filter((v) => v.platform === p.id).length;
          return (
            <button key={p.id} type="button" role="tab" aria-selected={filter === p.id} onClick={() => setFilter(p.id)}
              className={cn("rounded-full px-3 py-1.5 text-xs font-semibold transition",
                filter === p.id ? "bg-indigo-600 text-white" : "border border-slate-300 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800")}>
              {p.icon} {p.label} <span className="opacity-70">({n})</span>
            </button>
          );
        })}
      </div>

      {isOwner && (
        <form onSubmit={add} className={cn("mb-6 space-y-3 rounded-2xl border p-4", dark ? "border-fuchsia-500/30 bg-slate-900" : "border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900")}>
          <p className="text-sm font-bold text-slate-800 dark:text-slate-100">➕ Adicionar vídeo</p>
          <div className="flex flex-wrap gap-2" role="radiogroup" aria-label="Plataforma do vídeo">
            {PROFILE_PLATFORMS.map((p) => (
              <button key={p.id} type="button" role="radio" aria-checked={platform === p.id} onClick={() => { setPlatform(p.id); setErr(""); }}
                className={cn("rounded-lg border px-2.5 py-1.5 text-xs font-semibold",
                  platform === p.id ? "border-indigo-500 bg-indigo-500/15 text-indigo-600 dark:text-indigo-300" : "border-slate-300 text-slate-500 dark:border-slate-700 dark:text-slate-400")}>
                {p.icon} {p.label}
              </button>
            ))}
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <input className={`${inputCls} min-w-0 flex-1`} value={url} onChange={(e) => setUrl(e.target.value)} placeholder={plat.placeholder} aria-label="URL do vídeo" />
          </div>
          <input className={inputCls} value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Título (opcional)" aria-label="Título do vídeo" />
          {err && <p role="alert" className="text-xs text-rose-500">{err}</p>}
          <button type="submit" className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-bold text-white hover:bg-indigo-500">Adicionar vídeo</button>
        </form>
      )}

      {shown.length === 0 ? (
        <p className="rounded-2xl border border-dashed border-slate-300 p-8 text-center text-sm text-slate-400 dark:border-slate-700">
          Nenhum vídeo {filter !== "all" ? "desta plataforma" : "ainda"}.
        </p>
      ) : (
        <div className="grid gap-5 md:grid-cols-2">
          {shown.map((v) => {
            const p = VIDEO_PLATFORMS.find((x) => x.id === v.platform);
            return (
              <figure key={v.id} className={cn("rounded-2xl border p-3", dark ? "border-fuchsia-500/30 bg-slate-900/80" : "border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900")}>
                <VideoEmbed url={v.url} platform={v.platform} title={v.title} />
                <figcaption className="mt-2 flex items-center gap-2 text-sm">
                  <span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs font-semibold text-slate-600 dark:bg-slate-800 dark:text-slate-300">{p?.icon} {p?.label}</span>
                  <span className="min-w-0 flex-1 truncate font-semibold text-slate-800 dark:text-slate-100">{v.title}</span>
                  {isOwner && (
                    <button type="button" onClick={() => remove(v.id)} className="text-xs text-rose-500 hover:underline" aria-label={`Remover vídeo ${v.title}`}>remover</button>
                  )}
                </figcaption>
              </figure>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ----------------------------- Lista de pessoas ----------------------------- */

function PeopleList({ people, empty, action }) {
  if (!people.length) return <p className="rounded-2xl border border-dashed border-slate-300 p-8 text-center text-sm text-slate-400 dark:border-slate-700">{empty}</p>;
  return (
    <ul className="grid gap-3 sm:grid-cols-2">
      {people.map((p) => (
        <li key={p.id} className="flex items-center gap-3 rounded-2xl border border-slate-200 bg-white p-3 dark:border-slate-800 dark:bg-slate-900">
          <button type="button" onClick={() => navigate(`/forum/u/${p.username}`)} className="flex min-w-0 flex-1 items-center gap-3 text-left">
            <Avatar profile={p} />
            <span className="min-w-0">
              <span className="block truncate text-sm font-bold text-slate-900 dark:text-white">{p.name}</span>
              <span className="block text-xs text-slate-400">@{p.username}</span>
            </span>
          </button>
          {action && action(p)}
        </li>
      ))}
    </ul>
  );
}

/* ----------------------------- Shop (lista de desejos) ----------------------------- */

function ShopSection({ profile, state, isOwner }) {
  const [sub, setSub] = useState("wishlist");
  const lojaOn = state.features?.loja !== false;
  const items = (profile.wishlist || [])
    .map((id) => (state.loja?.products || []).find((p) => p.id === id))
    .filter((p) => p && p.active);
  const affiliate = (p) => p.kind === "afiliado" && p.affiliateUrl;
  return (
    <div data-shop>
      {/* sub menu do Shop */}
      <div className="mb-4 flex flex-wrap items-center gap-2" role="tablist" aria-label="Shop">
        <button type="button" role="tab" aria-selected={sub === "wishlist"} onClick={() => setSub("wishlist")}
          className={cn("rounded-full px-3 py-1.5 text-xs font-semibold", sub === "wishlist" ? "bg-rose-500 text-white" : "border border-slate-300 text-slate-600 dark:border-slate-700 dark:text-slate-300")}>
          ❤️ Lista de desejos ({items.length})
        </button>
        {lojaOn && (
          <button type="button" onClick={() => navigate("/loja")} className="ml-auto text-xs font-semibold text-amber-600 hover:underline dark:text-amber-400">
            🛒 Ver loja →
          </button>
        )}
      </div>
      {!lojaOn ? (
        <p className="rounded-2xl border border-dashed border-slate-300 p-8 text-center text-sm text-slate-400 dark:border-slate-700">A loja está desabilitada no momento.</p>
      ) : items.length === 0 ? (
        <p className="rounded-2xl border border-dashed border-slate-300 p-8 text-center text-sm text-slate-400 dark:border-slate-700">
          Nenhum produto na lista de desejos.{isOwner ? " Toque no ❤️ dos produtos da loja para adicionar." : ""}
        </p>
      ) : (
        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3" data-wishlist>
          {items.map((p) => (
            <li key={p.id} className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900" data-wish-item={p.id}>
              {p.image ? <img src={p.image} alt={p.name} className="h-36 w-full object-cover" loading="lazy" /> : <div className="flex h-36 items-center justify-center bg-slate-100 text-4xl dark:bg-slate-800">📦</div>}
              <div className="p-3">
                <p className="truncate font-bold text-slate-900 dark:text-white">{p.name}</p>
                <p className="text-sm font-extrabold text-amber-600 dark:text-amber-400">{brl(p.price)}</p>
                <div className="mt-2 flex flex-wrap gap-2">
                  {affiliate(p) ? (
                    <a href={p.affiliateUrl} target="_blank" rel="noopener noreferrer sponsored nofollow" className="rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-emerald-500">
                      Comprar{p.affiliateStore ? ` na ${p.affiliateStore}` : ""} ↗
                    </a>
                  ) : (
                    <button type="button" onClick={() => navigate("/loja")} className="rounded-lg bg-slate-900 px-3 py-1.5 text-xs font-bold text-white hover:bg-amber-500 hover:text-slate-950 dark:bg-amber-500 dark:text-slate-950">
                      Ver na loja
                    </button>
                  )}
                  {isOwner && (
                    <button type="button" onClick={() => toggleWishlist(profile.id, p.id)} className="rounded-lg border border-rose-400/60 px-3 py-1.5 text-xs text-rose-500 hover:bg-rose-500/10" aria-label={`Remover ${p.name} da lista de desejos`}>
                      Remover
                    </button>
                  )}
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/* ----------------------------- Página ----------------------------- */

export default function ForumProfile({ state, username }) {
  const [tab, setTab] = useState("videos");
  const [editing, setEditing] = useState(false);

  if (state.features?.forum === false) return <NotFound state={state} />;
  const profiles = state.forum?.profiles || [];
  const profile = profiles.find((p) => p.username === username);
  if (!profile) return <NotFound state={state} />;

  const me = getMe(state);
  const isOwner = !!me && me.id === profile.id;
  const iFollow = !!me && me.following.includes(profile.id);
  const followers = profiles.filter((p) => p.following.includes(profile.id));
  const following = profiles.filter((p) => profile.following.includes(p.id));
  const topics = (state.forum?.topics || []).filter((t) => t.author === profile.name || t.author === profile.username);
  const tpl = PROFILE_TEMPLATES.some((t) => t.id === profile.template) ? profile.template : "classico";
  const dark = tpl === "neon";

  const followBtn = !me ? (
    <span className="text-xs text-slate-400">Escolha “Participar como” no fórum para seguir</span>
  ) : isOwner ? (
    <button type="button" onClick={() => setEditing((v) => !v)} className="rounded-xl bg-indigo-600 px-4 py-2 text-sm font-bold text-white hover:bg-indigo-500">
      ✏️ {editing ? "Fechar personalização" : "Personalizar perfil"}
    </button>
  ) : iFollow ? (
    <button type="button" onClick={() => unfollowUser(me.id, profile.id)}
      className="rounded-xl border border-slate-300 px-4 py-2 text-sm font-bold text-slate-700 hover:border-rose-400 hover:text-rose-500 dark:border-slate-600 dark:text-slate-200">
      ✓ Seguindo · deixar de seguir
    </button>
  ) : (
    <button type="button" onClick={() => followUser(me.id, profile.id)} className="rounded-xl bg-amber-500 px-4 py-2 text-sm font-bold text-slate-950 hover:bg-amber-400">
      ＋ Seguir
    </button>
  );

  const stats = (
    <div className="flex flex-wrap gap-2 text-sm">
      {[
        { id: "seguidores", n: followers.length, label: "seguidores" },
        { id: "seguindo", n: following.length, label: "seguindo" },
        { id: "videos", n: (profile.videos || []).length, label: "vídeos" },
        { id: "topicos", n: topics.length, label: "tópicos" },
      ].map((s) => (
        <button key={s.id} type="button" onClick={() => setTab(s.id)}
          className="rounded-lg px-2 py-1 hover:bg-slate-100 dark:hover:bg-slate-800">
          <strong className="text-slate-900 dark:text-white">{s.n}</strong> <span className="text-slate-500 dark:text-slate-400">{s.label}</span>
        </button>
      ))}
    </div>
  );

  const identity = (center = false) => (
    <div className={center ? "text-center" : ""}>
      <h1 className={cn("font-extrabold text-slate-900 dark:text-white", tpl === "minimal" ? "text-2xl font-light tracking-wide" : "text-3xl")}>{profile.name}</h1>
      <p className="text-sm text-slate-400">@{profile.username} · membro desde {formatDate(profile.createdAt)}</p>
      {profile.bio && <p className={cn("mt-2 max-w-xl text-slate-600 dark:text-slate-300", center && "mx-auto")}>{profile.bio}</p>}
    </div>
  );

  const tabs = (
    <div className="mb-5 flex flex-wrap gap-1 border-b border-slate-200 dark:border-slate-800" role="tablist" aria-label="Seções do perfil">
      {[
        { id: "videos", label: "🎬 Vídeos" },
        { id: "imagens", label: `🖼️ Imagens (${(profile.images || []).length})` },
        { id: "audios", label: `🎵 Áudios (${(profile.audios || []).length})` },
        { id: "seguidores", label: `👥 Seguidores (${followers.length})` },
        { id: "seguindo", label: `➡️ Seguindo (${following.length})` },
        { id: "topicos", label: `💬 Tópicos (${topics.length})` },
        { id: "shop", label: `🛍️ Shop (${(profile.wishlist || []).length})` },
      ].map((t) => (
        <button key={t.id} type="button" role="tab" aria-selected={tab === t.id} onClick={() => setTab(t.id)}
          className={cn("-mb-px border-b-2 px-3 py-2 text-sm font-semibold",
            tab === t.id ? "border-indigo-500 text-indigo-600 dark:text-indigo-300" : "border-transparent text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200")}>
          {t.label}
        </button>
      ))}
    </div>
  );

  const content = (
    <div>
      {editing && isOwner && (
        <div className="mb-6 rounded-2xl border border-indigo-500/40 bg-white p-5 dark:bg-slate-900">
          <h2 className="mb-3 text-lg font-bold text-slate-900 dark:text-white">✏️ Personalizar minha página</h2>
          <ProfileForm
            profile={profile}
            allProfiles={profiles}
            onCancel={() => setEditing(false)}
            onSaved={(data) => {
              updateProfile(profile.id, data);
              setEditing(false);
              if (data.username !== profile.username) navigate(`/forum/u/${data.username}`);
            }}
          />
        </div>
      )}
      {tabs}
      {tab === "videos" && <VideosSection profile={profile} isOwner={isOwner} dark={dark} />}
      {tab === "seguidores" && (
        <PeopleList
          people={followers}
          empty="Ainda sem seguidores."
          action={isOwner ? (p) => (
            <button type="button" onClick={() => removeFollower(profile.id, p.id)} className="rounded-lg border border-rose-400/50 px-2 py-1 text-xs text-rose-500 hover:bg-rose-500/10">
              Remover
            </button>
          ) : null}
        />
      )}
      {tab === "seguindo" && (
        <PeopleList
          people={following}
          empty="Não segue ninguém ainda."
          action={isOwner ? (p) => (
            <button type="button" onClick={() => unfollowUser(profile.id, p.id)} className="rounded-lg border border-slate-300 px-2 py-1 text-xs text-slate-600 hover:border-rose-400 hover:text-rose-500 dark:border-slate-600 dark:text-slate-300">
              Deixar de seguir
            </button>
          ) : null}
        />
      )}
      {tab === "imagens" && <ImagesSection profile={profile} isOwner={isOwner} />}
      {tab === "audios" && <AudiosSection profile={profile} isOwner={isOwner} />}
      {tab === "shop" && <ShopSection profile={profile} state={state} isOwner={isOwner} />}
      {tab === "topicos" && (
        topics.length === 0 ? (
          <p className="rounded-2xl border border-dashed border-slate-300 p-8 text-center text-sm text-slate-400 dark:border-slate-700">Nenhum tópico publicado.</p>
        ) : (
          <ul className="space-y-2">
            {topics.map((t) => (
              <li key={t.id}>
                <button type="button" onClick={() => navigate(`/forum/${t.id}`)} className="w-full rounded-xl border border-slate-200 bg-white p-3 text-left hover:border-indigo-400 dark:border-slate-800 dark:bg-slate-900">
                  <span className="block font-semibold text-slate-900 dark:text-white">{t.title}</span>
                  <span className="text-xs text-slate-400">{formatDate(t.createdAt)} · 💬 {t.replies.length}</span>
                </button>
              </li>
            ))}
          </ul>
        )
      )}
    </div>
  );

  const coverImg = (cls) =>
    profile.cover ? <img src={profile.cover} alt="" className={cn("w-full object-cover", cls)} />
      : <div className={cn("w-full bg-gradient-to-r from-indigo-500 via-violet-500 to-amber-400", cls)} />;

  let page;
  if (tpl === "moderno") {
    page = (
      <div className="mx-auto max-w-5xl px-4 py-8">
        <div className="overflow-hidden rounded-3xl shadow-lg">{coverImg("h-56 sm:h-72")}</div>
        <div className="-mt-20 flex flex-col items-center gap-3">
          <Avatar profile={profile} size="h-36 w-36 ring-8 ring-white dark:ring-slate-950 shadow-xl" />
          {identity(true)}
          {stats}
          {followBtn}
        </div>
        <div className="mt-8">{content}</div>
      </div>
    );
  } else if (tpl === "minimal") {
    page = (
      <div className="mx-auto max-w-2xl px-4 py-12">
        <div className="overflow-hidden rounded-xl opacity-80 grayscale">{coverImg("h-20")}</div>
        <div className="mt-8 flex flex-col items-center gap-3">
          <Avatar profile={profile} size="h-20 w-20" />
          {identity(true)}
          {stats}
          {followBtn}
        </div>
        <hr className="my-10 border-slate-200 dark:border-slate-800" />
        {content}
      </div>
    );
  } else if (tpl === "neon") {
    page = (
      <div className="dark">
        <div className="min-h-screen bg-slate-950 pb-12" style={{ backgroundImage: "radial-gradient(60% 50% at 20% 0%, rgba(217,70,239,.25), transparent 60%), radial-gradient(50% 40% at 90% 10%, rgba(34,211,238,.2), transparent 60%)" }}>
          <div className="mx-auto max-w-5xl px-4 pt-8">
            <div className="overflow-hidden rounded-3xl border border-fuchsia-500/40 shadow-[0_0_40px_rgba(217,70,239,.25)]">{coverImg("h-52 sm:h-64")}</div>
            <div className="-mt-14 flex flex-wrap items-end gap-5 px-4">
              <Avatar profile={profile} size="h-32 w-32 ring-4 ring-fuchsia-500 shadow-[0_0_30px_rgba(217,70,239,.7)]" />
              <div className="flex-1">{identity()}</div>
              {followBtn}
            </div>
            <div className="mt-4 px-4">{stats}</div>
            <div className="mt-8 rounded-3xl border border-cyan-400/20 bg-slate-900/60 p-5">{content}</div>
          </div>
        </div>
      </div>
    );
  } else if (tpl === "revista") {
    page = (
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-8 lg:grid-cols-[320px_1fr]">
        <aside className="h-fit overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900 lg:sticky lg:top-24">
          {coverImg("h-32")}
          <div className="-mt-12 flex flex-col items-center gap-3 p-5">
            <Avatar profile={profile} size="h-24 w-24 ring-4 ring-white dark:ring-slate-900" />
            {identity(true)}
            {stats}
            {followBtn}
          </div>
        </aside>
        <div>
          <p className="mb-2 font-serif text-xs uppercase tracking-[0.3em] text-amber-600">Edição pessoal</p>
          <h2 className="mb-6 font-serif text-4xl font-bold text-slate-900 dark:text-white">O mundo de {profile.name.split(" ")[0]}</h2>
          {content}
        </div>
      </div>
    );
  } else {
    // clássico
    page = (
      <div>
        {coverImg("h-56 sm:h-64")}
        <div className="mx-auto max-w-5xl px-4">
          <div className="-mt-16 flex flex-wrap items-end gap-5">
            <Avatar profile={profile} size="h-32 w-32 ring-4 ring-white dark:ring-slate-950" />
            <div className="flex-1 pb-2">{identity()}</div>
            <div className="pb-2">{followBtn}</div>
          </div>
          <div className="mt-3">{stats}</div>
          <div className="mt-8 pb-12">{content}</div>
        </div>
      </div>
    );
  }

  return (
    <PublicLayout state={state}>
      <div data-profile-template={tpl}>
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 pt-4 text-sm">
          <button type="button" onClick={() => navigate("/forum")} className="text-slate-400 hover:text-amber-600">← Fórum</button>
          {me && !isOwner && (
            <span className="text-xs text-slate-400">participando como <strong>{me.name}</strong> · <button type="button" className="underline" onClick={() => setMeId("")}>sair</button></span>
          )}
        </div>
        {page}
      </div>
    </PublicLayout>
  );
}
