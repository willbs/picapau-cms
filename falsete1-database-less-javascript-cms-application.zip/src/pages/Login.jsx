// Página de login oculta e elegante — rota /login (também pelo botão "Acesso" no rodapé).
// Visual minimalista com referência à IA: fundo escuro, rede neural animada em canvas,
// ícone abstrato de átomo/nós e microanimações suaves. Rota marcada como noindex.
// Inclui "Esqueci a senha" (gera link de redefinição — modo demo, sem servidor de e-mail)
// e "Criar conta" (só quando habilitado na sessão Segurança do painel).
import { useEffect, useRef, useState } from "react";
import {
  authenticate,
  createSession,
  registerFailure,
  registerSuccess,
  getProtectionStatus,
  addLog,
  isAuthenticated,
  createResetToken,
  resetUrl,
  getCurrentUser,
  homeFor,
} from "../auth.js";
import { sendConfirmation } from "./Register.jsx";
import { useCmsState } from "../store.js";
import { smtpReady, sendMail, resetPasswordEmail } from "../mailer.js";
import { navigate } from "../router.js";

/** Canvas com partículas de "rede neural" conectadas por linhas. */
function NeuralCanvas() {
  const ref = useRef(null);

  useEffect(() => {
    const canvas = ref.current;
    const ctx = canvas.getContext("2d");
    if (!ctx || !window.requestAnimationFrame) return undefined; // ambiente sem canvas 2D
    let raf = 0;
    let w = 0;
    let h = 0;
    const N = 64;
    const pts = [];

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = canvas.offsetWidth;
      h = canvas.offsetHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener("resize", resize);

    for (let i = 0; i < N; i++) {
      pts.push({
        x: Math.random() * w,
        y: Math.random() * h,
        vx: (Math.random() - 0.5) * 0.35,
        vy: (Math.random() - 0.5) * 0.35,
        r: Math.random() * 1.7 + 0.7,
      });
    }

    const draw = () => {
      ctx.clearRect(0, 0, w, h);
      for (let i = 0; i < pts.length; i++) {
        const p = pts[i];
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < 0 || p.x > w) p.vx *= -1;
        if (p.y < 0 || p.y > h) p.vy *= -1;
        for (let j = i + 1; j < pts.length; j++) {
          const q = pts[j];
          const dx = p.x - q.x;
          const dy = p.y - q.y;
          const d = Math.hypot(dx, dy);
          if (d < 140) {
            ctx.strokeStyle = `rgba(129, 140, 248, ${(1 - d / 140) * 0.32})`;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(q.x, q.y);
            ctx.stroke();
          }
        }
        ctx.fillStyle = "rgba(165, 180, 252, 0.85)";
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      }
      raf = requestAnimationFrame(draw);
    };
    draw();

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return <canvas ref={ref} className="neural-canvas" aria-hidden="true" />;
}

/** Ícone abstrato de átomo / nó de rede neural. */
function AtomIcon() {
  return (
    <svg viewBox="0 0 64 64" className="animate-float-slow h-14 w-14" fill="none" aria-hidden="true">
      <defs>
        <linearGradient id="lg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#818cf8" />
          <stop offset="1" stopColor="#c084fc" />
        </linearGradient>
      </defs>
      <g stroke="url(#lg)" strokeWidth="1.6">
        <ellipse cx="32" cy="32" rx="26" ry="10.5" />
        <ellipse cx="32" cy="32" rx="26" ry="10.5" transform="rotate(60 32 32)" />
        <ellipse cx="32" cy="32" rx="26" ry="10.5" transform="rotate(120 32 32)" />
      </g>
      <circle cx="32" cy="32" r="5.5" fill="url(#lg)" className="animate-glow-pulse" />
      <circle cx="32" cy="6" r="2.4" fill="#a5b4fc" />
      <circle cx="54.5" cy="45" r="2.4" fill="#c084fc" />
      <circle cx="9.5" cy="45" r="2.4" fill="#818cf8" />
    </svg>
  );
}

export default function Login() {
  const state = useCmsState();
  const [mode, setMode] = useState("login"); // "login" | "forgot"
  const [user, setUser] = useState("");
  const [pass, setPass] = useState("");
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [loading, setLoading] = useState(false);
  const [protection, setProtection] = useState(() => getProtectionStatus());
  // "Esqueci a senha"
  const [forgotEmail, setForgotEmail] = useState("");
  const [forgotMsg, setForgotMsg] = useState("");
  const [resetLink, setResetLink] = useState("");
  const [forgotLoading, setForgotLoading] = useState(false);
  const [unverified, setUnverified] = useState(null); // usuário com e-mail ainda não confirmado
  const [resend, setResend] = useState(null);

  const allowRegistration = state.security.allowRegistration === true;

  useEffect(() => {
    // Se já existe sessão válida: administrador vai ao painel; editor fica no site.
    if (isAuthenticated()) navigate(homeFor(getCurrentUser()));
    // Recarrega o status de proteção a cada 5s (contagem regressiva do bloqueio).
    const iv = setInterval(() => setProtection(getProtectionStatus()), 5000);
    return () => clearInterval(iv);
  }, []);

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    setInfo("");
    const prot = getProtectionStatus();
    setProtection(prot);
    if (prot.locked) {
      setError(`Muitas tentativas. Aguarde ${Math.ceil(prot.lockRemaining / 60)} min para tentar novamente.`);
      return;
    }
    if (prot.limited) {
      setInfo(`Limite de tentativas atingido — aguarde ${prot.limitRemaining}s.`);
      return;
    }
    if (!user || !pass) {
      setError("Preencha e-mail e senha.");
      return;
    }
    setLoading(true);
    // Pequeno atraso proposital para dificultar força bruta automatizada.
    await new Promise((r) => setTimeout(r, 450));
    const loggedUser = await authenticate(user, pass);
    setLoading(false);
    setUnverified(null);
    setResend(null);
    if (loggedUser && loggedUser.emailVerified === false) {
      // senha correta, mas o e-mail ainda não foi confirmado
      addLog("falha", `Login bloqueado — e-mail não confirmado (${loggedUser.email})`);
      setUnverified(loggedUser);
      setError("Confirme seu e-mail antes de entrar: abra o link que enviamos para o seu endereço.");
      return;
    }
    if (loggedUser) {
      registerSuccess();
      createSession(loggedUser);
      addLog("login", `Login bem-sucedido (${loggedUser.email}, ${loggedUser.role})`);
      navigate(homeFor(loggedUser)); // editores: só o site (front-end); administradores: painel
    } else {
      registerFailure();
      setProtection(getProtectionStatus());
      addLog("falha", `Tentativa de login malsucedida (${user || "—"})`);
      setError("E-mail ou senha incorretos.");
    }
  };

  const submitForgot = async (e) => {
    e.preventDefault();
    setForgotMsg("");
    setResetLink("");
    if (!forgotEmail.trim()) {
      setForgotMsg("Informe o e-mail cadastrado.");
      return;
    }
    setForgotLoading(true);
    await new Promise((r) => setTimeout(r, 600)); // simula envio do e-mail
    const token = createResetToken(forgotEmail.trim());
    if (smtpReady()) {
      // SMTP configurado: envia o link por e-mail (nunca mostra o link na tela)
      if (token) {
        try {
          const m = resetPasswordEmail(resetUrl(token));
          await sendMail({ to: forgotEmail.trim(), subject: m.subject, html: m.html, kind: "redefinição de senha" });
        } catch (e) {
          setForgotLoading(false);
          setForgotMsg(`Não foi possível enviar o e-mail agora (${e.message}). Tente novamente mais tarde.`);
          return;
        }
      }
      setForgotLoading(false);
      // mesma mensagem para e-mails cadastrados ou não (não revela quem tem conta)
      setForgotMsg(`✉️ Se ${forgotEmail.trim()} estiver cadastrado, enviamos um link de redefinição (válido por 30 minutos). Verifique a caixa de entrada e o spam.`);
      return;
    }
    setForgotLoading(false);
    if (token) {
      // Sem servidor de e-mail real: o "e-mail enviado" é exibido aqui (modo demo).
      setResetLink(resetUrl(token));
      setForgotMsg(`✉️ Enviamos um link de redefinição para ${forgotEmail.trim()} (simulado — como não há servidor de e-mail neste CMS local, o link aparece abaixo). Válido por 30 minutos.`);
    } else {
      // Não revela se o e-mail existe ou não.
      setForgotMsg("Se este e-mail estiver cadastrado, enviamos um link de redefinição (válido por 30 min).");
    }
  };

  const inputCls =
    "w-full rounded-xl border border-slate-700/60 bg-slate-900/70 px-4 py-3 text-sm text-slate-100 placeholder-slate-500 outline-none transition focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/30";

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#070b18] px-4 py-10">
      {/* Fundo: gradiente + rede neural animada */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(70% 90% at 50% 0%, rgba(99,102,241,.16), transparent 60%), radial-gradient(50% 60% at 85% 90%, rgba(192,132,252,.10), transparent 60%), linear-gradient(180deg, #070b18 0%, #0a1024 100%)",
        }}
        aria-hidden="true"
      />
      <NeuralCanvas />
      <div
        className="pointer-events-none absolute inset-0"
        style={{ background: "linear-gradient(180deg, transparent 60%, rgba(7,11,24,.9))" }}
        aria-hidden="true"
      />

      <div className="animate-fade-up relative w-full max-w-md">
        <div className="glass-dark rounded-3xl p-8 shadow-2xl shadow-indigo-950/50">
          <div className="flex flex-col items-center text-center">
            <AtomIcon />
            <h1 className="mt-4 text-2xl font-bold tracking-tight text-white">
              {state.branding?.siteName || "Pica-Pau"}
            </h1>
            <p className="mt-1 text-sm text-slate-400">
              {mode === "login" ? "Área restrita · inteligência do conteúdo" : "Recuperar acesso"}
            </p>
          </div>

          {mode === "login" ? (
            <form onSubmit={submit} className="mt-8 space-y-4" noValidate>
              <div>
                <label htmlFor="login-user" className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400">
                  E-mail
                </label>
                <input
                  id="login-user"
                  type="email"
                  autoComplete="username"
                  className={inputCls}
                  value={user}
                  onChange={(e) => setUser(e.target.value)}
                  placeholder="seu e-mail de acesso"
                  autoFocus
                />
              </div>
              <div>
                <div className="mb-1.5 flex items-center justify-between">
                  <label htmlFor="login-pass" className="block text-xs font-semibold uppercase tracking-wider text-slate-400">
                    Senha
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setMode("forgot");
                      setError("");
                      setInfo("");
                      setForgotMsg("");
                      setResetLink("");
                      setForgotEmail(user);
                    }}
                    className="text-xs text-indigo-400 transition hover:text-indigo-300"
                  >
                    Esqueci a senha
                  </button>
                </div>
                <input
                  id="login-pass"
                  type="password"
                  autoComplete="current-password"
                  className={inputCls}
                  value={pass}
                  onChange={(e) => setPass(e.target.value)}
                  placeholder="••••••••"
                />
              </div>

              {error && (
                <p role="alert" className="animate-fade-up rounded-lg border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-sm text-rose-300">
                  {error}
                </p>
              )}
              {unverified && (
                <div className="rounded-lg border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-sm text-amber-200" data-unverified>
                  <button type="button" className="font-semibold underline"
                    onClick={async () => { setResend({ mode: "sending" }); setResend(await sendConfirmation(unverified)); }}>
                    Reenviar e-mail de confirmação
                  </button>
                  {resend?.mode === "sending" && <span className="ml-2">enviando…</span>}
                  {resend?.mode === "email" && <p className="mt-1">✉️ Novo link enviado para {unverified.email}.</p>}
                  {resend?.mode === "error" && <p className="mt-1 text-rose-300">Falha ao enviar: {resend.error}</p>}
                  {resend?.mode === "demo" && (
                    <a href={resend.link} className="mt-1 block break-all text-xs text-emerald-300 underline" data-confirm-link
                      onClick={(e) => { e.preventDefault(); navigate(`/login/confirmar/${resend.link.split("/confirmar/")[1]}`); }}>
                      {resend.link}
                    </a>
                  )}
                </div>
              )}
              {info && !error && (
                <p role="status" className="animate-fade-up rounded-lg border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-sm text-amber-300">
                  {info}
                </p>
              )}
              {protection.fails > 0 && !protection.locked && (
                <p className="text-xs text-slate-500">
                  Tentativas malsucedidas nesta janela: {protection.fails}/5
                </p>
              )}

              <button
                type="submit"
                disabled={loading || protection.locked}
                className="group relative w-full overflow-hidden rounded-xl bg-gradient-to-r from-indigo-500 to-violet-500 px-4 py-3 text-sm font-semibold text-white shadow-lg shadow-indigo-500/30 transition hover:from-indigo-400 hover:to-violet-400 disabled:cursor-not-allowed disabled:opacity-50"
              >
                <span className="relative z-10">{loading ? "Verificando…" : "Entrar"}</span>
                <span
                  className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/20 to-transparent transition-transform duration-700 group-hover:translate-x-full"
                  aria-hidden="true"
                />
              </button>

              {allowRegistration && (
                <p className="text-center text-xs text-slate-500">
                  Não tem conta?{" "}
                  <button type="button" onClick={() => navigate("/login/registrar")} className="font-semibold text-emerald-400 transition hover:text-emerald-300">
                    Criar conta
                  </button>
                </p>
              )}
            </form>
          ) : (
            /* ------------------ Esqueci a senha ------------------ */
            <form onSubmit={submitForgot} className="mt-8 space-y-4" noValidate>
              <p className="text-sm text-slate-400">
                Informe o e-mail cadastrado para receber um link de redefinição de senha.
              </p>
              <div>
                <label htmlFor="forgot-email" className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400">
                  E-mail cadastrado
                </label>
                <input
                  id="forgot-email"
                  type="email"
                  autoComplete="email"
                  className={inputCls}
                  value={forgotEmail}
                  onChange={(e) => setForgotEmail(e.target.value)}
                  placeholder="voce@exemplo.com"
                  autoFocus
                />
              </div>
              {forgotMsg && (
                <div role="status" className="animate-fade-up rounded-lg border border-indigo-500/30 bg-indigo-500/10 px-3 py-2 text-sm text-indigo-200">
                  {forgotMsg}
                </div>
              )}
              {resetLink && (
                <div className="animate-fade-up rounded-xl border border-emerald-500/40 bg-emerald-500/10 p-3">
                  <p className="text-xs font-semibold uppercase tracking-wide text-emerald-300">
                    ✉️ E-mail enviado (modo demo — copie o link)
                  </p>
                  <a
                    href={resetLink}
                    onClick={(e) => {
                      e.preventDefault();
                      navigate(`#/login/redefinir/${resetLink.split("/redefinir/")[1]}`);
                    }}
                    className="mt-1 block break-all text-xs text-emerald-300 underline hover:text-emerald-200"
                  >
                    {resetLink}
                  </a>
                </div>
              )}
              <button
                type="submit"
                disabled={forgotLoading}
                className="w-full rounded-xl bg-gradient-to-r from-indigo-500 to-violet-500 px-4 py-3 text-sm font-semibold text-white shadow-lg shadow-indigo-500/30 transition hover:from-indigo-400 hover:to-violet-400 disabled:opacity-50"
              >
                {forgotLoading ? "Enviando…" : "Enviar link de redefinição"}
              </button>
              <button
                type="button"
                onClick={() => setMode("login")}
                className="w-full text-center text-xs text-slate-500 transition hover:text-slate-300"
              >
                ← Voltar ao acesso
              </button>
            </form>
          )}

          <div className="mt-6 flex items-center justify-between text-xs text-slate-500">
            <button
              type="button"
              onClick={() => navigate("/")}
              className="transition hover:text-slate-300"
            >
              ← Voltar ao site
            </button>
            <span className="inline-flex items-center gap-1.5">
              <span className="h-1.5 w-1.5 animate-glow-pulse rounded-full bg-emerald-400" aria-hidden="true" />
              protegido por hash SHA-256
            </span>
          </div>
        </div>
        <p className="mt-4 text-center text-xs text-slate-600">
          Acesso monitorado · rate limit e bloqueio por tentativas ativos
        </p>
      </div>
    </div>
  );
}
