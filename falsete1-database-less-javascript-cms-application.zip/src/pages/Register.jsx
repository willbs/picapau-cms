// Criação de conta pública (/login/registrar) — só fica disponível quando a opção
// "Criação de novas contas" está LIGADA na sessão Segurança.
// Novos usuários entram como "editor" (acesso apenas ao site/front-end, sem painel)
// e precisam CONFIRMAR O E-MAIL pelo link enviado antes de conseguir entrar.
import { useState } from "react";
import { createUser, createVerifyToken, verifyUrl, addLog, getCurrentUser, homeFor } from "../auth.js";
import { navigate } from "../router.js";
import { smtpReady, smtpConfig, sendMail, confirmEmail, newAccountAdminEmail } from "../mailer.js";
import { loadState } from "../store.js";

/** Envia (ou, sem SMTP, devolve para exibir) o link de confirmação. Retorna { mode, link?, error? }. */
export async function sendConfirmation(user) {
  const link = verifyUrl(createVerifyToken(user.id));
  if (!smtpReady()) return { mode: "demo", link };
  try {
    const m = confirmEmail(link);
    await sendMail({ to: user.email, subject: m.subject, html: m.html, kind: "confirmação de e-mail" });
    return { mode: "email" };
  } catch (e) {
    return { mode: "error", error: e.message };
  }
}

export default function Register() {
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [pass2, setPass2] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(null); // { mode, email, link?, error? }

  const current = getCurrentUser();
  if (current) navigate(homeFor(current));

  const inputCls =
    "w-full rounded-xl border border-slate-700/60 bg-slate-900/70 px-4 py-3 text-sm text-slate-100 placeholder-slate-500 outline-none transition focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/30";

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    if (pass !== pass2) return setError("As senhas não coincidem.");
    setLoading(true);
    const res = await createUser({ email, password: pass, role: "editor", active: true, verified: false });
    if (!res.ok) {
      setLoading(false);
      return setError(res.error || "Não foi possível criar a conta.");
    }
    addLog("seguranca", `Conta criada (aguardando confirmação de e-mail): ${res.user.email} (editor)`);
    const r = await sendConfirmation(res.user);
    // aviso ao administrador (em segundo plano)
    if (smtpReady()) {
      const cfg = smtpConfig(loadState());
      if (cfg.adminEmail && cfg.notifyNewAccounts) {
        const a = newAccountAdminEmail(res.user.email);
        sendMail({ to: cfg.adminEmail, subject: a.subject, html: a.html, kind: "aviso de nova conta" }).catch(() => {});
      }
    }
    setLoading(false);
    setDone({ ...r, email: res.user.email });
  };

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#070b18] px-4 py-10">
      <div className="pointer-events-none absolute inset-0"
        style={{ background: "radial-gradient(70% 90% at 50% 0%, rgba(16,185,129,.14), transparent 60%), linear-gradient(180deg, #070b18 0%, #0a1024 100%)" }}
        aria-hidden="true" />
      <div className="animate-fade-up relative w-full max-w-md">
        <div className="glass-dark rounded-3xl p-8 shadow-2xl shadow-emerald-950/40">
          {done ? (
            <div className="text-center" data-register-done={done.mode}>
              <span className="text-5xl" aria-hidden="true">{done.mode === "error" ? "⚠️" : "📬"}</span>
              <h1 className="mt-3 text-2xl font-bold text-white">Confirme seu e-mail</h1>
              {done.mode === "email" && (
                <p className="mt-3 text-sm text-slate-300">
                  Conta criada! Enviamos um link de confirmação para <strong>{done.email}</strong>. Abra o e-mail e clique no link para poder entrar no site.
                </p>
              )}
              {done.mode === "demo" && (
                <>
                  <p className="mt-3 text-sm text-slate-300">
                    Conta criada! O envio de e-mails (SMTP) não está configurado, então o link de confirmação de <strong>{done.email}</strong> aparece abaixo (modo demonstração).
                  </p>
                  <a href={done.link} onClick={(e) => { e.preventDefault(); navigate(`/login/confirmar/${done.link.split("/confirmar/")[1]}`); }}
                    className="mt-4 block break-all rounded-xl border border-emerald-500/40 bg-emerald-500/10 p-3 text-xs text-emerald-300 underline" data-confirm-link>
                    {done.link}
                  </a>
                </>
              )}
              {done.mode === "error" && (
                <p className="mt-3 text-sm text-rose-300">
                  Conta criada, mas não foi possível enviar o e-mail de confirmação agora ({done.error}). Tente entrar mais tarde para receber um novo link.
                </p>
              )}
              <button type="button" onClick={() => navigate("/login")}
                className="mt-6 w-full rounded-xl bg-gradient-to-r from-indigo-500 to-violet-500 px-4 py-3 text-sm font-semibold text-white">
                Ir para o login
              </button>
            </div>
          ) : (
            <>
              <div className="text-center">
                <span className="text-4xl" aria-hidden="true">✨</span>
                <h1 className="mt-3 text-2xl font-bold tracking-tight text-white">Criar conta</h1>
                <p className="mt-1 text-sm text-slate-400">Você receberá um e-mail para confirmar a conta antes de entrar.</p>
              </div>
              <form onSubmit={submit} className="mt-8 space-y-4" noValidate>
                <div>
                  <label htmlFor="rg-email" className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400">E-mail</label>
                  <input id="rg-email" type="email" autoComplete="email" className={inputCls} value={email} onChange={(e) => setEmail(e.target.value)} placeholder="voce@exemplo.com" required autoFocus />
                </div>
                <div>
                  <label htmlFor="rg-pass" className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400">Senha</label>
                  <input id="rg-pass" type="password" autoComplete="new-password" className={inputCls} value={pass} onChange={(e) => setPass(e.target.value)} placeholder="mínimo 6 caracteres" required minLength={6} />
                </div>
                <div>
                  <label htmlFor="rg-pass2" className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400">Confirmar senha</label>
                  <input id="rg-pass2" type="password" autoComplete="new-password" className={inputCls} value={pass2} onChange={(e) => setPass2(e.target.value)} placeholder="repita a senha" required />
                </div>
                {error && <p role="alert" className="rounded-lg border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-sm text-rose-300">{error}</p>}
                <button type="submit" disabled={loading}
                  className="w-full rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 px-4 py-3 text-sm font-semibold text-white shadow-lg shadow-emerald-500/25 transition hover:from-emerald-400 hover:to-teal-400 disabled:opacity-50">
                  {loading ? "Criando…" : "Criar conta"}
                </button>
                <p className="text-center text-xs text-slate-500">
                  Já tem conta?{" "}
                  <button type="button" onClick={() => navigate("/login")} className="text-indigo-400 hover:text-indigo-300">Fazer login</button>
                </p>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
