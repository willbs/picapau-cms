// Página inicial no modelo Revista Digital (Painel → Tema).
// 10 modelos visuais + blocos que podem ser adicionados/retirados/reordenados,
// com categorias e postagens em destaque escolhidas no painel.
import { useRef } from "react";
import PublicLayout from "../components/Layout.jsx";
import { navigate } from "../router.js";
import { articlePath } from "../permalink.js";
import { cn, formatDate, readingTime, TYPE_ICONS } from "../utils.js";
import { brl } from "./Loja.jsx";

/* ============================ catálogo ============================ */

export const MAG_TEMPLATES = [
  { id: "manchete", name: "Manchete", desc: "Grande manchete com 3 chamadas laterais e cards clássicos.", hero: "split", card: "stack", bg: "bg-white dark:bg-slate-950", accent: "text-amber-600 dark:text-amber-400", bar: "bg-amber-500", head: "font-extrabold", thumb: "#f59e0b" },
  { id: "classica", name: "Grade clássica", desc: "Capa em tela cheia, títulos com serifa e grade elegante.", hero: "full", card: "stack", bg: "bg-stone-50 dark:bg-slate-950", accent: "text-red-700 dark:text-red-400", bar: "bg-red-700", head: "font-serif font-bold", thumb: "#b91c1c" },
  { id: "mosaico", name: "Mosaico", desc: "Destaques em mosaico (bento) com imagens sobrepostas.", hero: "mosaic", card: "overlay", bg: "bg-white dark:bg-slate-950", accent: "text-indigo-600 dark:text-indigo-400", bar: "bg-indigo-600", head: "font-black tracking-tight", thumb: "#4f46e5" },
  { id: "noturna", name: "Edição noturna", desc: "Visual escuro de revista, destaques neon e cards sobrepostos.", hero: "split", card: "overlay", bg: "bg-slate-950", accent: "text-fuchsia-400", bar: "bg-fuchsia-500", head: "font-extrabold", dark: true, thumb: "#a21caf" },
  { id: "minimalista", name: "Minimalista", desc: "Lista tipográfica numerada, muito respiro, sem excessos.", hero: "list", card: "minimal", bg: "bg-white dark:bg-slate-950", accent: "text-slate-900 dark:text-white", bar: "bg-slate-900 dark:bg-white", head: "font-light tracking-tight", thumb: "#0f172a" },
  { id: "carrossel", name: "Carrossel", desc: "Destaques em carrossel deslizante no topo da página.", hero: "slider", card: "stack", bg: "bg-slate-50 dark:bg-slate-950", accent: "text-sky-600 dark:text-sky-400", bar: "bg-sky-500", head: "font-extrabold", thumb: "#0284c7" },
  { id: "jornal", name: "Jornal", desc: "Cabeçalho de jornal impresso, papel creme e colunas.", hero: "masthead", card: "minimal", bg: "bg-[#f7f3ea] dark:bg-slate-950", accent: "text-black dark:text-white", bar: "bg-black dark:bg-white", head: "font-serif font-black", serif: true, thumb: "#1c1917" },
  { id: "tech", name: "Tech", desc: "Gradientes escuros, mosaico e detalhes em ciano.", hero: "mosaic", card: "overlay", bg: "bg-gradient-to-b from-slate-950 to-indigo-950", accent: "text-cyan-400", bar: "bg-cyan-400", head: "font-black tracking-tight", dark: true, thumb: "#06b6d4" },
  { id: "lifestyle", name: "Lifestyle", desc: "Imagens grandes e arredondadas, tons pastel.", hero: "full", card: "rounded", bg: "bg-rose-50 dark:bg-slate-950", accent: "text-rose-600 dark:text-rose-300", bar: "bg-rose-400", head: "font-serif font-semibold", thumb: "#fb7185" },
  { id: "portal", name: "Portal", desc: "Portal de notícias denso, com barra lateral de mais lidos.", hero: "split", card: "horizontal", bg: "bg-white dark:bg-slate-950", accent: "text-emerald-700 dark:text-emerald-400", bar: "bg-emerald-600", head: "font-extrabold", sidebar: true, thumb: "#059669" },
];

export const BLOCK_TYPES = [
  { id: "hero", label: "Destaque principal (capa)" },
  { id: "destaques", label: "Postagens em destaque" },
  { id: "categorias", label: "Categorias em destaque" },
  { id: "ultimos", label: "Últimas postagens" },
  { id: "porCategoria", label: "Seções por categoria" },
  { id: "maisLidos", label: "Mais lidos" },
  { id: "videos", label: "Vídeos" },
  { id: "audios", label: "Podcasts e áudios" },
  { id: "loja", label: "Vitrine da loja" },
  { id: "forum", label: "Do fórum" },
];

export const DEFAULT_THEME = {
  template: "original",
  blocks: BLOCK_TYPES.map((b) => ({ id: b.id, enabled: !["loja", "forum"].includes(b.id) })),
  featuredCategories: [],
  featuredArticles: [],
};

export function themeConfig(state) {
  const t = state.theme || {};
  const known = new Set(BLOCK_TYPES.map((b) => b.id));
  const blocks = (t.blocks || DEFAULT_THEME.blocks).filter((b) => known.has(b.id));
  BLOCK_TYPES.forEach((b) => { if (!blocks.some((x) => x.id === b.id)) blocks.push({ id: b.id, enabled: false }); });
  return { ...DEFAULT_THEME, ...t, blocks };
}

/* ============================ peças ============================ */

const go = (to) => (e) => { e.preventDefault(); navigate(to); };

function CatTag({ a, state, skin, light }) {
  const c = (state.categories || []).find((x) => x.slug === (a.categories || [])[0]);
  if (!c) return null;
  return (
    <span className={cn("text-[11px] font-bold uppercase tracking-wider", light ? "text-white/90" : skin.accent)}>
      {c.icon} {c.name}
    </span>
  );
}

function Meta({ a, light }) {
  return (
    <span className={cn("text-xs", light ? "text-white/75" : "text-slate-500 dark:text-slate-400")}>
      {formatDate(a.date)} · {readingTime(a.content)}
    </span>
  );
}

function Img({ a, className }) {
  return a.cover ? (
    <img src={a.cover} alt="" loading="lazy" className={cn("object-cover", className)} />
  ) : (
    <span className={cn("flex items-center justify-center bg-slate-200 text-4xl dark:bg-slate-800", className)} aria-hidden="true">{TYPE_ICONS[a.type]}</span>
  );
}

/** Card de postagem (5 estilos). */
function Card({ a, state, skin, big = false }) {
  const href = articlePath(a, state);
  const title = cn(skin.head, "leading-snug text-slate-900 group-hover:underline dark:text-white", big ? "text-2xl" : "text-lg");
  if (skin.card === "overlay") {
    return (
      <a href={href} onClick={go(href)} className={cn("group relative block overflow-hidden rounded-2xl", big ? "min-h-80" : "min-h-56")} data-mag-card>
        <Img a={a} className="absolute inset-0 h-full w-full transition-transform duration-500 group-hover:scale-105" />
        <span className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent" />
        <span className="absolute inset-x-0 bottom-0 flex flex-col gap-1 p-4">
          <CatTag a={a} state={state} skin={skin} light />
          <span className={cn(skin.head, "leading-snug text-white group-hover:underline", big ? "text-3xl" : "text-lg")}>{a.title}</span>
          <Meta a={a} light />
        </span>
      </a>
    );
  }
  if (skin.card === "horizontal") {
    return (
      <a href={href} onClick={go(href)} className="group flex gap-4 border-b border-slate-200 pb-4 dark:border-slate-800" data-mag-card>
        <Img a={a} className="h-24 w-32 shrink-0 rounded-lg" />
        <span className="flex min-w-0 flex-col gap-1">
          <CatTag a={a} state={state} skin={skin} />
          <span className={cn(skin.head, "line-clamp-2 text-base leading-snug text-slate-900 group-hover:underline dark:text-white")}>{a.title}</span>
          <Meta a={a} />
        </span>
      </a>
    );
  }
  if (skin.card === "minimal") {
    return (
      <a href={href} onClick={go(href)} className="group block border-t border-slate-300 pt-4 dark:border-slate-700" data-mag-card>
        <CatTag a={a} state={state} skin={skin} />
        <span className={cn("mt-1 block", title)}>{a.title}</span>
        <span className="mt-2 line-clamp-3 block text-sm leading-relaxed text-slate-600 dark:text-slate-400">{a.excerpt}</span>
        <span className="mt-2 block"><Meta a={a} /></span>
      </a>
    );
  }
  const rounded = skin.card === "rounded";
  return (
    <a href={href} onClick={go(href)} className="group block" data-mag-card>
      <span className={cn("block overflow-hidden", rounded ? "rounded-[2rem]" : "rounded-xl")}>
        <Img a={a} className={cn("w-full transition-transform duration-500 group-hover:scale-105", big ? "h-72" : "h-48")} />
      </span>
      <span className="mt-3 flex flex-col gap-1">
        <CatTag a={a} state={state} skin={skin} />
        <span className={title}>{a.title}</span>
        <span className="line-clamp-2 text-sm text-slate-600 dark:text-slate-400">{a.excerpt}</span>
        <Meta a={a} />
      </span>
    </a>
  );
}

function SectionTitle({ skin, children, to }) {
  return (
    <div className={cn("mb-5 flex items-end justify-between gap-3", skin.serif && "border-b-4 border-double border-black pb-2 dark:border-white")}>
      <h2 className={cn(skin.head, "flex items-center gap-3 text-2xl text-slate-900 dark:text-white", skin.serif && "uppercase")}>
        {!skin.serif && <span className={cn("h-6 w-1.5 rounded-full", skin.bar)} aria-hidden="true" />}
        {children}
      </h2>
      {to && (
        <a href={to} onClick={go(to)} className={cn("text-sm font-semibold hover:underline", skin.accent)}>Ver tudo →</a>
      )}
    </div>
  );
}

/* ============================ destaque principal (6 estilos) ============================ */

function Hero({ items, state, skin }) {
  const sliderRef = useRef(null);
  if (!items.length) return null;
  const [lead, ...rest] = items;
  if (skin.hero === "full") {
    const href = articlePath(lead, state);
    return (
      <a href={href} onClick={go(href)} className="group relative block min-h-[60vh] overflow-hidden rounded-3xl" data-mag-hero="full">
        <Img a={lead} className="absolute inset-0 h-full w-full transition-transform duration-700 group-hover:scale-105" />
        <span className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent" />
        <span className="absolute inset-x-0 bottom-0 max-w-3xl p-8 sm:p-12">
          <CatTag a={lead} state={state} skin={skin} light />
          <span className={cn(skin.head, "mt-2 block text-4xl leading-tight text-white sm:text-5xl")}>{lead.title}</span>
          <span className="mt-3 block text-lg text-white/85">{lead.excerpt}</span>
        </span>
      </a>
    );
  }
  if (skin.hero === "mosaic") {
    return (
      <div className="grid gap-4 md:grid-cols-4 md:grid-rows-2" data-mag-hero="mosaic">
        <div className="md:col-span-2 md:row-span-2"><Card a={lead} state={state} skin={{ ...skin, card: "overlay" }} big /></div>
        {rest.slice(0, 4).map((a) => <Card key={a.id} a={a} state={state} skin={{ ...skin, card: "overlay" }} />)}
      </div>
    );
  }
  if (skin.hero === "slider") {
    const scroll = (d) => sliderRef.current?.scrollBy({ left: d * sliderRef.current.clientWidth * 0.8, behavior: "smooth" });
    return (
      <div className="relative" data-mag-hero="slider">
        <div ref={sliderRef} className="no-scrollbar flex snap-x snap-mandatory gap-4 overflow-x-auto pb-2">
          {items.map((a) => (
            <div key={a.id} className="w-[85%] shrink-0 snap-start sm:w-[60%] lg:w-[45%]">
              <Card a={a} state={state} skin={{ ...skin, card: "overlay" }} big />
            </div>
          ))}
        </div>
        <div className="mt-3 flex justify-end gap-2">
          <button type="button" onClick={() => scroll(-1)} aria-label="Anterior" className="h-10 w-10 rounded-full border border-slate-300 bg-white text-lg shadow-sm hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-900">‹</button>
          <button type="button" onClick={() => scroll(1)} aria-label="Próximo" className="h-10 w-10 rounded-full border border-slate-300 bg-white text-lg shadow-sm hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-900">›</button>
        </div>
      </div>
    );
  }
  if (skin.hero === "list") {
    return (
      <ol className="divide-y divide-slate-200 dark:divide-slate-800" data-mag-hero="list">
        {items.slice(0, 5).map((a, i) => {
          const href = articlePath(a, state);
          return (
            <li key={a.id}>
              <a href={href} onClick={go(href)} className="group flex items-baseline gap-6 py-6">
                <span className="w-12 shrink-0 text-5xl font-thin text-slate-300 dark:text-slate-700">{String(i + 1).padStart(2, "0")}</span>
                <span className="min-w-0">
                  <span className={cn(skin.head, "block text-3xl leading-tight text-slate-900 group-hover:underline dark:text-white sm:text-4xl")}>{a.title}</span>
                  <span className="mt-2 block max-w-2xl text-slate-500 dark:text-slate-400">{a.excerpt}</span>
                </span>
              </a>
            </li>
          );
        })}
      </ol>
    );
  }
  if (skin.hero === "masthead") {
    const href = articlePath(lead, state);
    const site = state.branding?.siteName || state.seo?.title || "Pica-Pau";
    return (
      <div data-mag-hero="masthead">
        <div className="border-y-4 border-double border-black py-4 text-center dark:border-white">
          <p className="font-serif text-6xl font-black tracking-tight text-black dark:text-white sm:text-7xl">{site}</p>
          <p className="mt-2 font-serif text-sm uppercase tracking-[0.3em] text-slate-700 dark:text-slate-300">
            {formatDate(new Date().toISOString())} · Edição digital
          </p>
        </div>
        <div className="mt-8 grid gap-8 lg:grid-cols-3">
          <a href={href} onClick={go(href)} className="group lg:col-span-2">
            <Img a={lead} className="h-80 w-full grayscale transition group-hover:grayscale-0" />
            <span className="mt-4 block font-serif text-4xl font-black leading-tight text-black group-hover:underline dark:text-white">{lead.title}</span>
            <span className="mt-3 block font-serif text-lg leading-relaxed text-slate-700 dark:text-slate-300">{lead.excerpt}</span>
          </a>
          <div className="space-y-5 lg:border-l lg:border-black lg:pl-8 dark:lg:border-white">
            {rest.slice(0, 4).map((a) => <Card key={a.id} a={a} state={state} skin={skin} />)}
          </div>
        </div>
      </div>
    );
  }
  // split
  return (
    <div className="grid gap-6 lg:grid-cols-[2fr_1fr]" data-mag-hero="split">
      <Card a={lead} state={state} skin={{ ...skin, card: "overlay" }} big />
      <div className="flex flex-col gap-4">
        {rest.slice(0, 3).map((a) => <Card key={a.id} a={a} state={state} skin={{ ...skin, card: "horizontal" }} />)}
      </div>
    </div>
  );
}

/* ============================ página ============================ */

export function MagazineBody({ state }) {
  const cfg = themeConfig(state);
  const skin = MAG_TEMPLATES.find((t) => t.id === cfg.template) || MAG_TEMPLATES[0];
  const pub = (state.articles || []).filter((a) => a.status === "publicado").sort((a, b) => new Date(b.date) - new Date(a.date));
  const featured = cfg.featuredArticles.map((id) => pub.find((a) => a.id === id)).filter(Boolean);
  const heroItems = (featured.length ? featured : pub).slice(0, 6);
  const cats = cfg.featuredCategories.length
    ? cfg.featuredCategories.map((s) => state.categories.find((c) => c.slug === s)).filter(Boolean)
    : state.categories;
  const views = state.views || {};
  const grid = skin.card === "horizontal" ? "grid gap-4 md:grid-cols-2" : "grid gap-6 sm:grid-cols-2 lg:grid-cols-3";
  const enabled = cfg.blocks.filter((b) => b.enabled).map((b) => b.id);

  const R = {
    hero: () => <Hero items={heroItems} state={state} skin={skin} />,
    destaques: () => {
      const used = { split: 4, mosaic: 5, list: 5, masthead: 5, slider: 6, full: 1 }[skin.hero] || 1;
      const list = (featured.length ? featured : pub).slice(enabled.includes("hero") ? used : 0).slice(0, 6);
      if (!list.length) return null;
      return (<><SectionTitle skin={skin}>Em destaque</SectionTitle><div className={grid}>{list.map((a) => <Card key={a.id} a={a} state={state} skin={skin} />)}</div></>);
    },
    categorias: () => (
      <>
        <SectionTitle skin={skin}>Categorias</SectionTitle>
        <div className={skin.card === "minimal" ? "flex flex-wrap gap-2" : "grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5"}>
          {cats.map((c) => {
            const n = pub.filter((a) => (a.categories || []).includes(c.slug)).length;
            const to = `/categoria/${c.slug}`;
            return skin.card === "minimal" ? (
              <a key={c.id} href={to} onClick={go(to)} className="rounded-full border border-slate-400 px-3 py-1.5 text-sm text-slate-700 hover:bg-slate-900 hover:text-white dark:text-slate-300" data-mag-cat={c.slug}>{c.icon} {c.name}</a>
            ) : (
              <a key={c.id} href={to} onClick={go(to)} className="group rounded-2xl border border-slate-200 bg-white p-4 transition hover:-translate-y-0.5 hover:shadow-md dark:border-slate-800 dark:bg-slate-900" style={{ borderTopColor: c.color, borderTopWidth: 3 }} data-mag-cat={c.slug}>
                <span className="text-2xl" aria-hidden="true">{c.icon}</span>
                <span className="mt-1 block font-bold text-slate-900 group-hover:underline dark:text-white">{c.name}</span>
                <span className="text-xs text-slate-500">{n} artigo{n === 1 ? "" : "s"}</span>
              </a>
            );
          })}
        </div>
      </>
    ),
    ultimos: () => (<><SectionTitle skin={skin}>Últimas postagens</SectionTitle><div className={grid}>{pub.slice(0, 6).map((a) => <Card key={a.id} a={a} state={state} skin={skin} />)}</div></>),
    porCategoria: () => {
      const secs = cats.slice(0, 4).map((c) => ({ c, list: pub.filter((a) => (a.categories || []).includes(c.slug)).slice(0, 3) })).filter((x) => x.list.length);
      if (!secs.length) return null;
      return (
        <div className="space-y-12">
          {secs.map(({ c, list }) => (
            <section key={c.id} data-mag-section={c.slug}>
              <SectionTitle skin={skin} to={`/categoria/${c.slug}`}>{c.icon} {c.name}</SectionTitle>
              <div className={grid}>{list.map((a) => <Card key={a.id} a={a} state={state} skin={skin} />)}</div>
            </section>
          ))}
        </div>
      );
    },
    maisLidos: () => {
      const top = [...pub].sort((a, b) => (views[b.id] || 0) - (views[a.id] || 0)).slice(0, 5);
      return (
        <>
          <SectionTitle skin={skin}>Mais lidos</SectionTitle>
          <ol className="space-y-4">
            {top.map((a, i) => {
              const href = articlePath(a, state);
              return (
                <li key={a.id}>
                  <a href={href} onClick={go(href)} className="group flex items-start gap-4">
                    <span className={cn("text-3xl font-black leading-none", skin.accent)}>{i + 1}</span>
                    <span className="min-w-0">
                      <span className={cn(skin.head, "block leading-snug text-slate-900 group-hover:underline dark:text-white")}>{a.title}</span>
                      <span className="text-xs text-slate-500">👁 {views[a.id] || 0} visualizações</span>
                    </span>
                  </a>
                </li>
              );
            })}
          </ol>
        </>
      );
    },
    videos: () => {
      const list = pub.filter((a) => a.type === "video").slice(0, 3);
      if (!list.length) return null;
      return (<><SectionTitle skin={skin}>Vídeos</SectionTitle><div className={grid}>{list.map((a) => <Card key={a.id} a={a} state={state} skin={skin} />)}</div></>);
    },
    audios: () => {
      const list = pub.filter((a) => a.type === "audio").slice(0, 3);
      if (!list.length) return null;
      return (<><SectionTitle skin={skin} to={state.features?.podcast !== false ? "/podcasts" : null}>Podcasts e áudios</SectionTitle><div className={grid}>{list.map((a) => <Card key={a.id} a={a} state={state} skin={skin} />)}</div></>);
    },
    loja: () => {
      if (state.features?.loja === false) return null;
      const prods = (state.loja?.products || []).filter((p) => p.active).slice(0, 4);
      if (!prods.length) return null;
      return (
        <>
          <SectionTitle skin={skin} to="/loja">Da loja</SectionTitle>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {prods.map((p) => (
              <a key={p.id} href="/loja" onClick={go("/loja")} className="group overflow-hidden rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
                {p.image && <img src={p.image} alt={p.name} loading="lazy" className="h-40 w-full object-cover" />}
                <span className="block p-3">
                  <span className="block truncate font-bold text-slate-900 group-hover:underline dark:text-white">{p.name}</span>
                  <span className={cn("text-sm font-extrabold", skin.accent)}>{brl(p.price)}</span>
                </span>
              </a>
            ))}
          </div>
        </>
      );
    },
    forum: () => {
      if (state.features?.forum === false) return null;
      const topics = [...(state.forum?.topics || [])].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 4);
      if (!topics.length) return null;
      return (
        <>
          <SectionTitle skin={skin} to="/forum">Do fórum</SectionTitle>
          <ul className="grid gap-3 md:grid-cols-2">
            {topics.map((t) => (
              <li key={t.id}>
                <a href={`/forum/${t.id}`} onClick={go(`/forum/${t.id}`)} className="block rounded-xl border border-slate-200 bg-white p-4 hover:border-slate-400 dark:border-slate-800 dark:bg-slate-900">
                  <span className="block font-semibold text-slate-900 dark:text-white">{t.title}</span>
                  <span className="text-xs text-slate-500">{t.author} · 💬 {t.replies.length}</span>
                </a>
              </li>
            ))}
          </ul>
        </>
      );
    },
  };

  const sideIds = skin.sidebar ? ["maisLidos", "categorias"].filter((id) => enabled.includes(id)) : [];
  const mainIds = enabled.filter((id) => !sideIds.includes(id));
  const renderIds = (ids) => ids.map((id) => {
    const el = R[id]?.();
    return el ? <section key={id} data-mag-block={id}>{el}</section> : null;
  });

  const body = (
    <div className={cn("min-h-screen pb-16", skin.bg)} data-mag-template={skin.id}>
      <div className="mx-auto max-w-7xl px-4 pt-8">
        {skin.sidebar ? (
          <div className="grid gap-10 lg:grid-cols-[minmax(0,1fr)_320px]">
            <div className="min-w-0 space-y-14">{renderIds(mainIds)}</div>
            <aside className="space-y-10 lg:sticky lg:top-24 lg:self-start" aria-label="Barra lateral">{renderIds(sideIds)}</aside>
          </div>
        ) : (
          <div className="space-y-14">{renderIds(mainIds)}</div>
        )}
        {!enabled.length && <p className="py-20 text-center text-slate-400">Nenhum bloco ativo na página inicial.</p>}
      </div>
    </div>
  );
  return skin.dark ? <div className="dark">{body}</div> : body;
}

export default function MagazineHome({ state }) {
  return (
    <PublicLayout state={state}>
      <MagazineBody state={state} />
    </PublicLayout>
  );
}
