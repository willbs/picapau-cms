// Página inicial pública: hero + grade com as categorias + últimos artigos.
import PublicLayout, { CategoryCard, ArticleCard } from "../components/Layout.jsx";
import { navigate } from "../router.js";
import { articlePath } from "../permalink.js";

export default function Home({ state }) {
  const cats = state.categories || [];
  const published = (state.articles || [])
    .filter((a) => a.status === "publicado")
    .sort((a, b) => new Date(b.date) - new Date(a.date));
  const latest = published.slice(0, 6);
  const countFor = (slug) =>
    (state.articles || []).filter(
      (a) => a.status === "publicado" && (a.categories || []).includes(slug)
    ).length;

  return (
    <PublicLayout state={state}>
      {/* Hero */}
      <section className="relative overflow-hidden bg-slate-950 text-white">
        <div
          className="pointer-events-none absolute inset-0 opacity-40"
          style={{
            background:
              "radial-gradient(60% 80% at 20% 10%, rgba(245,158,11,.25), transparent 60%), radial-gradient(50% 70% at 85% 20%, rgba(99,102,241,.28), transparent 60%), radial-gradient(40% 60% at 50% 100%, rgba(16,185,129,.15), transparent 60%)",
          }}
          aria-hidden="true"
        />
        <div className="relative mx-auto max-w-7xl px-4 py-16 sm:py-24">
          <p className="animate-fade-up text-xs font-bold uppercase tracking-[0.25em] text-amber-400">
            Portal de conteúdo
          </p>
          <h1 className="animate-fade-up mt-3 max-w-3xl text-4xl font-extrabold leading-tight tracking-tight sm:text-5xl">
            {state.seo.title}
          </h1>
          <p className="animate-fade-up mt-4 max-w-2xl text-lg text-slate-300" style={{ animationDelay: "80ms" }}>
            {state.seo.description}
          </p>
          <div className="animate-fade-up mt-8 flex flex-wrap gap-3" style={{ animationDelay: "160ms" }}>
            <button
              type="button"
              onClick={() => {
                document.getElementById("categorias")?.scrollIntoView({ behavior: "smooth" });
              }}
              className="rounded-xl bg-amber-500 px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-amber-500/25 transition hover:bg-amber-400"
            >
              Explorar categorias
            </button>
            <button
              type="button"
              onClick={() => navigate(latest[0] ? articlePath(latest[0], state) : "/")}
              disabled={!latest.length}
              className="rounded-xl border border-slate-700 bg-white/5 px-5 py-2.5 text-sm font-semibold text-slate-200 transition hover:bg-white/10 disabled:opacity-40"
            >
              Ler último artigo
            </button>
          </div>
        </div>
      </section>

      {/* Grade de categorias */}
      <section id="categorias" className="mx-auto max-w-7xl scroll-mt-20 px-4 py-14">
        <div className="mb-8 flex flex-wrap items-end justify-between gap-3">
          <div>
            <h2 className="text-2xl font-extrabold tracking-tight text-slate-900 dark:text-white sm:text-3xl">
              Categorias
            </h2>
            <p className="mt-1 text-slate-500 dark:text-slate-400">
              Explore o conteúdo por tema — são {cats.length} categorias no total.
            </p>
          </div>
          <span className="rounded-full bg-amber-100 px-3 py-1 text-sm font-bold text-amber-800 dark:bg-amber-500/15 dark:text-amber-300">
            {cats.length} categorias
          </span>
        </div>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
          {cats.map((c) => (
            <CategoryCard key={c.id} cat={c} count={countFor(c.slug)} />
          ))}
        </div>
      </section>

      {/* Últimos artigos */}
      {latest.length > 0 && (
        <section className="border-t border-slate-200 bg-white py-14 dark:border-slate-800 dark:bg-slate-900/40">
          <div className="mx-auto max-w-7xl px-4">
            <h2 className="mb-8 text-2xl font-extrabold tracking-tight text-slate-900 dark:text-white sm:text-3xl">
              Últimos artigos
            </h2>
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {latest.map((a) => (
                <ArticleCard key={a.id} article={a} />
              ))}
            </div>
          </div>
        </section>
      )}
    </PublicLayout>
  );
}
