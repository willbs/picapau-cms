// Páginas públicas do Fórum: /forum (5 layouts), /forum/novo e /forum/:id.
// Identidade do visitante: "Participar como" um perfil (salvo no LocalStorage),
// usado para criar tópicos/respostas e para seguir outros usuários.
import { useMemo, useState } from "react";
import PublicLayout from "../components/Layout.jsx";
import NotFound from "./NotFound.jsx";
import { navigate } from "../router.js";
import { updateState } from "../store.js";
import { uid, formatDate, slugify } from "../utils.js";

const ME_KEY = "picapau_forum_me_v1";

/** Os 5 layouts da página do fórum (escolhidos em Painel → Fórum). */
export const FORUM_TEMPLATES = [
  { id: "classico", name: "Clássico", icon: "☰", desc: "Lista de tópicos em linhas, com contador de respostas." },
  { id: "cards", name: "Cards", icon: "▦", desc: "Tópicos em cartões com resumo do conteúdo." },
  { id: "compacto", name: "Tabela compacta", icon: "▤", desc: "Tabela densa: título, categoria, autor, respostas e data." },
  { id: "quadro", name: "Quadro por categoria", icon: "▥", desc: "Colunas por categoria, estilo quadro/kanban." },
  { id: "feed", name: "Feed social", icon: "💬", desc: "Linha do tempo com avatar do autor e conteúdo completo." },
];

/* ----------------------------- Identidade ----------------------------- */

export function getMeId() {
  return localStorage.getItem(ME_KEY) || "";
}
export function setMeId(id) {
  if (id) localStorage.setItem(ME_KEY, id);
  else localStorage.removeItem(ME_KEY);
  window.dispatchEvent(new Event("cms:changed"));
}
export function getMe(state) {
  const id = getMeId();
  return (state.forum?.profiles || []).find((p) => p.id === id) || null;
}
export function profileByName(state, name) {
  return (state.forum?.profiles || []).find((p) => p.name === name || p.username === name) || null;
}

const inputCls =
  "w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 placeholder-slate-400 focus:border-amber-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white";
const labelCls = "mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400";

export function Avatar({ profile, name, size = "h-10 w-10" }) {
  if (profile?.avatar) return <img src={profile.avatar} alt="" className={`${size} shrink-0 rounded-full object-cover`} />;
  return (
    <span className={`${size} flex shrink-0 items-center justify-center rounded-full bg-indigo-500/20 text-sm font-bold text-indigo-600 dark:text-indigo-300`} aria-hidden="true">
      {(profile?.name || name || "?")[0]?.toUpperCase()}
    </span>
  );
}

/** Link para o perfil do autor (se existir um perfil com esse nome). */
export function AuthorLink({ state, name }) {
  const p = profileByName(state, name);
  if (!p) return <strong>{name}</strong>;
  return (
    <a
      href={`/forum/u/${p.username}`}
      onClick={(e) => { e.preventDefault(); e.stopPropagation(); navigate(`/forum/u/${p.username}`); }}
      className="font-semibold text-indigo-600 hover:underline dark:text-indigo-300"
    >
      {p.name}
    </a>
  );
}

/** Barra "Participar como": escolher/criar perfil e ir para o próprio perfil. */
export function IdentityBar({ state }) {
  const me = getMe(state);
  const profiles = state.forum?.profiles || [];
  const [creating, setCreating] = useState(false);
  const [name, setName] = useState("");
  const [err, setErr] = useState("");

  const create = (e) => {
    e.preventDefault();
    const n = name.trim();
    if (!n) return setErr("Informe seu nome.");
    let username = slugify(n).replace(/-/g, "") || "usuario";
    let k = 1;
    while (profiles.some((p) => p.username === username)) username = `${slugify(n).replace(/-/g, "")}${++k}`;
    const prof = {
      id: uid(), username, name: n, bio: "", avatar: "", cover: "",
      template: "classico", following: [], videos: [], createdAt: new Date().toISOString(),
    };
    updateState((s) => { s.forum.profiles.push(prof); });
    setMeId(prof.id);
    setCreating(false);
    setName("");
    navigate(`/forum/u/${username}`);
  };

  return (
    <div className="mb-6 flex flex-wrap items-center gap-3 rounded-2xl border border-slate-200 bg-white p-3 shadow-sm dark:border-slate-800 dark:bg-slate-900">
      <Avatar profile={me} name="?" size="h-9 w-9" />
      <label htmlFor="me-select" className="text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">
        Participar como
      </label>
      <select id="me-select" className={`${inputCls} w-auto`} value={me?.id || ""} onChange={(e) => setMeId(e.target.value)}>
        <option value="">— visitante (sem perfil) —</option>
        {profiles.map((p) => <option key={p.id} value={p.id}>{p.name} (@{p.username})</option>)}
      </select>
      {me && (
        <button type="button" onClick={() => navigate(`/forum/u/${me.username}`)}
          className="rounded-lg bg-indigo-600 px-3 py-2 text-xs font-bold text-white hover:bg-indigo-500">
          👤 Meu perfil
        </button>
      )}
      {creating ? (
        <form onSubmit={create} className="flex flex-wrap items-center gap-2">
          <input className={`${inputCls} w-48`} placeholder="Seu nome" value={name} onChange={(e) => setName(e.target.value)} aria-label="Nome do novo perfil" autoFocus />
          <button type="submit" className="rounded-lg bg-emerald-600 px-3 py-2 text-xs font-bold text-white">Criar</button>
          <button type="button" onClick={() => setCreating(false)} className="text-xs text-slate-400">cancelar</button>
          {err && <span className="text-xs text-rose-500">{err}</span>}
        </form>
      ) : (
        <button type="button" onClick={() => setCreating(true)} className="text-xs font-semibold text-emerald-600 hover:underline dark:text-emerald-400">
          ＋ Criar meu perfil
        </button>
      )}
    </div>
  );
}

function catOf(state, slug) {
  return (state.forum?.categories || []).find((c) => c.slug === slug);
}

/* ----------------------------- 5 layouts ----------------------------- */

function LClassico({ topics, state }) {
  return (
    <ul className="space-y-3">
      {topics.map((t) => {
        const cat = catOf(state, t.category);
        return (
          <li key={t.id}>
            <button type="button" onClick={() => navigate(`/forum/${t.id}`)}
              className="flex w-full items-start gap-4 rounded-2xl border border-slate-200 bg-white p-4 text-left shadow-sm transition hover:-translate-y-0.5 hover:shadow-md dark:border-slate-800 dark:bg-slate-900">
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-indigo-100 text-xl dark:bg-indigo-500/15" aria-hidden="true">{cat?.icon || "💬"}</span>
              <span className="min-w-0 flex-1">
                <span className="flex flex-wrap items-center gap-2">
                  {t.pinned && <span title="Fixado">📌</span>}
                  {t.locked && <span title="Bloqueado">🔒</span>}
                  <span className="truncate font-bold text-slate-900 dark:text-white">{t.title}</span>
                </span>
                <span className="mt-1 block text-xs text-slate-400">
                  por <AuthorLink state={state} name={t.author} /> · {formatDate(t.createdAt)} · {cat ? `${cat.icon} ${cat.name}` : "sem categoria"}
                </span>
              </span>
              <span className="shrink-0 rounded-full bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-600 dark:bg-slate-800 dark:text-slate-300">💬 {t.replies.length}</span>
            </button>
          </li>
        );
      })}
    </ul>
  );
}

function LCards({ topics, state }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {topics.map((t) => {
        const cat = catOf(state, t.category);
        return (
          <button key={t.id} type="button" onClick={() => navigate(`/forum/${t.id}`)}
            className="flex flex-col rounded-2xl border border-slate-200 bg-white p-5 text-left shadow-sm transition hover:-translate-y-1 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900">
            <span className="text-xs font-semibold text-indigo-600 dark:text-indigo-300">{cat ? `${cat.icon} ${cat.name}` : "💬"} {t.pinned && "· 📌"} {t.locked && "· 🔒"}</span>
            <span className="mt-2 font-bold text-slate-900 dark:text-white">{t.title}</span>
            <span className="mt-2 line-clamp-3 flex-1 text-sm text-slate-500 dark:text-slate-400">{t.body}</span>
            <span className="mt-4 flex items-center justify-between text-xs text-slate-400">
              <span><AuthorLink state={state} name={t.author} /></span>
              <span>💬 {t.replies.length}</span>
            </span>
          </button>
        );
      })}
    </div>
  );
}

function LCompacto({ topics, state }) {
  return (
    <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
      <table className="w-full text-left text-sm">
        <thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500 dark:bg-slate-800/60 dark:text-slate-400">
          <tr>
            <th className="px-4 py-2.5">Tópico</th>
            <th className="px-4 py-2.5">Categoria</th>
            <th className="px-4 py-2.5">Autor</th>
            <th className="px-4 py-2.5 text-center">Respostas</th>
            <th className="px-4 py-2.5">Data</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
          {topics.map((t) => {
            const cat = catOf(state, t.category);
            return (
              <tr key={t.id} className="cursor-pointer hover:bg-amber-50/60 dark:hover:bg-slate-800/50" onClick={() => navigate(`/forum/${t.id}`)}>
                <td className="px-4 py-2.5 font-semibold text-slate-900 dark:text-white">{t.pinned && "📌 "}{t.locked && "🔒 "}{t.title}</td>
                <td className="px-4 py-2.5 text-slate-500">{cat ? `${cat.icon} ${cat.name}` : "—"}</td>
                <td className="px-4 py-2.5"><AuthorLink state={state} name={t.author} /></td>
                <td className="px-4 py-2.5 text-center text-slate-500">{t.replies.length}</td>
                <td className="px-4 py-2.5 text-xs text-slate-400">{formatDate(t.createdAt)}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

function LQuadro({ topics, state }) {
  const cats = state.forum?.categories || [];
  const cols = [...cats.map((c) => ({ key: c.slug, title: `${c.icon} ${c.name}` })), { key: "", title: "📁 Sem categoria" }];
  return (
    <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
      {cols.map((col) => {
        const list = topics.filter((t) => (t.category || "") === col.key && (col.key || !catOf(state, t.category)));
        if (!col.key && list.length === 0) return null;
        return (
          <section key={col.key || "none"} className="rounded-2xl bg-slate-100 p-3 dark:bg-slate-900/70">
            <h2 className="mb-3 flex items-center justify-between px-1 text-sm font-bold text-slate-700 dark:text-slate-200">
              {col.title} <span className="rounded-full bg-white px-2 text-xs dark:bg-slate-800">{list.length}</span>
            </h2>
            <div className="space-y-2">
              {list.map((t) => (
                <button key={t.id} type="button" onClick={() => navigate(`/forum/${t.id}`)}
                  className="block w-full rounded-xl bg-white p-3 text-left shadow-sm hover:shadow-md dark:bg-slate-800">
                  <span className="block text-sm font-semibold text-slate-900 dark:text-white">{t.pinned && "📌 "}{t.title}</span>
                  <span className="mt-1 block text-xs text-slate-400">{t.author} · 💬 {t.replies.length}</span>
                </button>
              ))}
              {list.length === 0 && <p className="px-1 text-xs text-slate-400">Nenhum tópico.</p>}
            </div>
          </section>
        );
      })}
    </div>
  );
}

function LFeed({ topics, state }) {
  return (
    <div className="mx-auto max-w-2xl space-y-4">
      {topics.map((t) => {
        const prof = profileByName(state, t.author);
        const cat = catOf(state, t.category);
        return (
          <article key={t.id} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <header className="flex items-center gap-3">
              <Avatar profile={prof} name={t.author} />
              <div className="min-w-0 flex-1">
                <p className="text-sm"><AuthorLink state={state} name={t.author} /></p>
                <p className="text-xs text-slate-400">{formatDate(t.createdAt)} · {cat ? `${cat.icon} ${cat.name}` : ""} {t.pinned && "· 📌"}</p>
              </div>
            </header>
            <button type="button" onClick={() => navigate(`/forum/${t.id}`)} className="mt-3 block text-left">
              <h2 className="text-lg font-bold text-slate-900 hover:text-amber-600 dark:text-white">{t.title}</h2>
            </button>
            <p className="mt-2 whitespace-pre-wrap text-sm leading-relaxed text-slate-600 dark:text-slate-300">{t.body}</p>
            <button type="button" onClick={() => navigate(`/forum/${t.id}`)} className="mt-3 text-xs font-semibold text-indigo-600 hover:underline dark:text-indigo-300">
              💬 {t.replies.length} resposta{t.replies.length === 1 ? "" : "s"} — ver conversa →
            </button>
          </article>
        );
      })}
    </div>
  );
}

const FORUM_LAYOUTS = { classico: LClassico, cards: LCards, compacto: LCompacto, quadro: LQuadro, feed: LFeed };

/* ----------------------------- Páginas ----------------------------- */

function ForumHero({ subtitle }) {
  return (
    <section className="relative overflow-hidden bg-slate-950 text-white">
      <div className="pointer-events-none absolute inset-0 opacity-40"
        style={{ background: "radial-gradient(60% 80% at 20% 10%, rgba(99,102,241,.30), transparent 60%), radial-gradient(50% 70% at 85% 20%, rgba(245,158,11,.20), transparent 60%)" }}
        aria-hidden="true" />
      <div className="relative mx-auto max-w-7xl px-4 py-14">
        <p className="animate-fade-up text-xs font-bold uppercase tracking-[0.25em] text-indigo-400">💬 Fórum</p>
        <h1 className="animate-fade-up mt-3 text-4xl font-extrabold tracking-tight sm:text-5xl">Tópicos da comunidade</h1>
        <p className="animate-fade-up mt-3 max-w-xl text-slate-300">{subtitle}</p>
      </div>
    </section>
  );
}

/** /forum — listagem de tópicos no layout escolhido no painel. */
export function ForumIndex({ state }) {
  const [cat, setCat] = useState("");
  const [q, setQ] = useState("");
  const topics = useMemo(() => {
    let list = [...(state.forum?.topics || [])];
    if (cat) list = list.filter((t) => t.category === cat);
    if (q.trim()) {
      const s = q.toLowerCase();
      list = list.filter((t) => t.title.toLowerCase().includes(s) || t.body.toLowerCase().includes(s) || t.author.toLowerCase().includes(s));
    }
    return list.sort((a, b) => (b.pinned - a.pinned) || (new Date(b.createdAt) - new Date(a.createdAt)));
  }, [state.forum?.topics, cat, q]);

  if (state.features?.forum === false) return <NotFound state={state} />;

  const tpl = FORUM_LAYOUTS[state.forum?.template] ? state.forum.template : "classico";
  const L = FORUM_LAYOUTS[tpl];
  const profiles = state.forum?.profiles || [];

  return (
    <PublicLayout state={state}>
      <ForumHero subtitle="Participe da conversa: faça perguntas, compartilhe ideias, siga outros usuários." />
      <section className="mx-auto max-w-7xl px-4 py-10" data-forum-layout={tpl}>
        <IdentityBar state={state} />

        <div className="mb-6 flex flex-wrap items-center gap-2">
          <input className={`${inputCls} w-full max-w-xs`} placeholder="🔍 Buscar tópicos…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Buscar tópicos" />
          <div className="flex flex-wrap gap-2">
            <button type="button" onClick={() => setCat("")}
              className={`rounded-full px-3 py-1.5 text-xs font-semibold ${!cat ? "bg-amber-500 text-slate-950" : "border border-slate-300 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300"}`}>
              Todos
            </button>
            {(state.forum?.categories || []).map((c) => (
              <button key={c.id} type="button" onClick={() => setCat(c.slug === cat ? "" : c.slug)}
                className={`rounded-full px-3 py-1.5 text-xs font-semibold ${cat === c.slug ? "bg-amber-500 text-slate-950" : "border border-slate-300 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300"}`}>
                {c.icon} {c.name}
              </button>
            ))}
          </div>
          <button type="button" onClick={() => navigate("/forum/novo")}
            className="ml-auto rounded-xl bg-amber-500 px-4 py-2 text-sm font-bold text-slate-950 shadow transition hover:bg-amber-400">
            ＋ Novo tópico
          </button>
        </div>

        {topics.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-12 text-center dark:border-slate-700 dark:bg-slate-900">
            <p className="text-4xl" aria-hidden="true">💭</p>
            <p className="mt-2 font-semibold text-slate-700 dark:text-slate-200">Nenhum tópico encontrado.</p>
          </div>
        ) : (
          <L topics={topics} state={state} />
        )}

        {/* Membros da comunidade */}
        {profiles.length > 0 && (
          <section className="mt-12">
            <h2 className="mb-4 text-lg font-bold text-slate-900 dark:text-white">👥 Membros ({profiles.length})</h2>
            <div className="flex flex-wrap gap-3">
              {profiles.map((p) => (
                <button key={p.id} type="button" onClick={() => navigate(`/forum/u/${p.username}`)}
                  className="flex items-center gap-2 rounded-full border border-slate-200 bg-white py-1 pl-1 pr-3 text-sm hover:border-indigo-400 dark:border-slate-800 dark:bg-slate-900">
                  <Avatar profile={p} size="h-8 w-8" />
                  <span className="font-semibold text-slate-800 dark:text-slate-100">{p.name}</span>
                  <span className="text-xs text-slate-400">@{p.username}</span>
                </button>
              ))}
            </div>
          </section>
        )}
      </section>
    </PublicLayout>
  );
}

/** /forum/novo — criar tópico. */
export function ForumNew({ state }) {
  const me = getMe(state);
  const [author, setAuthor] = useState(me?.name || "");
  const [category, setCategory] = useState(state.forum?.categories?.[0]?.slug || "");
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [error, setError] = useState("");

  if (state.features?.forum === false) return <NotFound state={state} />;

  const submit = (e) => {
    e.preventDefault();
    if (!author.trim()) return setError("Informe seu nome (como autor).");
    if (!category) return setError("Escolha uma categoria.");
    if (!title.trim()) return setError("O título é obrigatório.");
    if (!body.trim()) return setError("Escreva o conteúdo do tópico.");
    const topic = {
      id: uid(), title: title.trim(), body: body.trim(), author: author.trim(), category,
      createdAt: new Date().toISOString(), pinned: false, locked: false, replies: [],
    };
    updateState((s) => { s.forum.topics.unshift(topic); });
    navigate(`/forum/${topic.id}`);
  };

  const cats = state.forum?.categories || [];
  return (
    <PublicLayout state={state}>
      <section className="mx-auto max-w-3xl px-4 py-12">
        <button type="button" onClick={() => navigate("/forum")} className="text-sm text-slate-400 hover:text-amber-600">← Voltar ao fórum</button>
        <h1 className="mt-3 text-3xl font-extrabold text-slate-900 dark:text-white">Novo tópico</h1>
        {cats.length === 0 ? (
          <p className="mt-6 rounded-xl border border-amber-500/40 bg-amber-500/10 p-4 text-sm text-amber-700 dark:text-amber-300">
            Ainda não há categorias de fórum. Crie categorias em Painel → Fórum.
          </p>
        ) : (
          <form onSubmit={submit} className="mt-6 space-y-4 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900">
            {error && <p role="alert" className="rounded-lg bg-rose-500/10 px-3 py-2 text-sm text-rose-500">{error}</p>}
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="fn-author" className={labelCls}>Seu nome</label>
                <input id="fn-author" className={inputCls} value={author} onChange={(e) => setAuthor(e.target.value)} placeholder="Como aparecerá no tópico" />
              </div>
              <div>
                <label htmlFor="fn-cat" className={labelCls}>Categoria</label>
                <select id="fn-cat" className={inputCls} value={category} onChange={(e) => setCategory(e.target.value)}>
                  {cats.map((c) => <option key={c.id} value={c.slug}>{c.icon} {c.name}</option>)}
                </select>
              </div>
            </div>
            <div>
              <label htmlFor="fn-title" className={labelCls}>Título</label>
              <input id="fn-title" className={inputCls} value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Resumo do assunto" />
            </div>
            <div>
              <label htmlFor="fn-body" className={labelCls}>Conteúdo</label>
              <textarea id="fn-body" className={inputCls} rows={6} value={body} onChange={(e) => setBody(e.target.value)} placeholder="Descreva sua dúvida ou ideia…" />
            </div>
            <button type="submit" className="rounded-xl bg-amber-500 px-5 py-2.5 text-sm font-bold text-slate-950 transition hover:bg-amber-400">Publicar tópico</button>
          </form>
        )}
      </section>
    </PublicLayout>
  );
}

/** /forum/:id — tópico + respostas. */
export function ForumTopic({ state, id }) {
  const me = getMe(state);
  const topic = (state.forum?.topics || []).find((t) => t.id === id);
  const [author, setAuthor] = useState(me?.name || "");
  const [body, setBody] = useState("");
  const [error, setError] = useState("");

  if (state.features?.forum === false) return <NotFound state={state} />;
  if (!topic) {
    return (
      <PublicLayout state={state}>
        <div className="mx-auto max-w-3xl px-4 py-24 text-center">
          <p className="text-6xl font-black text-amber-500">404</p>
          <p className="mt-3 text-slate-500 dark:text-slate-400">Tópico não encontrado.</p>
          <button type="button" onClick={() => navigate("/forum")} className="mt-6 rounded-xl bg-amber-500 px-5 py-2.5 text-sm font-bold text-slate-950 hover:bg-amber-400">Voltar ao fórum</button>
        </div>
      </PublicLayout>
    );
  }
  const cat = catOf(state, topic.category);

  const reply = (e) => {
    e.preventDefault();
    if (topic.locked) return;
    if (!author.trim()) return setError("Informe seu nome.");
    if (!body.trim()) return setError("Escreva sua resposta.");
    updateState((s) => {
      const t = s.forum.topics.find((x) => x.id === id);
      if (t) t.replies.push({ id: uid(), author: author.trim(), body: body.trim(), createdAt: new Date().toISOString() });
    });
    setBody("");
    setError("");
  };

  return (
    <PublicLayout state={state}>
      <section className="mx-auto max-w-3xl px-4 py-12">
        <button type="button" onClick={() => navigate("/forum")} className="text-sm text-slate-400 hover:text-amber-600">← Voltar ao fórum</button>
        <article className="mt-4 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div className="flex flex-wrap items-center gap-2">
            {cat && <span className="rounded-full bg-indigo-100 px-2.5 py-0.5 text-xs font-semibold text-indigo-700 dark:bg-indigo-500/15 dark:text-indigo-300">{cat.icon} {cat.name}</span>}
            {topic.pinned && <span className="text-xs">📌 fixado</span>}
            {topic.locked && <span className="text-xs">🔒 bloqueado</span>}
          </div>
          <h1 className="mt-2 text-2xl font-extrabold text-slate-900 dark:text-white">{topic.title}</h1>
          <p className="mt-1 flex items-center gap-2 text-xs text-slate-400">
            <Avatar profile={profileByName(state, topic.author)} name={topic.author} size="h-6 w-6" />
            por <AuthorLink state={state} name={topic.author} /> · {formatDate(topic.createdAt)}
          </p>
          <p className="mt-4 whitespace-pre-wrap leading-relaxed text-slate-700 dark:text-slate-300">{topic.body}</p>
        </article>

        <h2 className="mb-3 mt-8 text-lg font-bold text-slate-900 dark:text-white">💬 Respostas ({topic.replies.length})</h2>
        <ul className="space-y-3">
          {topic.replies.map((r) => (
            <li key={r.id} className="flex gap-3 rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
              <Avatar profile={profileByName(state, r.author)} name={r.author} size="h-8 w-8" />
              <div className="min-w-0">
                <p className="text-xs text-slate-400"><AuthorLink state={state} name={r.author} /> · {formatDate(r.createdAt)}</p>
                <p className="mt-1 whitespace-pre-wrap text-sm leading-relaxed text-slate-700 dark:text-slate-300">{r.body}</p>
              </div>
            </li>
          ))}
          {topic.replies.length === 0 && (
            <li className="rounded-2xl border border-dashed border-slate-300 p-6 text-center text-sm text-slate-400 dark:border-slate-700">Ainda sem respostas — seja o primeiro!</li>
          )}
        </ul>

        {topic.locked ? (
          <p className="mt-5 rounded-xl border border-slate-300 bg-slate-100 p-4 text-sm text-slate-500 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-400">🔒 Este tópico está bloqueado para novas respostas.</p>
        ) : (
          <form onSubmit={reply} className="mt-5 space-y-3 rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100">Responder</h3>
            {error && <p role="alert" className="rounded-lg bg-rose-500/10 px-3 py-2 text-sm text-rose-500">{error}</p>}
            <input className={inputCls} placeholder="Seu nome" value={author} onChange={(e) => setAuthor(e.target.value)} aria-label="Seu nome" />
            <textarea className={inputCls} rows={4} placeholder="Sua resposta…" value={body} onChange={(e) => setBody(e.target.value)} aria-label="Sua resposta" />
            <button type="submit" className="rounded-xl bg-amber-500 px-5 py-2 text-sm font-bold text-slate-950 transition hover:bg-amber-400">Enviar resposta</button>
          </form>
        )}
      </section>
    </PublicLayout>
  );
}
