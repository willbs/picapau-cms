// Modo manutenção: exibido no site público quando ativado no painel de segurança.
import PublicLayout from "../components/Layout.jsx";

export default function Maintenance({ state }) {
  return (
    <PublicLayout state={state}>
      <div className="mx-auto flex max-w-2xl flex-col items-center px-4 py-28 text-center">
        <span className="animate-float-slow text-6xl" aria-hidden="true">🛠️</span>
        <h1 className="mt-6 text-3xl font-extrabold text-slate-900 dark:text-white">Em manutenção</h1>
        <p className="mt-3 text-slate-500 dark:text-slate-400">
          Estamos fazendo ajustes e voltamos já já. Obrigado pela paciência!
        </p>
      </div>
    </PublicLayout>
  );
}
