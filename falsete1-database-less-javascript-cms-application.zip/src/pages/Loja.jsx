// Página pública da Loja Virtual (/loja).
// - 5 layouts de página de produtos (escolhidos em Painel → Loja): grade, lista, vitrine, minimal, revista
// - Produtos próprios vão para o carrinho; produtos de AFILIADO redirecionam para o site parceiro
// - Se a loja estiver desabilitada no painel, a página retorna 404
import { useMemo, useState } from "react";
import PublicLayout from "../components/Layout.jsx";
import Modal from "../components/Modal.jsx";
import NotFound from "./NotFound.jsx";
import { updateState } from "../store.js";
import { uid } from "../utils.js";
import { getLocale } from "../i18n.js";
import WishHeart from "../components/WishHeart.jsx";

const CART_KEY = "picapau_cart_v1";

/** Catálogo dos 5 layouts de página de produtos. */
export const LOJA_TEMPLATES = [
  { id: "grade", name: "Grade clássica", icon: "▦", desc: "Cards em grade de 4 colunas — o layout padrão de e-commerce." },
  { id: "lista", name: "Lista detalhada", icon: "☰", desc: "Um produto por linha, imagem à esquerda e detalhes completos." },
  { id: "vitrine", name: "Vitrine com destaque", icon: "⭐", desc: "Primeiro produto em banner gigante + demais em grade." },
  { id: "minimal", name: "Minimalista", icon: "◻", desc: "Cards grandes, tipografia limpa e muito respiro." },
  { id: "revista", name: "Revista (zigue-zague)", icon: "📰", desc: "Blocos editoriais alternando imagem à esquerda e à direita." },
];

function getCart() {
  try {
    return JSON.parse(localStorage.getItem(CART_KEY)) || [];
  } catch {
    return [];
  }
}
function setCart(c) {
  localStorage.setItem(CART_KEY, JSON.stringify(c));
}

export const brl = (n) =>
  Number(n || 0).toLocaleString(getLocale(), { style: "currency", currency: "BRL" });

const isAffiliate = (p) => p.kind === "afiliado" && !!p.affiliateUrl;
const isOut = (p) => !isAffiliate(p) && p.stock !== null && p.stock !== undefined && p.stock !== "" && Number(p.stock) <= 0;

/** Botão de compra: afiliado → link externo; próprio → adicionar ao carrinho. */
function BuyButton({ p, onAdd, className = "" }) {
  if (isAffiliate(p)) {
    return (
      <a
        href={p.affiliateUrl}
        target="_blank"
        rel="noopener noreferrer sponsored nofollow"
        className={`inline-flex items-center justify-center gap-1.5 rounded-xl bg-emerald-600 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-emerald-500 ${className}`}
      >
        Comprar{p.affiliateStore ? ` na ${p.affiliateStore}` : ""} ↗
      </a>
    );
  }
  const out = isOut(p);
  return (
    <button
      type="button"
      disabled={out}
      onClick={() => onAdd(p)}
      className={`rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-amber-500 hover:text-slate-950 disabled:cursor-not-allowed disabled:opacity-40 dark:bg-amber-500 dark:text-slate-950 dark:hover:bg-amber-400 ${className}`}
    >
      {out ? "Esgotado" : "🛒 Adicionar ao carrinho"}
    </button>
  );
}

function Price({ p, big = false }) {
  return (
    <span className="flex items-baseline gap-2">
      <span className={`${big ? "text-3xl" : "text-xl"} font-extrabold text-amber-600 dark:text-amber-400`}>{brl(p.price)}</span>
      {p.oldPrice > p.price && <span className="text-sm text-slate-400 line-through">{brl(p.oldPrice)}</span>}
    </span>
  );
}

function Badges({ p }) {
  return (
    <>
      {p.category && (
        <span className="rounded-full bg-black/60 px-2 py-0.5 text-xs font-semibold text-white backdrop-blur">{p.category}</span>
      )}
      {isAffiliate(p) && (
        <span className="rounded-full bg-emerald-600 px-2 py-0.5 text-xs font-bold text-white">🔗 afiliado</span>
      )}
      {isOut(p) && <span className="rounded-full bg-rose-500 px-2 py-0.5 text-xs font-bold text-white">esgotado</span>}
    </>
  );
}

function Img({ p, className }) {
  return p.image ? (
    <img src={p.image} alt={p.name} loading="lazy" className={`object-cover ${className}`} />
  ) : (
    <span className={`flex items-center justify-center bg-slate-100 text-5xl dark:bg-slate-800 ${className}`} aria-hidden="true">📦</span>
  );
}

/* ----------------------------- 5 layouts ----------------------------- */

function LayoutGrade({ products, onAdd, state }) {
  return (
    <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
      {products.map((p) => (
        <article key={p.id} className="group flex flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm transition-all hover:-translate-y-1 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900">
          <div className="relative h-52 overflow-hidden">
            <Img p={p} className="h-full w-full transition-transform duration-300 group-hover:scale-105" />
            <WishHeart state={state} product={p} className="absolute right-3 top-3" />
            <div className="absolute left-3 top-3 flex flex-wrap gap-1"><Badges p={p} /></div>
          </div>
          <div className="flex flex-1 flex-col p-4">
            <h2 className="font-bold text-slate-900 dark:text-white">{p.name}</h2>
            <p className="mt-1 line-clamp-2 flex-1 text-sm text-slate-500 dark:text-slate-400">{p.description}</p>
            <div className="mt-3"><Price p={p} /></div>
            <BuyButton p={p} onAdd={onAdd} className="mt-3 w-full" />
          </div>
        </article>
      ))}
    </div>
  );
}

function LayoutLista({ products, onAdd, state }) {
  return (
    <div className="space-y-4">
      {products.map((p) => (
        <article key={p.id} className="flex flex-col gap-4 overflow-hidden rounded-2xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900 sm:flex-row sm:items-center">
          <div className="relative h-40 w-full shrink-0 overflow-hidden rounded-xl sm:h-32 sm:w-40">
            <Img p={p} className="h-full w-full" />
            <WishHeart state={state} product={p} className="absolute right-3 top-3" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="mb-1 flex flex-wrap gap-1"><Badges p={p} /></div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">{p.name}</h2>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">{p.description}</p>
            {!isAffiliate(p) && <p className="mt-1 text-xs text-slate-400">estoque: {p.stock ?? "ilimitado"}</p>}
          </div>
          <div className="flex shrink-0 flex-col items-start gap-2 sm:items-end">
            <Price p={p} />
            <BuyButton p={p} onAdd={onAdd} />
          </div>
        </article>
      ))}
    </div>
  );
}

function LayoutVitrine({ products, onAdd, state }) {
  const [hero, ...rest] = products;
  return (
    <div className="space-y-8">
      {hero && (
        <article className="relative grid overflow-hidden rounded-3xl bg-slate-900 text-white shadow-xl md:grid-cols-2">
          <div className="relative"><Img p={hero} className="h-72 w-full md:h-full" /><WishHeart state={state} product={hero} className="absolute right-4 top-4" /></div>
          <div className="flex flex-col justify-center gap-3 p-8">
            <span className="text-xs font-bold uppercase tracking-[0.25em] text-amber-400">⭐ Destaque da vitrine</span>
            <div className="flex flex-wrap gap-1"><Badges p={hero} /></div>
            <h2 className="text-3xl font-extrabold">{hero.name}</h2>
            <p className="text-slate-300">{hero.description}</p>
            <Price p={hero} big />
            <BuyButton p={hero} onAdd={onAdd} className="self-start" />
          </div>
        </article>
      )}
      {rest.length > 0 && <LayoutGrade products={rest} onAdd={onAdd} state={state} />}
    </div>
  );
}

function LayoutMinimal({ products, onAdd, state }) {
  return (
    <div className="grid gap-10 sm:grid-cols-2">
      {products.map((p) => (
        <article key={p.id} className="group text-center">
          <div className="relative overflow-hidden rounded-3xl bg-slate-100 dark:bg-slate-900">
            <Img p={p} className="aspect-square w-full transition-transform duration-500 group-hover:scale-[1.03]" />
            <WishHeart state={state} product={p} className="absolute right-4 top-4" />
            <div className="absolute left-4 top-4 flex flex-wrap gap-1"><Badges p={p} /></div>
          </div>
          <h2 className="mt-5 text-xl font-light tracking-wide text-slate-900 dark:text-white">{p.name}</h2>
          <p className="mt-1 text-sm text-slate-400">{p.category}</p>
          <div className="mt-2 flex justify-center"><Price p={p} /></div>
          <BuyButton p={p} onAdd={onAdd} className="mt-4" />
        </article>
      ))}
    </div>
  );
}

function LayoutRevista({ products, onAdd, state }) {
  return (
    <div className="space-y-12">
      {products.map((p, i) => (
        <article key={p.id} className={`flex flex-col items-center gap-8 md:flex-row ${i % 2 ? "md:flex-row-reverse" : ""}`}>
          <div className="relative w-full overflow-hidden rounded-3xl shadow-lg md:w-1/2">
            <Img p={p} className="h-72 w-full md:h-96" />
            <WishHeart state={state} product={p} className="absolute right-4 top-4" />
            <div className="absolute left-4 top-4 flex flex-wrap gap-1"><Badges p={p} /></div>
          </div>
          <div className="w-full md:w-1/2">
            <p className="text-xs font-bold uppercase tracking-[0.25em] text-amber-600 dark:text-amber-400">
              Nº {String(i + 1).padStart(2, "0")} · {p.category || "Produto"}
            </p>
            <h2 className="mt-2 font-serif text-4xl font-bold leading-tight text-slate-900 dark:text-white">{p.name}</h2>
            <p className="mt-4 text-lg leading-relaxed text-slate-600 dark:text-slate-300">{p.description}</p>
            <div className="mt-5"><Price p={p} big /></div>
            <BuyButton p={p} onAdd={onAdd} className="mt-5" />
          </div>
        </article>
      ))}
    </div>
  );
}

const LAYOUTS = {
  grade: LayoutGrade,
  lista: LayoutLista,
  vitrine: LayoutVitrine,
  minimal: LayoutMinimal,
  revista: LayoutRevista,
};

/* ----------------------------- Página ----------------------------- */

export default function Loja({ state }) {
  const [cart, setCartState] = useState(getCart);
  const [open, setOpen] = useState(false);
  const [done, setDone] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const [lastTotal, setLastTotal] = useState(0);

  const allProducts = state.loja?.products || [];
  const items = useMemo(
    () =>
      cart
        .map((i) => {
          const p = allProducts.find((x) => x.id === i.productId);
          return p && !isAffiliate(p) ? { ...i, product: p } : null;
        })
        .filter(Boolean),
    [cart, allProducts]
  );

  // Toggle no painel: loja desabilitada → 404
  if (state.features?.loja === false) return <NotFound state={state} />;

  const products = allProducts.filter((p) => p.active);
  const template = LAYOUTS[state.loja?.template] ? state.loja.template : "grade";
  const Layout = LAYOUTS[template];
  const cartCount = items.reduce((s, i) => s + i.qty, 0);
  const total = items.reduce((s, i) => s + i.product.price * i.qty, 0);

  const add = (p) => {
    const next = [...cart];
    const found = next.find((i) => i.productId === p.id);
    if (found) found.qty += 1;
    else next.push({ productId: p.id, qty: 1 });
    setCart(next);
    setCartState(next);
  };
  const setQty = (productId, qty) => {
    const next = cart.map((i) => (i.productId === productId ? { ...i, qty } : i)).filter((i) => i.qty > 0);
    setCart(next);
    setCartState(next);
  };

  const checkout = (e) => {
    e.preventDefault();
    setError("");
    if (!name.trim() || !email.trim()) return setError("Informe nome e e-mail para finalizar.");
    updateState((s) => {
      s.loja.orders.unshift({
        id: uid(),
        items: items.map((i) => ({ productId: i.productId, name: i.product.name, price: i.product.price, qty: i.qty })),
        total,
        customer: { name: name.trim(), email: email.trim() },
        createdAt: new Date().toISOString(),
        status: "novo",
      });
    });
    setLastTotal(total);
    setCart([]);
    setCartState([]);
    setDone(true);
  };

  return (
    <PublicLayout state={state}>
      <section className="relative overflow-hidden bg-slate-950 text-white">
        <div
          className="pointer-events-none absolute inset-0 opacity-40"
          style={{
            background:
              "radial-gradient(60% 80% at 20% 10%, rgba(245,158,11,.25), transparent 60%), radial-gradient(50% 70% at 85% 20%, rgba(16,185,129,.22), transparent 60%)",
          }}
          aria-hidden="true"
        />
        <div className="relative mx-auto flex max-w-7xl flex-wrap items-end justify-between gap-4 px-4 py-14">
          <div>
            <p className="animate-fade-up text-xs font-bold uppercase tracking-[0.25em] text-amber-400">🛒 Loja virtual</p>
            <h1 className="animate-fade-up mt-3 text-4xl font-extrabold tracking-tight sm:text-5xl">Produtos oficiais</h1>
            <p className="animate-fade-up mt-3 max-w-xl text-slate-300">
              {products.length} produto{products.length === 1 ? "" : "s"} — produtos próprios vão para o carrinho;
              produtos de afiliados abrem o site parceiro.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setOpen(true)}
            className="relative rounded-xl bg-amber-500 px-5 py-3 text-sm font-bold text-white shadow-lg shadow-amber-500/25 transition hover:bg-amber-400"
          >
            🛒 Carrinho
            {cartCount > 0 && (
              <span className="absolute -right-2 -top-2 flex h-6 w-6 items-center justify-center rounded-full bg-rose-500 text-xs font-bold">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-12" data-layout={template}>
        {products.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-14 text-center dark:border-slate-700 dark:bg-slate-900">
            <p className="text-5xl" aria-hidden="true">🛍️</p>
            <p className="mt-3 font-semibold text-slate-700 dark:text-slate-200">Nenhum produto publicado ainda.</p>
          </div>
        ) : (
          <Layout products={products} onAdd={add} state={state} />
        )}
      </section>

      <Modal open={open} onClose={() => { setOpen(false); setDone(false); }} title="🛒 Seu carrinho" wide>
        {done ? (
          <div className="py-6 text-center">
            <p className="text-5xl" aria-hidden="true">✅</p>
            <h3 className="mt-3 text-xl font-bold text-slate-900 dark:text-white">Pedido registrado!</h3>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              Seu pedido de <strong>{brl(lastTotal)}</strong> foi enviado e aparece na sessão Loja do painel.
            </p>
            <button type="button" onClick={() => { setDone(false); setOpen(false); }}
              className="mt-5 rounded-xl bg-amber-500 px-5 py-2.5 text-sm font-bold text-slate-950 hover:bg-amber-400">
              Continuar comprando
            </button>
          </div>
        ) : items.length === 0 ? (
          <div className="py-8 text-center">
            <p className="text-4xl" aria-hidden="true">🛒</p>
            <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">Seu carrinho está vazio.</p>
          </div>
        ) : (
          <div className="space-y-4">
            <ul className="divide-y divide-slate-200 dark:divide-slate-700">
              {items.map(({ product: p, qty }) => (
                <li key={p.id} className="flex items-center gap-3 py-3">
                  {p.image && <img src={p.image} alt="" className="h-12 w-12 rounded-lg object-cover" />}
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold text-slate-800 dark:text-slate-100">{p.name}</p>
                    <p className="text-xs text-slate-400">{brl(p.price)} cada</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button type="button" aria-label="Diminuir" onClick={() => setQty(p.id, qty - 1)} className="h-7 w-7 rounded-lg border border-slate-300 dark:border-slate-600">−</button>
                    <span className="w-6 text-center text-sm font-bold">{qty}</span>
                    <button type="button" aria-label="Aumentar" onClick={() => setQty(p.id, qty + 1)} className="h-7 w-7 rounded-lg border border-slate-300 dark:border-slate-600">＋</button>
                  </div>
                  <span className="w-24 text-right text-sm font-bold text-slate-800 dark:text-slate-100">{brl(p.price * qty)}</span>
                </li>
              ))}
            </ul>
            <p className="text-right text-lg font-extrabold text-slate-900 dark:text-white">
              Total: <span className="text-amber-600 dark:text-amber-400">{brl(total)}</span>
            </p>
            <form onSubmit={checkout} className="grid gap-3 border-t border-slate-200 pt-4 dark:border-slate-700 sm:grid-cols-2">
              <input className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                placeholder="Seu nome" value={name} onChange={(e) => setName(e.target.value)} required />
              <input type="email" className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                placeholder="Seu e-mail" value={email} onChange={(e) => setEmail(e.target.value)} required />
              {error && <p role="alert" className="text-sm text-rose-500 sm:col-span-2">{error}</p>}
              <button type="submit" className="rounded-xl bg-amber-500 px-5 py-2.5 text-sm font-bold text-slate-950 transition hover:bg-amber-400 sm:col-span-2">
                Finalizar compra — {brl(total)}
              </button>
            </form>
          </div>
        )}
      </Modal>
    </PublicLayout>
  );
}
