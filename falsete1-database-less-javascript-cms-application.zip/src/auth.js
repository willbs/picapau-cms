// Autenticação e segurança — tudo em JavaScript puro, persistido no LocalStorage.
// Vários usuários cadastrados (e-mail + hash SHA-256), sessão por token,
// rate limit, bloqueio por tentativas, logs e tokens de "esqueci a senha".
import { loadState, updateState } from "./store.js";
import { uid } from "./utils.js";

const SESSION_KEY = "picapau_session_v1";
const ATTEMPTS_KEY = "picapau_attempts_v1";
const RESET_KEY = "picapau_reset_v1";
const SALT = "pica-pau-cms-v1";

const MAX_FAILS = 5; // tentativas falhas dentro da janela antes de bloquear
const WINDOW_MS = 60 * 1000; // janela de 60 segundos
const LOCK_MS = 5 * 60 * 1000; // bloqueio de 5 minutos
const RESET_TTL_MS = 30 * 60 * 1000; // link de redefinição vale 30 minutos

/* ------------------------------------------------------------------ */
/* SHA-256: usa WebCrypto quando disponível; caso contrário, cai para  */
/* uma implementação pura em JS (útil em http não-localhost).          */
/* ------------------------------------------------------------------ */

function sha256Pure(str) {
  function rr(v, a) {
    return (v >>> a) | (v << (32 - a));
  }
  const maxWord = Math.pow(2, 32);
  const bytes = new TextEncoder().encode(str);
  let bin = "";
  for (const b of bytes) bin += String.fromCharCode(b);

  const k = [];
  const hInit = [];
  const isComposite = {};
  let primeCounter = 0;
  for (let candidate = 2; primeCounter < 64; candidate++) {
    if (!isComposite[candidate]) {
      for (let i = 0; i < 313; i += candidate) isComposite[i] = candidate;
      hInit[primeCounter] = (Math.pow(candidate, 0.5) * maxWord) | 0;
      k[primeCounter++] = (Math.pow(candidate, 1 / 3) * maxWord) | 0;
    }
  }

  let msg = bin + "\x80";
  while (msg.length % 64 !== 56) msg += "\x00";
  const words = [];
  for (let i = 0; i < msg.length; i++) {
    words[i >> 2] = (words[i >> 2] || 0) | (msg.charCodeAt(i) << (((3 - i) % 4) * 8));
  }
  words[words.length] = Math.floor((bin.length * 8) / maxWord);
  words[words.length] = bin.length * 8;

  let hash = hInit.slice(0, 8);
  for (let j = 0; j < words.length; ) {
    const w = words.slice(j, (j += 16));
    const oldHash = hash.slice();
    for (let i = 0; i < 64; i++) {
      const a = hash[0];
      const e = hash[4];
      const w15 = w[i - 15];
      const w2 = w[i - 2];
      const temp1 =
        hash[7] +
        (rr(e, 6) ^ rr(e, 11) ^ rr(e, 25)) +
        ((e & hash[5]) ^ (~e & hash[6])) +
        k[i] +
        (w[i] =
          i < 16
            ? w[i]
            : (w[i - 16] +
                (rr(w15, 7) ^ rr(w15, 18) ^ (w15 >>> 3)) +
                w[i - 7] +
                (rr(w2, 17) ^ rr(w2, 19) ^ (w2 >>> 10))) |
              0);
      const temp2 =
        (rr(a, 2) ^ rr(a, 13) ^ rr(a, 22)) +
        ((a & hash[1]) ^ (a & hash[2]) ^ (hash[1] & hash[2]));
      hash = [(temp1 + temp2) | 0].concat(hash.slice(0, 7));
      hash[4] = (hash[4] + temp1) | 0;
    }
    for (let i = 0; i < 8; i++) hash[i] = (hash[i] + oldHash[i]) | 0;
  }

  let result = "";
  for (let i = 0; i < 8; i++) {
    for (let j = 3; j >= 0; j--) {
      const b = (hash[i] >> (j * 8)) & 255;
      result += (b < 16 ? "0" : "") + b.toString(16);
    }
  }
  return result;
}

/** Hash SHA-256 em hexadecimal de uma string. */
export async function sha256Hex(str) {
  if (
    typeof crypto !== "undefined" &&
    crypto.subtle &&
    (window.isSecureContext || location.protocol === "https:")
  ) {
    const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(str));
    return Array.from(new Uint8Array(buf))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");
  }
  return sha256Pure(str);
}

/** Hash da senha (salt + senha). */
export async function hashPassword(password) {
  return sha256Hex(`${SALT}::${password}`);
}

/* ------------------------------------------------------------------ */
/* Usuários cadastrados                                                */
/* ------------------------------------------------------------------ */

export function getUsers() {
  return loadState().security.users || [];
}

export function findUserByEmail(email) {
  const e = String(email || "").trim().toLowerCase();
  return getUsers().find((u) => u.email.toLowerCase() === e) || null;
}

/** Autentica e-mail + senha; retorna o usuário (ativo) ou null. */
export async function authenticate(email, password) {
  const user = findUserByEmail(email);
  if (!user || !user.active) return null;
  const hash = await hashPassword(password);
  return hash === user.passwordHash ? user : null;
}

/** Compatibilidade: retorna true/false. */
export async function verifyCredentials(email, password) {
  return !!(await authenticate(email, password));
}

/** Cria um novo usuário manualmente (painel de segurança). */
export async function createUser({ email, password, role = "editor", active = true, verified = true }) {
  const e = String(email || "").trim().toLowerCase();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e)) return { ok: false, error: "Informe um e-mail válido." };
  if (findUserByEmail(e)) return { ok: false, error: "Já existe um usuário com esse e-mail." };
  if (!password || password.length < 6)
    return { ok: false, error: "A senha precisa de pelo menos 6 caracteres." };
  const hash = await hashPassword(password);
  const user = {
    id: uid(),
    email: e,
    passwordHash: hash,
    role: role === "admin" ? "admin" : "editor",
    active: !!active,
    emailVerified: !!verified, // cadastros públicos começam como false até confirmar o e-mail
    createdAt: new Date().toISOString(),
  };
  updateState((s) => {
    s.security.users.push(user);
  });
  addLog("seguranca", `Novo usuário cadastrado: ${e} (${user.role})`);
  return { ok: true, user };
}

/* ------------------------------------------------------------------ */
/* Confirmação de e-mail (cadastro público)                            */
/* ------------------------------------------------------------------ */

const VERIFY_TTL_MS = 48 * 60 * 60 * 1000; // link vale 48 horas

/** Gera (ou renova) o token de confirmação do usuário. */
export function createVerifyToken(userId) {
  const token = uid() + uid();
  updateState((s) => {
    const u = s.security.users.find((x) => x.id === userId);
    if (u) {
      u.verifyToken = token;
      u.verifyExpires = Date.now() + VERIFY_TTL_MS;
    }
  });
  return token;
}

export function verifyUrl(token) {
  return `${location.origin}/#/login/confirmar/${token}`;
}

/** Confirma o e-mail pelo token do link. */
export function verifyEmail(token) {
  const user = getUsers().find((u) => u.verifyToken && u.verifyToken === token);
  if (!user) return { ok: false, error: "Link de confirmação inválido ou já utilizado." };
  if (user.verifyExpires && Date.now() > user.verifyExpires) {
    return { ok: false, error: "Este link de confirmação expirou. Faça login para receber um novo." };
  }
  updateState((s) => {
    const u = s.security.users.find((x) => x.id === user.id);
    if (u) {
      u.emailVerified = true;
      u.verifyToken = null;
      u.verifyExpires = null;
    }
  });
  addLog("seguranca", `E-mail confirmado: ${user.email}`);
  return { ok: true, user };
}

/** Destino após o login: administradores vão ao painel; editores ficam no site (front-end). */
export function homeFor(user) {
  return user && user.role === "admin" ? "/admin" : "/";
}

/** Define uma nova senha diretamente para um usuário (admin). */
export async function setUserPassword(userId, next) {
  if (!next || next.length < 6) return { ok: false, error: "A senha precisa de pelo menos 6 caracteres." };
  const hash = await hashPassword(next);
  updateState((s) => {
    const u = s.security.users.find((x) => x.id === userId);
    if (u) u.passwordHash = hash;
  });
  const u = getUsers().find((x) => x.id === userId);
  addLog("seguranca", `Senha redefinida pelo administrador para ${u?.email || userId}`);
  return { ok: true };
}

/** Ativa/desativa ou muda a role de um usuário. */
export function updateUser(userId, patch) {
  updateState((s) => {
    const u = s.security.users.find((x) => x.id === userId);
    if (u) Object.assign(u, patch);
  });
}

/** Remove um usuário (protege o último administrador ativo). */
export function deleteUser(userId) {
  const users = getUsers();
  const target = users.find((u) => u.id === userId);
  if (!target) return { ok: false, error: "Usuário não encontrado." };
  const activeAdmins = users.filter((u) => u.role === "admin" && u.active);
  if (target.role === "admin" && activeAdmins.length <= 1) {
    return { ok: false, error: "Não é possível remover o último administrador ativo." };
  }
  updateState((s) => {
    s.security.users = s.security.users.filter((u) => u.id !== userId);
  });
  addLog("seguranca", `Usuário removido: ${target.email}`);
  return { ok: true };
}

/* ------------------------------------------------------------------ */
/* Sessão (token no LocalStorage, com expiração e inatividade)          */
/* ------------------------------------------------------------------ */

export function getSessionMinutes() {
  const s = loadState();
  return Number(s.security.sessionMinutes) || 30;
}

export function createSession(user) {
  const minutes = getSessionMinutes();
  const now = Date.now();
  const session = {
    token: uid(),
    userId: user.id,
    email: user.email,
    role: user.role,
    createdAt: now,
    lastActivity: now,
    expiresAt: now + minutes * 60 * 1000,
  };
  localStorage.setItem(SESSION_KEY, JSON.stringify(session));
  return session;
}

export function getSession() {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    const s = JSON.parse(raw);
    if (!s.token || Date.now() > s.expiresAt) {
      localStorage.removeItem(SESSION_KEY);
      return null;
    }
    return s;
  } catch {
    return null;
  }
}

/** Usuário da sessão atual (ou null). */
export function getCurrentUser() {
  const s = getSession();
  if (!s) return null;
  return getUsers().find((u) => u.id === s.userId) || null;
}

/** A sessão atual pertence a um administrador? */
export function isAdmin() {
  const u = getCurrentUser();
  return !!u && u.role === "admin" && u.active;
}

/** Renova a atividade da sessão (expiração deslizante). */
export function touchSession() {
  const s = getSession();
  if (!s) return;
  s.lastActivity = Date.now();
  s.expiresAt = Date.now() + getSessionMinutes() * 60 * 1000;
  localStorage.setItem(SESSION_KEY, JSON.stringify(s));
}

export function destroySession() {
  localStorage.removeItem(SESSION_KEY);
}

export function isAuthenticated() {
  const s = getSession();
  if (!s) return false;
  const u = getUsers().find((x) => x.id === s.userId);
  return !!u && u.active;
}

/** Logout por inatividade: retorna true se a sessão expirou por inatividade. */
export function checkInactivity() {
  const s = getSession();
  if (!s) return false;
  const limit = getSessionMinutes() * 60 * 1000;
  return Date.now() - s.lastActivity > limit;
}

/* ------------------------------------------------------------------ */
/* Rate limiting simples + bloqueio por tentativas repetidas           */
/* ------------------------------------------------------------------ */

function getFlags() {
  const s = loadState().security;
  return { rateLimit: s.rateLimit !== false, lockout: s.lockout !== false };
}

function getAttempts() {
  try {
    return JSON.parse(localStorage.getItem(ATTEMPTS_KEY)) || { fails: [], lockUntil: 0 };
  } catch {
    return { fails: [], lockUntil: 0 };
  }
}

/**
 * Retorna o status de proteção:
 * { locked, lockRemaining, limited, limitRemaining, fails }
 */
export function getProtectionStatus() {
  const flags = getFlags();
  const a = getAttempts();
  const now = Date.now();
  if (flags.lockout && a.lockUntil > now) {
    return { locked: true, lockRemaining: Math.ceil((a.lockUntil - now) / 1000), fails: a.fails.length };
  }
  const recent = a.fails.filter((t) => now - t < WINDOW_MS);
  if (flags.lockout && recent.length >= MAX_FAILS) {
    return { locked: true, lockRemaining: Math.ceil(LOCK_MS / 1000), fails: recent.length };
  }
  if (flags.rateLimit && recent.length >= 3) {
    const oldest = recent[0];
    return {
      locked: false,
      limited: true,
      limitRemaining: Math.max(1, Math.ceil((WINDOW_MS - (now - oldest)) / 1000)),
      fails: recent.length,
    };
  }
  return { locked: false, fails: recent.length };
}

/** Registra uma tentativa de login malsucedida. */
export function registerFailure() {
  const flags = getFlags();
  const a = getAttempts();
  const now = Date.now();
  a.fails = a.fails.filter((t) => now - t < WINDOW_MS).concat([now]);
  if (flags.lockout && a.fails.length >= MAX_FAILS) {
    a.lockUntil = now + LOCK_MS;
  }
  localStorage.setItem(ATTEMPTS_KEY, JSON.stringify(a));
}

/** Limpa as tentativas após login bem-sucedido. */
export function registerSuccess() {
  localStorage.removeItem(ATTEMPTS_KEY);
}

/* ------------------------------------------------------------------ */
/* "Esqueci a senha": tokens de redefinição (simulados, sem servidor    */
/* de e-mail — o link é gerado e exibido na própria tela, como demo).   */
/* ------------------------------------------------------------------ */

function getResetTokens() {
  try {
    return JSON.parse(localStorage.getItem(RESET_KEY)) || [];
  } catch {
    return [];
  }
}

/** Gera um token de redefinição para o e-mail (se cadastrado e ativo). */
export function createResetToken(email) {
  const user = findUserByEmail(email);
  if (!user || !user.active) return null;
  const token = uid() + uid();
  const tokens = getResetTokens()
    .filter((t) => !t.used && t.expiresAt > Date.now())
    .concat([{ token, userId: user.id, email: user.email, expiresAt: Date.now() + RESET_TTL_MS, used: false }]);
  localStorage.setItem(RESET_KEY, JSON.stringify(tokens.slice(-20)));
  addLog("seguranca", `Link de redefinição de senha gerado para ${user.email}`);
  return token;
}

/** Valida um token (existe, não usado, não expirado). */
export function getResetToken(token) {
  return (
    getResetTokens().find((t) => t.token === token && !t.used && t.expiresAt > Date.now()) || null
  );
}

/** URL interna do link de redefinição (funciona com path ou hash). */
export function resetUrl(token) {
  return `${location.origin}/#/login/redefinir/${token}`;
}

/** Redefine a senha usando o token e consome o token. */
export async function resetPasswordWithToken(token, next) {
  const t = getResetToken(token);
  if (!t) return { ok: false, error: "Link inválido ou expirado. Solicite um novo." };
  if (!next || next.length < 6)
    return { ok: false, error: "A nova senha precisa de pelo menos 6 caracteres." };
  const hash = await hashPassword(next);
  updateState((s) => {
    const u = s.security.users.find((x) => x.id === t.userId);
    if (u) u.passwordHash = hash;
  });
  const tokens = getResetTokens().map((x) => (x.token === token ? { ...x, used: true } : x));
  localStorage.setItem(RESET_KEY, JSON.stringify(tokens));
  addLog("seguranca", `Senha redefinida via link de recuperação para ${t.email}`);
  destroySession();
  return { ok: true };
}

/* ------------------------------------------------------------------ */
/* Troca de senha do usuário logado                                    */
/* ------------------------------------------------------------------ */

export async function changePassword(current, next) {
  const user = getCurrentUser();
  if (!user) return { ok: false, error: "Nenhuma sessão ativa." };
  const hash = await hashPassword(current);
  if (hash !== user.passwordHash) return { ok: false, error: "Senha atual incorreta." };
  return setUserPassword(user.id, next);
}

/* ------------------------------------------------------------------ */
/* Logs de acesso (guardados no estado do CMS)                         */
/* ------------------------------------------------------------------ */

export function addLog(type, message) {
  updateState((s) => {
    s.security.logs.unshift({
      id: uid(),
      time: new Date().toISOString(),
      type,
      message,
    });
    s.security.logs = s.security.logs.slice(0, 300);
  });
}
