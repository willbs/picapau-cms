// Upload de arquivos sem back-end: o arquivo é convertido para DataURL
// (imagens são redimensionadas/comprimidas via canvas) e salvo no LocalStorage.
const MAX_MEDIA_BYTES = 2.5 * 1024 * 1024; // limite p/ áudio/vídeo (LocalStorage ~5MB no total)

/** Formata bytes em KB/MB. */
export function formatBytes(n) {
  if (!n && n !== 0) return "";
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(2)} MB`;
}

/** Lê um arquivo como DataURL. */
export function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.onerror = () => reject(new Error("Falha ao ler o arquivo."));
    r.readAsDataURL(file);
  });
}

/**
 * Converte imagem para DataURL comprimido (redimensiona se passar de maxDim).
 * SVG é mantido como texto (data:image/svg+xml).
 */
export async function imageFileToDataUrl(file, { maxDim = 1280, quality = 0.82 } = {}) {
  if (!file.type.startsWith("image/")) throw new Error("Selecione um arquivo de imagem.");
  if (file.type === "image/svg+xml") return fileToDataUrl(file);
  const url = URL.createObjectURL(file);
  try {
    const imgEl = new Image();
    await new Promise((res, rej) => {
      imgEl.onload = res;
      imgEl.onerror = () => rej(new Error("Imagem inválida."));
      imgEl.src = url;
    });
    const scale = Math.min(1, maxDim / Math.max(imgEl.width, imgEl.height, 1));
    const w = Math.max(1, Math.round(imgEl.width * scale));
    const h = Math.max(1, Math.round(imgEl.height * scale));
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    canvas.getContext("2d").drawImage(imgEl, 0, 0, w, h);
    return canvas.toDataURL("image/jpeg", quality);
  } finally {
    URL.revokeObjectURL(url);
  }
}

/** Áudio/vídeo: guarda o arquivo inteiro como DataURL (com limite de tamanho). */
export async function mediaFileToDataUrl(file) {
  if (!file.type.startsWith("audio/") && !file.type.startsWith("video/")) {
    throw new Error("Selecione um arquivo de áudio ou vídeo.");
  }
  if (file.size > MAX_MEDIA_BYTES) {
    throw new Error(
      `Arquivo muito grande (${formatBytes(file.size)}). Limite do armazenamento local: ${formatBytes(
        MAX_MEDIA_BYTES
      )}. Prefira informar uma URL externa.`
    );
  }
  return fileToDataUrl(file);
}
