// Armazenamento de mídias grandes (imagens e áudios de até 15 MB) no IndexedDB do navegador.
// O LocalStorage (≈5 MB no total) não comporta esses arquivos; aqui guardamos o arquivo original (Blob)
// e o perfil guarda apenas os metadados (id, título, tipo, tamanho).
import { useEffect, useState } from "react";
import { uid } from "./utils.js";

export const MAX_MEDIA_BYTES = 15 * 1024 * 1024; // 15 MB por arquivo
const DB = "picapau_media";
const STORE = "files";

function open() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE, { keyPath: "id" });
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function tx(mode, fn) {
  return open().then(
    (db) =>
      new Promise((resolve, reject) => {
        const t = db.transaction(STORE, mode);
        const req = fn(t.objectStore(STORE));
        t.oncomplete = () => resolve(req ? req.result : undefined);
        t.onerror = () => reject(t.error || new Error("Falha no armazenamento do navegador."));
      })
  );
}

/** Valida e guarda o arquivo; retorna os metadados. kind: "image" | "audio". */
export async function saveMediaFile(file, kind) {
  if (!file) throw new Error("Selecione um arquivo.");
  if (!file.type.startsWith(kind + "/")) throw new Error(kind === "image" ? "O arquivo precisa ser uma imagem." : "O arquivo precisa ser um áudio.");
  if (file.size > MAX_MEDIA_BYTES) {
    throw new Error(`Arquivo muito grande (${(file.size / 1048576).toFixed(1)} MB). O limite é 15 MB por arquivo.`);
  }
  const id = uid();
  await tx("readwrite", (s) => s.put({ id, blob: file, type: file.type, name: file.name, size: file.size }));
  return { id, mediaId: id, type: file.type, size: file.size, fileName: file.name };
}

export const getMediaFile = (id) => tx("readonly", (s) => s.get(id));
export const deleteMediaFile = (id) => tx("readwrite", (s) => s.delete(id));

/** URL temporária (object URL) para exibir um arquivo guardado. */
export function useMediaUrl(mediaId) {
  const [url, setUrl] = useState("");
  useEffect(() => {
    let alive = true;
    let objectUrl = "";
    if (!mediaId) return undefined;
    getMediaFile(mediaId)
      .then((rec) => {
        if (!alive || !rec) return;
        objectUrl = URL.createObjectURL(rec.blob);
        setUrl(objectUrl);
      })
      .catch(() => {});
    return () => {
      alive = false;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [mediaId]);
  return url;
}

export const formatMB = (n) => (n >= 1048576 ? `${(n / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1024))} KB`);
