// Mini roteador em JavaScript puro.
// Suporta rotas reais de caminho (/login, /admin/...) e também hash (#/login),
// garantindo que a rota /login funcione em qualquer servidor estático.
import { useEffect, useState } from "react";

/** Retorna a rota atual (hash tem precedência sobre o pathname). */
export function getRoute() {
  let r = "";
  const h = window.location.hash;
  if (h && h.length > 1) r = h.slice(1);
  else r = window.location.pathname;
  r = r.replace(/\/+$/, "") || "/";
  if (!r.startsWith("/")) r = "/" + r;
  return r;
}

/** Navega para uma rota interna sem recarregar a página. */
export function navigate(to) {
  if (!to.startsWith("/")) to = "/" + to;
  if (getRoute() === to.replace(/\/+$/, "") || "/") {
    window.dispatchEvent(new Event("routechange"));
  }
  window.history.pushState({}, "", to);
  window.dispatchEvent(new Event("routechange"));
  window.scrollTo({ top: 0 });
}

/** Hook React que observa mudanças de rota. */
export function useRoute() {
  const [route, setRoute] = useState(getRoute());
  useEffect(() => {
    const handler = () => setRoute(getRoute());
    window.addEventListener("routechange", handler);
    window.addEventListener("popstate", handler);
    return () => {
      window.removeEventListener("routechange", handler);
      window.removeEventListener("popstate", handler);
    };
  }, []);
  return route;
}

/**
 * Compara uma rota com um padrão tipo "/artigo/:slug".
 * Retorna os parâmetros ou null.
 */
export function matchRoute(route, pattern) {
  const ra = route.split("/").filter(Boolean);
  const pa = pattern.split("/").filter(Boolean);
  if (ra.length !== pa.length) return null;
  const params = {};
  for (let i = 0; i < pa.length; i++) {
    if (pa[i].startsWith(":")) params[pa[i].slice(1)] = decodeURIComponent(ra[i]);
    else if (pa[i] !== ra[i]) return null;
  }
  return params;
}
