// Painel → Podcasts: botão de habilitar/desabilitar a página de podcasts
// e formulário para adicionar novos podcasts (episódios de áudio) que são
// enviados automaticamente para a página pública /podcasts (agrupados por categoria).
import { useState } from "react";
import { Card, inputCls, labelCls, btnPrimary, btnGhost, btnDanger, Badge, Toggle } from "./ui.jsx";
import { navigate } from "../router.js";
import { updateState } from "../store.js";
import { addLog } from "../auth.js";
import { uid, slugify, formatDate } from "../utils.js";
import { TEMPLATES } from "../templates/ArticleView.jsx";
import UploadField from "../components/UploadField.jsx";

function blankEpisode() {
  return {
    title: "",
    category: "",
    podcastCategory: "",
    audioUrl: "",
    cover: "",
    duration: "",
    description: "",
    template: TEMPLATES.audio[0].id,
    status: "publicado",
  };
}

export default function PodcastsAdmin({ state }) {
  const flagOn = state.features?.podcast !== false;
  const [form, setForm] = useState(blankEpisode());
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState("");
  const [ok, setOk] = useState("");

  const episodes = (state.articles || [])
    .filter((a) => a.type === "audio")
    .sort((a, b) => new Date(b.date) - new Date(a.date));

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const toggleFeature = (on) => {
    updateState((s) => {
      s.features = s.features || {};
      s.features.podcast = on;
    });
    addLog("sistema", `Página de podcasts ${on ? "HABILITADA" : "DESABILITADA"}`);
  };

  const saveEpisode = () => {
    setError("");
    setOk("");
    if (!form.title.trim()) return setError("O título do episódio é obrigatório.");
    if (!form.category) return setError("Escolha uma categoria (obrigatório).");
    if (!form.audioUrl.trim()) return setError("Informe a URL do arquivo de áudio (MP3).");
    const slug = `${slugify(form.title)}-${Date.now().toString(36)}`;
    const now = new Date().toISOString();
    const article = {
      id: uid(),
      type: "audio",
      template: form.template,
      title: form.title.trim(),
      slug,
      excerpt: form.description.trim(),
      content: form.description.trim()
        ? `<p>${form.description.trim()}</p>`
        : "",
      cover: form.cover.trim(),
      author: "Podcast Pica-Pau",
      date: now,
      scheduledAt: "",
      status: form.status,
      categories: [form.category],
      podcastCategory: form.podcastCategory,
      seo: {
        title: `${form.title.trim()} | Podcasts`,
        description: form.description.trim().slice(0, 160),
        keywords: "podcast, episódio, áudio",
        ogImage: form.cover.trim(),
        canonical: "",
      },
      media: {
        image: { url: "", alt: "", caption: "", gallery: [] },
        video: { url: "", poster: "", duration: "", transcript: "" },
        audio: {
          url: form.audioUrl.trim(),
          cover: form.cover.trim(),
          duration: form.duration.trim(),
          transcript: "",
          timestamps: [],
        },
      },
      createdAt: now,
      updatedAt: now,
    };
    updateState((s) => {
      s.articles.unshift(article);
    });
    addLog("sistema", `Podcast adicionado: ${article.title} (${article.status})`);
    setForm(blankEpisode());
    setShowForm(false);
    setOk(`Episódio "${article.title}" ${article.status === "publicado" ? "publicado" : "salvo"} — já aparece em /podcasts.`);
  };

  const remove = (a) => {
    if (!window.confirm(`Excluir o episódio "${a.title}"?`)) return;
    updateState((s) => {
      s.articles = s.articles.filter((x) => x.id !== a.id);
    });
  };

  /* ----- categorias exclusivas de podcast ----- */
  const pcats = state.podcast?.categories || [];
  const [pcName, setPcName] = useState("");
  const [pcIcon, setPcIcon] = useState("🎙️");
  const [pcError, setPcError] = useState("");
  const addPodcastCat = (e) => {
    e.preventDefault();
    setPcError("");
    const name = pcName.trim();
    if (!name) return setPcError("Informe o nome da categoria.");
    const slug = slugify(name);
    if (pcats.some((c) => c.slug === slug)) return setPcError("Já existe uma categoria de podcast com esse nome.");
    const colors = ["#6366f1", "#8b5cf6", "#f59e0b", "#06b6d4", "#10b981", "#ef4444", "#ec4899"];
    updateState((s) => {
      s.podcast = s.podcast || { categories: [] };
      s.podcast.categories.push({ id: uid(), slug, name, icon: pcIcon || "🎙️", color: colors[s.podcast.categories.length % colors.length] });
    });
    addLog("sistema", `Categoria de podcast criada: ${name}`);
    setPcName("");
  };
  const removePodcastCat = (c) => {
    const n = episodes.filter((a) => a.podcastCategory === c.slug).length;
    if (!window.confirm(`Remover a categoria de podcast "${c.name}"?${n ? ` ${n} episódio(s) ficarão em "Outros".` : ""}`)) return;
    updateState((s) => {
      s.podcast.categories = s.podcast.categories.filter((x) => x.id !== c.id);
      s.articles.forEach((a) => { if (a.podcastCategory === c.slug) a.podcastCategory = ""; });
    });
    addLog("sistema", `Categoria de podcast removida: ${c.name}`);
  };
  const setEpisodeCat = (id, slug) => updateState((s) => {
    const a = s.articles.find((x) => x.id === id);
    if (a) a.podcastCategory = slug;
  });

  const catName = (slug) => state.categories.find((c) => c.slug === slug)?.name || slug;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-white">🎧 Podcasts</h1>
          <p className="mt-1 text-sm text-slate-400">
            Episódios publicados aparecem na página pública <code className="rounded bg-slate-800 px-1.5 py-0.5 text-amber-300">/podcasts</code>,
            separados por categoria.
          </p>
        </div>
        <div className="flex gap-2">
          <a href="/podcasts" onClick={(e) => { e.preventDefault(); navigate("/podcasts"); }} className={btnGhost}>
            🌐 Ver página pública
          </a>
          <button type="button" className={btnPrimary} onClick={() => setShowForm((v) => !v)}>
            {showForm ? "Fechar formulário" : "+ Adicionar podcast"}
          </button>
        </div>
      </div>

      {/* Habilitar / desabilitar a opção de podcast */}
      <Card title="Opção de podcast">
        <Toggle
          label={flagOn ? "Página de podcasts HABILITADA" : "Página de podcasts DESABILITADA"}
          desc={
            flagOn
              ? "A página /podcasts está no ar e o link aparece no menu do site."
              : "A página /podcasts retorna 404 e o link sai do menu (os episódios continuam salvos)."
          }
          checked={flagOn}
          onChange={toggleFeature}
        />
      </Card>

      {ok && (
        <p role="status" className="rounded-xl border border-emerald-500/40 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-300">{ok}</p>
      )}

      {/* Categorias exclusivas de podcast */}
      <Card title={`🗂️ Categorias de podcast (${pcats.length})`} subtitle="Categorias usadas somente na página /podcasts — independentes das categorias do site.">
        <form onSubmit={addPodcastCat} className="flex flex-wrap items-center gap-2">
          <input className={`${inputCls} w-20 text-center`} value={pcIcon} maxLength={4} onChange={(e) => setPcIcon(e.target.value)} aria-label="Ícone da categoria de podcast" />
          <input className={`${inputCls} min-w-0 flex-1 basis-48`} value={pcName} onChange={(e) => setPcName(e.target.value)} placeholder="Nome da nova categoria (ex.: Entrevistas)" aria-label="Nome da categoria de podcast" />
          <button type="submit" className={btnPrimary}>+ Adicionar categoria</button>
        </form>
        {pcError && <p role="alert" className="mt-2 text-sm text-rose-400">{pcError}</p>}
        <ul className="mt-4 flex flex-wrap gap-2" data-podcast-cats>
          {pcats.map((c) => (
            <li key={c.id} className="flex items-center gap-2 rounded-full border border-slate-700 bg-slate-800/60 py-1 pl-3 pr-1 text-sm text-slate-200">
              <span aria-hidden="true">{c.icon}</span> {c.name}
              <span className="text-xs text-slate-500">({episodes.filter((a) => a.podcastCategory === c.slug).length})</span>
              <button type="button" onClick={() => removePodcastCat(c)} aria-label={`Remover categoria ${c.name}`}
                className="flex h-6 w-6 items-center justify-center rounded-full text-xs text-rose-300 hover:bg-rose-500/20">✕</button>
            </li>
          ))}
          {pcats.length === 0 && <li className="text-sm text-slate-500">Nenhuma categoria de podcast.</li>}
        </ul>
      </Card>

      {/* Formulário de novo podcast */}
      {showForm && (
        <Card title="Novo podcast (episódio)" subtitle="Será criado como artigo do tipo Áudio e enviado para /podcasts.">
          <div className="space-y-4">
            {error && <p role="alert" className="rounded-lg border border-rose-500/40 bg-rose-500/10 px-3 py-2 text-sm text-rose-300">{error}</p>}
            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <label htmlFor="p-title" className={labelCls}>Título do episódio *</label>
                <input id="p-title" className={inputCls} value={form.title} onChange={(e) => set("title", e.target.value)} placeholder="Ex.: Episódio #12 — …" />
              </div>
              <div>
                <label htmlFor="p-cat" className={labelCls}>Categoria do site *</label>
                <select id="p-cat" className={inputCls} value={form.category} onChange={(e) => set("category", e.target.value)}>
                  <option value="">— escolha a categoria —</option>
                  {state.categories.map((c) => (
                    <option key={c.id} value={c.slug}>{c.icon} {c.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label htmlFor="p-pcat" className={labelCls}>Categoria de podcast</label>
                <select id="p-pcat" className={inputCls} value={form.podcastCategory} onChange={(e) => set("podcastCategory", e.target.value)}>
                  <option value="">— sem categoria de podcast —</option>
                  {(state.podcast?.categories || []).map((c) => <option key={c.id} value={c.slug}>{c.icon} {c.name}</option>)}
                </select>
              </div>
              <div>
                <label htmlFor="p-audio" className={labelCls}>Áudio: URL ou upload (MP3) *</label>
                <div className="flex flex-wrap items-center gap-2">
                  <input id="p-audio" className={`${inputCls} min-w-0 flex-1`} value={form.audioUrl} onChange={(e) => set("audioUrl", e.target.value)} placeholder="https://…/episodio.mp3" />
                  <UploadField kind="audio" label="Upload áudio" onUploaded={(d) => set("audioUrl", d)} />
                </div>
                {form.audioUrl && <audio controls src={form.audioUrl} className="mt-2 w-full" style={{ height: 36 }} />}
              </div>
              <div>
                <label htmlFor="p-cover" className={labelCls}>Capa — URL ou upload</label>
                <div className="flex flex-wrap items-center gap-2">
                  <input id="p-cover" className={`${inputCls} min-w-0 flex-1`} value={form.cover} onChange={(e) => set("cover", e.target.value)} placeholder="https://…/capa-800x800.jpg" />
                  <UploadField kind="image" label="Upload capa" onUploaded={(d) => set("cover", d)} />
                </div>
                {form.cover && <img src={form.cover} alt="Capa" className="mt-2 h-20 w-20 rounded-lg border border-slate-700 object-cover" />}
              </div>
              <div>
                <label htmlFor="p-dur" className={labelCls}>Duração</label>
                <input id="p-dur" className={inputCls} value={form.duration} onChange={(e) => set("duration", e.target.value)} placeholder="32:10" />
              </div>
              <div>
                <label htmlFor="p-tpl" className={labelCls}>Modelo do player</label>
                <select id="p-tpl" className={inputCls} value={form.template} onChange={(e) => set("template", e.target.value)}>
                  {TEMPLATES.audio.map((t) => (
                    <option key={t.id} value={t.id}>{t.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label htmlFor="p-status" className={labelCls}>Status</label>
                <select id="p-status" className={inputCls} value={form.status} onChange={(e) => set("status", e.target.value)}>
                  <option value="publicado">Publicado (aparece em /podcasts)</option>
                  <option value="rascunho">Rascunho</option>
                </select>
              </div>
            </div>
            <div>
              <label htmlFor="p-desc" className={labelCls}>Descrição</label>
              <textarea id="p-desc" className={inputCls} rows={3} value={form.description} onChange={(e) => set("description", e.target.value)} placeholder="Sobre o que é este episódio…" />
            </div>
            <div className="flex justify-end gap-2">
              <button type="button" className={btnGhost} onClick={() => setShowForm(false)}>Cancelar</button>
              <button type="button" className={btnPrimary} onClick={saveEpisode}>Publicar podcast</button>
            </div>
          </div>
        </Card>
      )}

      {/* Lista de episódios */}
      <Card title={`Episódios cadastrados (${episodes.length})`} subtitle="Artigos do tipo Áudio — editáveis também em Artigos.">
        {episodes.length === 0 ? (
          <p className="py-6 text-center text-sm text-slate-400">Nenhum podcast ainda. Clique em “+ Adicionar podcast”.</p>
        ) : (
          <ul className="divide-y divide-slate-800">
            {episodes.map((a) => (
              <li key={a.id} className="flex flex-wrap items-center gap-3 py-3.5">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center overflow-hidden rounded-lg bg-slate-800 text-xl" aria-hidden="true">
                  {a.media?.audio?.cover || a.cover ? (
                    <img src={a.media?.audio?.cover || a.cover} alt="" className="h-full w-full object-cover" loading="lazy" />
                  ) : (
                    "🎧"
                  )}
                </span>
                <div className="min-w-0 flex-1 basis-52">
                  <button type="button" onClick={() => navigate(`/admin/artigos/editar/${a.id}`)} className="block truncate text-left text-sm font-semibold text-slate-100 hover:text-amber-300">
                    {a.title}
                  </button>
                  <p className="truncate text-xs text-slate-500">
                    {formatDate(a.date)} · {catName(a.categories[0])} · {a.media?.audio?.duration || "—"}
                  </p>
                </div>
                <select className={`${inputCls} w-auto`} value={a.podcastCategory || ""} onChange={(e) => setEpisodeCat(a.id, e.target.value)} aria-label={`Categoria de podcast de ${a.title}`}>
                  <option value="">— sem categoria de podcast —</option>
                  {pcats.map((c) => <option key={c.id} value={c.slug}>{c.icon} {c.name}</option>)}
                </select>
                <Badge tone="audio">🎧 Áudio</Badge>
                <Badge tone={a.status}>{a.status === "publicado" ? "Publicado" : a.status === "rascunho" ? "Rascunho" : "Agendado"}</Badge>
                <div className="flex gap-2">
                  <button type="button" className={btnGhost} onClick={() => navigate(`/admin/artigos/editar/${a.id}`)}>Editar</button>
                  <button type="button" className={btnDanger} onClick={() => remove(a)}>Excluir</button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}
