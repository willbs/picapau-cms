// Painel → HTML:
// - códigos HTML / textos alternativos exibidos no INÍCIO e no FINAL de cada artigo
// - configurações e moderação dos comentários dos leitores
// - contador de visualizações (exibir/ocultar, ranking, zerar)
import { useState } from "react";
import { Card, inputCls, labelCls, btnPrimary, btnGhost, btnDanger, Badge, Toggle } from "./ui.jsx";
import { updateState } from "../store.js";
import { addLog } from "../auth.js";
import { formatDate } from "../utils.js";
import { navigate } from "../router.js";
import { articlePath } from "../permalink.js";
import { HTML_VARIABLES, renderBlock, ARTICLE_LAYOUTS, SHARE_NETWORKS } from "../pages/ArticleExtras.jsx";

const DEFAULT_HTML = {
  before: { enabled: false, mode: "html", content: "" },
  after: { enabled: false, mode: "html", content: "" },
  comments: { enabled: true, requireApproval: false },
  showViews: true,
  share: true,
  layout: "none",
};

/** Miniatura dos layouts de artigo. */
function LayoutThumb({ id }) {
  const side = <div className="w-3 rounded-sm bg-amber-400/80" />;
  const main = <div className="flex flex-1 flex-col gap-1 rounded-sm bg-slate-600/60 p-1"><div className="h-1 w-3/4 rounded bg-slate-300/70" /><div className="h-1 w-1/2 rounded bg-slate-300/70" /></div>;
  const parts = {
    none: [<div key="m" className="mx-auto flex w-2/3">{main}</div>],
    left: [<span key="a">{side}</span>, main],
    right: [main, <span key="a">{side}</span>],
    "two-left": [<span key="a">{side}</span>, <span key="b">{side}</span>, main],
    "two-right": [main, <span key="a">{side}</span>, <span key="b">{side}</span>],
  }[id];
  return <div className="flex h-14 w-full gap-1 rounded-md border border-slate-700 bg-slate-800/60 p-1.5 [&>span]:flex">{parts}</div>;
}


function BlockEditor({ title, subtitle, block, onChange, sample, state }) {
  const set = (patch) => onChange({ ...block, ...patch });
  const preview = renderBlock({ ...block, enabled: true }, sample, state);
  return (
    <Card title={title} subtitle={subtitle}>
      <div className="space-y-4">
        <Toggle label={block.enabled ? "Exibindo em todos os artigos" : "Desativado"} desc="Liga/desliga este bloco em todos os artigos."
          checked={!!block.enabled} onChange={(v) => set({ enabled: v })} />
        <div className="flex flex-wrap gap-2" role="radiogroup" aria-label={`Tipo de conteúdo — ${title}`}>
          {[{ id: "html", label: "</> Código HTML" }, { id: "texto", label: "📝 Texto alternativo" }].map((m) => (
            <button key={m.id} type="button" role="radio" aria-checked={block.mode === m.id} onClick={() => set({ mode: m.id })}
              className={`rounded-lg border px-3 py-1.5 text-xs font-semibold ${block.mode === m.id ? "border-amber-500 bg-amber-500/15 text-amber-300" : "border-slate-700 text-slate-400"}`}>
              {m.label}
            </button>
          ))}
        </div>
        <textarea
          className={`${inputCls} font-mono`}
          rows={7}
          value={block.content}
          onChange={(e) => set({ content: e.target.value })}
          placeholder={block.mode === "html" ? '<div class="aviso">📢 Assine nossa newsletter!</div>' : "Texto simples exibido no artigo…"}
          aria-label={`Conteúdo — ${title}`}
        />
        <div>
          <p className={labelCls}>Prévia (com o artigo “{sample.title.slice(0, 40)}…”)</p>
          <div className="min-h-12 rounded-xl border border-slate-700 bg-white p-3 text-slate-800">
            {preview ? <div dangerouslySetInnerHTML={{ __html: preview }} /> : <span className="text-xs text-slate-400">Sem conteúdo.</span>}
          </div>
        </div>
      </div>
    </Card>
  );
}

export default function HtmlAdmin({ state }) {
  const [form, setForm] = useState(() => JSON.parse(JSON.stringify({ ...DEFAULT_HTML, ...(state.html || {}) })));
  const [saved, setSaved] = useState(false);
  const comments = [...(state.comments || [])].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  const sample = (state.articles || []).find((a) => a.status === "publicado") || { title: "Artigo de exemplo", author: "Autor", categories: [], slug: "exemplo" };
  const views = state.views || {};
  const ranking = [...(state.articles || [])].map((a) => ({ a, n: views[a.id] || 0 })).sort((x, y) => y.n - x.n).slice(0, 8);
  const totalViews = Object.values(views).reduce((s, n) => s + n, 0);
  const artTitle = (id) => (state.articles || []).find((a) => a.id === id);

  const save = () => {
    updateState((s) => { s.html = { ...form, comments: s.html?.comments || form.comments }; });
    addLog("sistema", "Sessão HTML atualizada (blocos de início/fim, comentários e visualizações)");
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };
  const setComment = (id, status) => updateState((s) => {
    const c = s.comments.find((x) => x.id === id);
    if (c) c.status = status;
  });
  const deleteComment = (id) => {
    if (!window.confirm("Excluir este comentário?")) return;
    updateState((s) => { s.comments = s.comments.filter((x) => x.id !== id); });
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-white">&lt;/&gt; HTML</h1>
          <p className="mt-1 text-sm text-slate-400">
            Códigos HTML e textos alternativos no início e no final de cada artigo, comentários e visualizações.
          </p>
        </div>
        <button type="button" className={btnPrimary} onClick={save}>{saved ? "✓ Salvo!" : "Salvar HTML"}</button>
      </div>

      <p className="rounded-xl border border-slate-800 bg-slate-900/60 p-3 text-xs text-slate-400">
        Variáveis disponíveis: {HTML_VARIABLES.map((v) => <code key={v} className="mx-0.5 rounded bg-slate-800 px-1.5 py-0.5 text-amber-300">{v}</code>)}.
        Por segurança, tags &lt;script&gt; inseridas aqui não são executadas no navegador.
      </p>

      <div className="grid gap-5 xl:grid-cols-2">
        <BlockEditor title="⬆️ Início de cada artigo" subtitle="Exibido antes do conteúdo (ex.: aviso, banner, anúncio)."
          block={form.before} onChange={(b) => setForm((f) => ({ ...f, before: b }))} sample={sample} state={state} />
        <BlockEditor title="⬇️ Final de cada artigo" subtitle="Exibido depois do conteúdo (ex.: newsletter, assinatura, CTA)."
          block={form.after} onChange={(b) => setForm((f) => ({ ...f, after: b }))} sample={sample} state={state} />
      </div>

      <Card title="🧱 Layout do artigo" subtitle="Escolha a estrutura da página de cada artigo (sidebars com mais lidos, categorias, últimos artigos e redes).">
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5" role="radiogroup" aria-label="Layout do artigo">
          {ARTICLE_LAYOUTS.map((l) => {
            const active = (form.layout || "none") === l.id;
            return (
              <button key={l.id} type="button" role="radio" aria-checked={active} onClick={() => setForm((f) => ({ ...f, layout: l.id }))}
                className={`rounded-xl border p-3 text-left transition ${active ? "border-amber-500 bg-amber-500/10 ring-2 ring-amber-500/30" : "border-slate-700 bg-slate-800/50 hover:border-slate-500"}`}>
                <LayoutThumb id={l.id} />
                <p className="mt-2 text-sm font-bold text-slate-100">{l.name}</p>
                <p className="mt-0.5 text-xs text-slate-400">{l.desc}</p>
              </button>
            );
          })}
        </div>
      </Card>

      <Card title="🔗 Compartilhamento social" subtitle="Ícones no início e no final de cada artigo.">
        <Toggle label="Exibir botões de compartilhamento" desc={`${SHARE_NETWORKS.map((n) => n.name).join(", ")} e copiar link.`}
          checked={form.share !== false} onChange={(v) => setForm((f) => ({ ...f, share: v }))} />
      </Card>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card title="💬 Comentários dos leitores" subtitle="A moderação e as configurações agora ficam na sessão Comentários.">
          <button type="button" className={btnPrimary} onClick={() => navigate("/admin/comentarios")}>Abrir sessão Comentários →</button>
        </Card>
        <Card title="👁 Visualizações" subtitle={`Total: ${totalViews} visualizações em todos os artigos.`}
          actions={<button type="button" className={btnDanger} onClick={() => { if (window.confirm("Zerar todas as visualizações?")) updateState((s) => { s.views = {}; }); }}>Zerar</button>}>
          <Toggle label="Exibir contador nos artigos" desc="Mostra de forma discreta “👁 N visualizações” no cabeçalho do artigo."
            checked={form.showViews !== false} onChange={(v) => setForm((f) => ({ ...f, showViews: v }))} />
          <ul className="mt-3 divide-y divide-slate-800">
            {ranking.map(({ a, n }) => (
              <li key={a.id} className="flex items-center gap-3 py-2 text-sm">
                <span className="min-w-0 flex-1 truncate text-slate-300">{a.title}</span>
                <Badge tone="video">👁 {n}</Badge>
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </div>
  );
}
