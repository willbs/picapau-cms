// Página de segurança: trocar a senha do usuário logado, GERENCIAR USUÁRIOS
// cadastrados (cadastrar manualmente, ativar/desativar, redefinir senha, excluir),
// toggle para habilitar/desabilitar criação de novas contas (login), sessão,
// proteções (rate limit/bloqueio), modo manutenção e logs de acesso.
import { useState } from "react";
import { Card, inputCls, labelCls, btnPrimary, btnGhost, btnDanger, Badge, Toggle } from "./ui.jsx";
import { updateState, useCmsState } from "../store.js";
import {
  changePassword,
  addLog,
  getSession,
  getCurrentUser,
  destroySession,
  getProtectionStatus,
  createUser,
  updateUser,
  deleteUser,
  setUserPassword,
} from "../auth.js";
import { navigate } from "../router.js";
import { formatDate } from "../utils.js";
import { BackupCard, PrivacyCard, SmtpCard } from "./SecurityExtras.jsx";
import { sendConfirmation } from "../pages/Register.jsx";

export default function SecurityAdmin() {
  const state = useCmsState();
  const me = getCurrentUser();
  const users = state.security.users || [];

  const [cur, setCur] = useState("");
  const [next, setNext] = useState("");
  const [next2, setNext2] = useState("");
  const [msg, setMsg] = useState(null); // {type:'ok'|'err', text}
  const [minutes, setMinutes] = useState(String(state.security.sessionMinutes || 30));
  const protection = getProtectionStatus();

  // novo usuário (cadastro manual)
  const [nuEmail, setNuEmail] = useState("");
  const [nuPass, setNuPass] = useState("");
  const [nuRole, setNuRole] = useState("editor");
  const [nuActive, setNuActive] = useState(true);
  const [nuMsg, setNuMsg] = useState(null);

  const submitPassword = async (e) => {
    e.preventDefault();
    setMsg(null);
    if (next !== next2) return setMsg({ type: "err", text: "As senhas novas não coincidem." });
    const res = await changePassword(cur, next);
    if (res.ok) {
      setMsg({ type: "ok", text: "Sua senha foi alterada com sucesso!" });
      setCur(""); setNext(""); setNext2("");
    } else {
      setMsg({ type: "err", text: res.error });
    }
  };

  const saveMinutes = () => {
    const m = Math.max(5, Math.min(1440, Number(minutes) || 30));
    updateState((s) => {
      s.security.sessionMinutes = m;
    });
    addLog("seguranca", `Tempo de sessão alterado para ${m} min`);
    setMsg({ type: "ok", text: `Sessão configurada para ${m} minutos de inatividade.` });
  };

  const toggle = (key) => (val) => {
    updateState((s) => {
      s.security[key] = val;
    });
    addLog("seguranca", `Proteção "${key}" ${val ? "ativada" : "desativada"}`);
  };

  const submitNewUser = async (e) => {
    e.preventDefault();
    setNuMsg(null);
    const res = await createUser({ email: nuEmail, password: nuPass, role: nuRole, active: nuActive });
    if (res.ok) {
      setNuMsg({ type: "ok", text: `Usuário ${res.user.email} cadastrado (${res.user.role}).` });
      setNuEmail(""); setNuPass(""); setNuRole("editor"); setNuActive(true);
    } else {
      setNuMsg({ type: "err", text: res.error });
    }
  };

  const onResetUserPassword = async (u) => {
    const pw = window.prompt(`Nova senha para ${u.email} (mín. 6 caracteres):`);
    if (!pw) return;
    const res = await setUserPassword(u.id, pw);
    setNuMsg(res.ok ? { type: "ok", text: `Senha de ${u.email} redefinida.` } : { type: "err", text: res.error });
  };

  const onDeleteUser = (u) => {
    if (!window.confirm(`Remover o usuário ${u.email}?`)) return;
    const res = deleteUser(u.id);
    setNuMsg(res.ok ? { type: "ok", text: `Usuário ${u.email} removido.` } : { type: "err", text: res.error });
  };

  const session = getSession();

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-extrabold text-white">Segurança</h1>
        <p className="mt-1 text-sm text-slate-400">
          Logado como: <strong className="text-slate-200">{me?.email}</strong> ({me?.role}) ·
          senhas guardadas apenas como hash SHA-256.
        </p>
      </div>

      {msg && (
        <p role="alert" className={`rounded-xl border px-4 py-3 text-sm ${msg.type === "ok" ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-300" : "border-rose-500/40 bg-rose-500/10 text-rose-300"}`}>
          {msg.text}
        </p>
      )}

      <div className="grid gap-5 lg:grid-cols-2">
        {/* Trocar senha do usuário logado */}
        <Card title="Alterar minha senha" subtitle="A senha é armazenada apenas como hash SHA-256 (salt + senha).">
          <form onSubmit={submitPassword} className="space-y-4">
            <div>
              <label htmlFor="sp-cur" className={labelCls}>Senha atual</label>
              <input id="sp-cur" type="password" autoComplete="current-password" className={inputCls} value={cur} onChange={(e) => setCur(e.target.value)} required />
            </div>
            <div>
              <label htmlFor="sp-new" className={labelCls}>Nova senha</label>
              <input id="sp-new" type="password" autoComplete="new-password" className={inputCls} value={next} onChange={(e) => setNext(e.target.value)} required minLength={6} />
            </div>
            <div>
              <label htmlFor="sp-new2" className={labelCls}>Confirmar nova senha</label>
              <input id="sp-new2" type="password" autoComplete="new-password" className={inputCls} value={next2} onChange={(e) => setNext2(e.target.value)} required />
            </div>
            <button type="submit" className={btnPrimary}>Alterar senha</button>
          </form>
        </Card>

        {/* Sessão */}
        <Card title="Sessão" subtitle="Logout automático por inatividade (expiração deslizante).">
          <div className="space-y-4">
            <div>
              <label htmlFor="sp-min" className={labelCls}>Expirar após (minutos de inatividade)</label>
              <div className="flex gap-2">
                <input id="sp-min" type="number" min={5} max={1440} className={inputCls} value={minutes} onChange={(e) => setMinutes(e.target.value)} />
                <button type="button" className={btnGhost} onClick={saveMinutes}>Aplicar</button>
              </div>
            </div>
            <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4 text-sm text-slate-300">
              <p><strong className="text-slate-100">Sessão atual:</strong> {session ? "ativa" : "nenhuma"}</p>
              {session && (
                <p className="mt-1 text-xs text-slate-500">
                  criada em {formatDate(new Date(session.createdAt).toISOString())} às{" "}
                  {new Date(session.createdAt).toLocaleTimeString("pt-BR")}
                </p>
              )}
              <button
                type="button"
                className={`${btnDanger} mt-3`}
                onClick={() => {
                  addLog("logout", "Sessão encerrada pelo painel de segurança");
                  destroySession();
                  navigate("/");
                }}
              >
                Encerrar sessão agora
              </button>
            </div>
          </div>
        </Card>
      </div>

      {/* Gerenciar usuários cadastrados */}
      <Card
        title={`Usuários cadastrados (${users.length})`}
        subtitle="Cadastre novos usuários manualmente, ative/desative, redefina senhas ou remova."
      >
        {nuMsg && (
          <p role="alert" className={`mb-4 rounded-xl border px-4 py-2.5 text-sm ${nuMsg.type === "ok" ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-300" : "border-rose-500/40 bg-rose-500/10 text-rose-300"}`}>
            {nuMsg.text}
          </p>
        )}
        <ul className="divide-y divide-slate-800">
          {users.map((u) => (
            <li key={u.id} className="flex flex-wrap items-center gap-3 py-3">
              <span className="flex h-9 w-9 items-center justify-center rounded-full bg-indigo-500/20 text-sm font-bold text-indigo-300" aria-hidden="true">
                {u.email[0]?.toUpperCase()}
              </span>
              <div className="min-w-0 flex-1 basis-48">
                <p className="truncate text-sm font-semibold text-slate-100">{u.email}</p>
                <p className="text-xs text-slate-500">cadastrado em {formatDate(u.createdAt)}</p>
              </div>
              <Badge tone={u.role === "admin" ? "agendado" : "video"}>{u.role === "admin" ? "👑 admin" : "✏️ editor"}</Badge>
              <Badge tone={u.active ? "publicado" : "rascunho"}>{u.active ? "ativo" : "inativo"}</Badge>
              {u.emailVerified === false
                ? <Badge tone="agendado">✉️ e-mail não confirmado</Badge>
                : <Badge tone="publicado">✉️ confirmado</Badge>}
              {u.role !== "admin" && <span className="text-[11px] text-slate-500">só o site (sem painel)</span>}
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  className={btnGhost}
                  onClick={() => {
                    updateUser(u.id, { active: !u.active });
                    addLog("seguranca", `Usuário ${u.email} ${!u.active ? "ativado" : "desativado"}`);
                  }}
                >
                  {u.active ? "Desativar" : "Ativar"}
                </button>
                {u.emailVerified === false && (
                  <>
                    <button type="button" className={btnGhost} onClick={() => { updateUser(u.id, { emailVerified: true, verifyToken: null, verifyExpires: null }); addLog("seguranca", `E-mail de ${u.email} confirmado manualmente`); }}>Confirmar e-mail</button>
                    <button type="button" className={btnGhost} onClick={async () => { const r = await sendConfirmation(u); setNuMsg(r.mode === "email" ? { type: "ok", text: `Novo link de confirmação enviado para ${u.email}.` } : r.mode === "demo" ? { type: "ok", text: `SMTP desativado — link de confirmação: ${r.link}` } : { type: "err", text: r.error }); }}>Reenviar confirmação</button>
                  </>
                )}
                <button type="button" className={btnGhost} onClick={() => onResetUserPassword(u)}>Redefinir senha</button>
                <button type="button" className={btnDanger} onClick={() => onDeleteUser(u)}>Excluir</button>
              </div>
            </li>
          ))}
        </ul>

        {/* Cadastro manual de novo usuário */}
        <form onSubmit={submitNewUser} className="mt-5 grid gap-3 rounded-xl border border-slate-800 bg-slate-900/60 p-4 md:grid-cols-4">
          <div>
            <label htmlFor="nu-email" className={labelCls}>E-mail</label>
            <input id="nu-email" type="email" className={inputCls} value={nuEmail} onChange={(e) => setNuEmail(e.target.value)} placeholder="novo@exemplo.com" required />
          </div>
          <div>
            <label htmlFor="nu-pass" className={labelCls}>Senha inicial</label>
            <input id="nu-pass" type="password" className={inputCls} value={nuPass} onChange={(e) => setNuPass(e.target.value)} placeholder="mín. 6 caracteres" required minLength={6} />
          </div>
          <div>
            <label htmlFor="nu-role" className={labelCls}>Perfil</label>
            <select id="nu-role" className={inputCls} value={nuRole} onChange={(e) => setNuRole(e.target.value)}>
              <option value="editor">✏️ editor (só o site)</option>
              <option value="admin">👑 admin</option>
            </select>
          </div>
          <div className="flex items-end gap-3">
            <label className="flex cursor-pointer items-center gap-2 text-sm text-slate-300">
              <input type="checkbox" checked={nuActive} onChange={(e) => setNuActive(e.target.checked)} />
              ativo
            </label>
            <button type="submit" className={btnPrimary}>+ Cadastrar usuário</button>
          </div>
        </form>
      </Card>

      {/* Proteções */}
      <Card title="Proteções contra acessos indevidos" subtitle="Rate limiting no login, bloqueio por tentativas e criação de novas contas.">
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          <Toggle
            label="Rate limit no login"
            desc="Após 3 falhas em 60s, pede para aguardar a janela passar."
            checked={state.security.rateLimit !== false}
            onChange={toggle("rateLimit")}
          />
          <Toggle
            label="Bloqueio por tentativas"
            desc="Após 5 falhas em 60s, bloqueia o login por 5 minutos."
            checked={state.security.lockout !== false}
            onChange={toggle("lockout")}
          />
          <Toggle
            label="Criação de novas contas"
            desc="Habilita o link 'Criar conta' na página de login (/login/registrar). Novas contas entram como Editor (acesso só ao site, sem painel) e precisam confirmar o e-mail pelo link enviado. Desligado = apenas usuários cadastrados no painel entram."
            checked={state.security.allowRegistration === true}
            onChange={(v) => {
              toggle("allowRegistration")(v);
              addLog("seguranca", `Criação de novas contas ${v ? "HABILITADA" : "DESABILITADA"}`);
            }}
          />
          <Toggle
            label="Modo manutenção"
            desc="O site público mostra uma página de manutenção (painel segue acessível)."
            checked={!!state.security.maintenance}
            onChange={(v) => {
              toggle("maintenance")(v);
              addLog("sistema", `Modo manutenção ${v ? "ATIVADO" : "DESATIVADO"}`);
            }}
          />
        </div>
        <p className="mt-4 text-xs text-slate-500">
          Status atual: {protection.locked
            ? `🔒 bloqueado por ${Math.ceil(protection.lockRemaining / 60)} min`
            : protection.limited
              ? `⏳ limitado — aguarde ${protection.limitRemaining}s`
              : `✅ ativo — ${protection.fails} falha(s) na janela atual`}
        </p>
      </Card>

      {/* Backup e Políticas de privacidade */}
      <SmtpCard state={state} />
      <BackupCard state={state} />
      <PrivacyCard state={state} />

      {/* Logs */}
      <Card
        title="Logs de acesso ao login"
        subtitle="Últimas tentativas (sucesso e falha) registradas no navegador."
        actions={
          <button
            type="button"
            className={btnDanger}
            onClick={() => {
              if (window.confirm("Limpar todos os logs?")) {
                updateState((s) => { s.security.logs = []; });
              }
            }}
          >
            Limpar logs
          </button>
        }
      >
        {state.security.logs.length === 0 ? (
          <p className="text-sm text-slate-400">Nenhum log registrado ainda.</p>
        ) : (
          <ul className="admin-scroll max-h-80 divide-y divide-slate-800 overflow-y-auto">
            {state.security.logs.map((l) => (
              <li key={l.id} className="flex items-center gap-3 py-2.5 text-sm">
                <Badge tone={l.type}>{l.type}</Badge>
                <span className="min-w-0 flex-1 truncate text-slate-300">{l.message}</span>
                <span className="shrink-0 text-xs text-slate-500">
                  {new Date(l.time).toLocaleString("pt-BR")}
                </span>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}
