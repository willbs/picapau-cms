// Pequenos componentes de UI do painel administrativo (tema escuro).
import { cn } from "../utils.js";

export const inputCls =
  "w-full rounded-lg border border-slate-700 bg-slate-800/80 px-3 py-2 text-sm text-slate-100 placeholder-slate-500 focus:border-amber-500 focus:outline-none focus:ring-1 focus:ring-amber-500/40";

export const labelCls =
  "mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-400";

export const btnPrimary =
  "rounded-lg bg-amber-500 px-4 py-2 text-sm font-semibold text-slate-950 shadow transition hover:bg-amber-400 disabled:opacity-50";

export const btnGhost =
  "rounded-lg border border-slate-700 px-3 py-2 text-sm font-medium text-slate-300 transition hover:bg-slate-800 hover:text-white";

export const btnDanger =
  "rounded-lg border border-rose-500/40 px-3 py-2 text-sm font-medium text-rose-300 transition hover:bg-rose-500/10";

export function Card({ title, subtitle, actions, children, className }) {
  return (
    <section
      className={cn(
        "rounded-2xl border border-slate-800 bg-slate-900/70 p-5 shadow-sm",
        className
      )}
    >
      {(title || actions) && (
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div>
            {title && <h2 className="text-lg font-bold text-white">{title}</h2>}
            {subtitle && <p className="mt-0.5 text-sm text-slate-400">{subtitle}</p>}
          </div>
          {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
        </div>
      )}
      {children}
    </section>
  );
}

const BADGE_COLORS = {
  image: "bg-sky-500/15 text-sky-300",
  video: "bg-indigo-500/15 text-indigo-300",
  audio: "bg-emerald-500/15 text-emerald-300",
  publicado: "bg-emerald-500/15 text-emerald-300",
  rascunho: "bg-slate-500/15 text-slate-300",
  agendado: "bg-amber-500/15 text-amber-300",
  login: "bg-emerald-500/15 text-emerald-300",
  falha: "bg-rose-500/15 text-rose-300",
  logout: "bg-slate-500/15 text-slate-300",
  seguranca: "bg-indigo-500/15 text-indigo-300",
  sistema: "bg-sky-500/15 text-sky-300",
};

export function Badge({ children, tone }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-semibold",
        BADGE_COLORS[tone] || "bg-slate-500/15 text-slate-300"
      )}
    >
      {children}
    </span>
  );
}

export function Toggle({ checked, onChange, label, desc }) {
  return (
    <label className="flex cursor-pointer items-start gap-3 rounded-xl border border-slate-800 bg-slate-900/60 p-4 hover:border-slate-700">
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        aria-label={label}
        onClick={() => onChange(!checked)}
        className={cn(
          "relative mt-0.5 h-6 w-11 shrink-0 rounded-full transition-colors",
          checked ? "bg-amber-500" : "bg-slate-700"
        )}
      >
        <span
          className={cn(
            "absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all",
            checked ? "left-[22px]" : "left-0.5"
          )}
        />
      </button>
      <span>
        <span className="block text-sm font-semibold text-slate-100">{label}</span>
        {desc && <span className="mt-0.5 block text-xs text-slate-400">{desc}</span>}
      </span>
    </label>
  );
}
