// Painel → Tradução: habilitar/desabilitar cada idioma (inglês, português do Brasil, espanhol,
// italiano e francês), idioma padrão, tradução automática e traduções manuais do conteúdo.
import { useMemo, useState } from "react";
import { Card, inputCls, btnPrimary, btnGhost, btnDanger, Badge, Toggle } from "./ui.jsx";
import { updateState } from "../store.js";
import { addLog } from "../auth.js";
import { LANGUAGES, SOURCE_LANG, clearAutoCache, autoCacheSize, autoTranslate } from "../i18n.js";
import { DICT } from "../data/i18nDict.js";

const IDX = { en: 0, es: 1, it: 2, fr: 3 };
const strip = (s) => String(s || "").replace(/^[\s\p{Extended_Pictographic}\uFE0F\u200D]+/u, "").trim();

/** Coleta os textos de conteúdo traduzíveis do site. */
function collectStrings(state) {
  const out = [];
  const add = (group, s) => {
    const t = strip(s);
    if (t && /\p{L}/u.test(t) && !out.some((o) => o.text === t)) out.push({ group, text: t });
  };
  add("Site", state.branding?.siteName);
  add("Site", state.seo?.title);
  add("Site", state.seo?.description);
  (state.categories || []).forEach((c) => { add("Categorias", c.name); add("Categorias", c.description); });
  (state.articles || []).forEach((a) => { add("Artigos", a.title); add("Artigos", a.excerpt); });
  (state.menus || []).forEach((m) => {
    add("Menus", m.name);
    const walk = (items) => (items || []).forEach((i) => {
      add("Menus", i.label); add("Menus", i.desc); walk(i.children);
      (i.columns || []).forEach((c) => { add("Menus", c.title); (c.links || []).forEach((l) => { add("Menus", l.label); add("Menus", l.desc); }); });
    });
    walk(m.items);
  });
  (state.podcast?.categories || []).forEach((c) => add("Podcasts", c.name));
  (state.loja?.products || []).forEach((p) => { add("Loja", p.name); add("Loja", p.description); add("Loja", p.category); });
  (state.forum?.categories || []).forEach((c) => { add("Fórum", c.name); add("Fórum", c.description); });
  (state.footer?.bottomMenu || []).forEach((b) => add("Rodapé", b.label));
  return out;
}

export default function TranslationAdmin({ state }) {
  const cfg = state.i18n || { enabled: true, default: SOURCE_LANG, languages: {}, auto: true, phrases: {} };
  const [tab, setTab] = useState("en");
  const [q, setQ] = useState("");
  const [group, setGroup] = useState("");
  const [draft, setDraft] = useState(() => JSON.parse(JSON.stringify(cfg.phrases || {})));
  const [busy, setBusy] = useState("");
  const [msg, setMsg] = useState("");
  const [cacheN, setCacheN] = useState(autoCacheSize());

  const strings = useMemo(() => collectStrings(state), [state]);
  const groups = [...new Set(strings.map((s) => s.group))];
  const shown = strings.filter((s) => (!group || s.group === group) && (!q || s.text.toLowerCase().includes(q.toLowerCase())));
  const builtin = (text) => DICT[text]?.[IDX[tab]] || "";
  const manual = (text) => draft[tab]?.[text] || "";
  const missing = shown.filter((s) => !manual(s.text) && !builtin(s.text));

  const patch = (fn, log) => {
    updateState((s) => {
      s.i18n = s.i18n || { enabled: true, default: SOURCE_LANG, languages: {}, auto: true, phrases: {} };
      fn(s.i18n);
    });
    if (log) addLog("sistema", log);
  };

  const toggleLang = (code, on) => {
    if (!on && code === cfg.default) return setMsg("Não é possível desabilitar o idioma padrão. Escolha outro padrão antes.");
    const active = LANGUAGES.filter((l) => cfg.languages?.[l.code]).length;
    if (!on && active <= 1) return setMsg("Mantenha pelo menos um idioma habilitado.");
    setMsg("");
    patch((i) => { i.languages = { ...i.languages, [code]: on }; }, `Idioma ${code} ${on ? "HABILITADO" : "DESABILITADO"}`);
  };
  const setDefault = (code) => {
    if (!cfg.languages?.[code]) return setMsg("Habilite o idioma antes de torná-lo padrão.");
    setMsg("");
    patch((i) => { i.default = code; }, `Idioma padrão alterado para ${code}`);
  };
  const setVal = (text, v) => setDraft((d) => ({ ...d, [tab]: { ...(d[tab] || {}), [text]: v } }));
  const saveManual = () => {
    const clean = {};
    Object.entries(draft).forEach(([l, m]) => { clean[l] = Object.fromEntries(Object.entries(m || {}).filter(([, v]) => String(v).trim())); });
    patch((i) => { i.phrases = clean; }, "Traduções manuais de conteúdo atualizadas");
    setMsg("✓ Traduções salvas.");
  };
  const autoFill = async () => {
    setBusy("Traduzindo…");
    let ok = 0, fail = 0;
    for (const s of missing.slice(0, 30)) {
      try { const tr = await autoTranslate(s.text, tab); setVal(s.text, tr); ok++; } catch { fail++; }
    }
    setBusy("");
    setMsg(`Tradução automática: ${ok} preenchido(s)${fail ? `, ${fail} falha(s) (limite da API ou sem internet)` : ""}. Revise e clique em Salvar.`);
  };

  const langName = (c) => LANGUAGES.find((l) => l.code === c)?.name;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-extrabold text-white">🌍 Tradução</h1>
        <p className="mt-1 text-sm text-slate-400">
          O blog inteiro é traduzido para o idioma escolhido pelo visitante no seletor do menu superior. O painel continua em português.
        </p>
      </div>

      {msg && <p role="status" className="rounded-xl border border-amber-500/40 bg-amber-500/10 px-4 py-3 text-sm text-amber-200">{msg}</p>}

      <Card title="Tradução do site">
        <Toggle label={cfg.enabled !== false ? "Tradução HABILITADA" : "Tradução DESABILITADA (site só em português)"}
          desc="Liga/desliga o seletor de idiomas e a tradução do blog como um todo."
          checked={cfg.enabled !== false} onChange={(v) => patch((i) => { i.enabled = v; }, `Tradução do site ${v ? "habilitada" : "desabilitada"}`)} />
      </Card>

      <Card title="Idiomas" subtitle="Habilite ou desabilite cada idioma e escolha o padrão (exibido para quem ainda não escolheu).">
        <ul className="divide-y divide-slate-800" aria-label="Idiomas">
          {LANGUAGES.map((l) => {
            const on = !!cfg.languages?.[l.code];
            const isDefault = cfg.default === l.code;
            return (
              <li key={l.code} className="flex flex-wrap items-center gap-3 py-3" data-lang-row={l.code}>
                <span className="text-2xl" aria-hidden="true">{l.flag}</span>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-bold text-slate-100">{l.name}</p>
                  <p className="text-xs text-slate-500">{l.code}{l.code === SOURCE_LANG ? " · idioma original do conteúdo" : ""}</p>
                </div>
                {isDefault && <Badge tone="agendado">⭐ padrão</Badge>}
                <label className="flex cursor-pointer items-center gap-1.5 text-xs text-slate-300">
                  <input type="radio" name="lang-default" checked={isDefault} onChange={() => setDefault(l.code)} aria-label={`Tornar ${l.name} o idioma padrão`} />
                  padrão
                </label>
                <button type="button" role="switch" aria-checked={on} aria-label={`Habilitar ${l.name}`} onClick={() => toggleLang(l.code, !on)}
                  className={`relative h-6 w-11 shrink-0 rounded-full transition-colors ${on ? "bg-amber-500" : "bg-slate-700"}`}>
                  <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${on ? "left-[22px]" : "left-0.5"}`} />
                </button>
                <span className={`w-24 text-xs font-semibold ${on ? "text-emerald-400" : "text-slate-500"}`}>{on ? "habilitado" : "desabilitado"}</span>
              </li>
            );
          })}
        </ul>
      </Card>

      <Card title="🤖 Tradução automática de conteúdo"
        subtitle="Conteúdo sem tradução revisada (ex.: corpo dos artigos, posts do fórum) é traduzido no navegador do visitante pela API gratuita MyMemory e guardado em cache.">
        <Toggle label="Traduzir automaticamente o conteúdo sem tradução" desc="Requer internet; a API gratuita tem limite diário de caracteres por visitante."
          checked={cfg.auto !== false} onChange={(v) => patch((i) => { i.auto = v; }, `Tradução automática ${v ? "ligada" : "desligada"}`)} />
        <div className="mt-3 flex items-center gap-3 text-xs text-slate-400">
          <span>{cacheN} tradução(ões) automáticas em cache neste navegador</span>
          <button type="button" className={btnDanger} onClick={() => { clearAutoCache(); setCacheN(0); }}>Limpar cache</button>
        </div>
      </Card>

      <Card title="✍️ Traduções do conteúdo" subtitle="Textos do site (categorias, artigos, menus, loja, fórum…). Campos vazios usam a tradução revisada embutida (mostrada em cinza) ou a automática."
        actions={<button type="button" className={btnPrimary} onClick={saveManual}>Salvar traduções</button>}>
        <div className="mb-4 flex flex-wrap items-center gap-2">
          <div className="flex gap-1" role="tablist" aria-label="Idioma das traduções">
            {LANGUAGES.filter((l) => l.code !== SOURCE_LANG).map((l) => (
              <button key={l.code} type="button" role="tab" aria-selected={tab === l.code} onClick={() => setTab(l.code)}
                className={`rounded-lg px-3 py-1.5 text-xs font-semibold ${tab === l.code ? "bg-amber-500 text-slate-950" : "border border-slate-700 text-slate-300"}`}>
                {l.flag} {l.name}
              </button>
            ))}
          </div>
          <select className={`${inputCls} w-auto`} value={group} onChange={(e) => setGroup(e.target.value)} aria-label="Filtrar grupo">
            <option value="">Todos os grupos</option>
            {groups.map((g) => <option key={g} value={g}>{g}</option>)}
          </select>
          <input className={`${inputCls} max-w-xs`} placeholder="🔍 Buscar texto…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Buscar texto" />
          <button type="button" className={btnGhost} disabled={!!busy || !missing.length} onClick={autoFill}>
            {busy || `🤖 Traduzir automaticamente os ${Math.min(missing.length, 30)} sem tradução`}
          </button>
        </div>
        <ul className="max-h-[60vh] divide-y divide-slate-800 overflow-y-auto admin-scroll" aria-label="Textos traduzíveis">
          {shown.map((s) => (
            <li key={s.text} className="grid gap-2 py-2.5 md:grid-cols-2" data-tr-row>
              <div>
                <p className="text-sm text-slate-200">{s.text}</p>
                <p className="text-[11px] text-slate-500">{s.group}</p>
              </div>
              <input className={inputCls} value={manual(s.text)} onChange={(e) => setVal(s.text, e.target.value)}
                placeholder={builtin(s.text) || `sem tradução em ${langName(tab)} (usa a automática)`} aria-label={`Tradução de: ${s.text}`} />
            </li>
          ))}
        </ul>
      </Card>
    </div>
  );
}
