// Editor de artigos: seletor de tipo (imagem/vídeo/áudio), modelos de layout com
// preview em tempo real, campos comuns, mídia específica, SEO e categorias obrigatórias.
import { useMemo, useState } from "react";
import { Card, inputCls, labelCls, btnPrimary, btnGhost } from "./ui.jsx";
import RichEditor from "../components/RichEditor.jsx";
import SeoFields from "../components/SeoFields.jsx";
import MediaFields from "../components/MediaFields.jsx";
import UploadField from "../components/UploadField.jsx";
import TemplatePicker from "../components/TemplatePicker.jsx";
import ArticleView, { TEMPLATES } from "../templates/ArticleView.jsx";
import { navigate } from "../router.js";
import { articlePath } from "../permalink.js";
import { updateState } from "../store.js";
import { uid, slugify, nowLocalInput, excerptFromHtml, TYPE_ICONS } from "../utils.js";

/** Artigo em branco. */
function blankArticle() {
  return {
    id: uid(),
    type: "image",
    template: "hero",
    title: "",
    slug: "",
    excerpt: "",
    content: "",
    cover: "",
    author: "Equipe Pica-Pau",
    date: nowLocalInput(),
    scheduledAt: "",
    status: "rascunho",
    categories: [],
    seo: { title: "", description: "", keywords: "", ogImage: "", canonical: "" },
    media: {
      image: { url: "", alt: "", caption: "", gallery: [] },
      video: { url: "", poster: "", duration: "", transcript: "" },
      audio: { url: "", cover: "", duration: "", transcript: "", timestamps: [] },
    },
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
}

const TYPE_CARDS = [
  { id: "image", icon: "🖼️", label: "Artigo com Imagem", desc: "Destaque, galeria, lateral, tela cheia…" },
  { id: "video", icon: "🎬", label: "Artigo com Vídeo", desc: "YouTube/Vimeo/arquivo, playlist, transcrição…" },
  { id: "audio", icon: "🎧", label: "Artigo com Áudio", desc: "Podcast, player fixo, timestamps…" },
];

export default function ArticleEditor({ state, id }) {
  const existing = id ? (state.articles || []).find((a) => a.id === id) : null;
  const [art, setArt] = useState(() =>
    existing ? JSON.parse(JSON.stringify(existing)) : blankArticle()
  );
  const [slugTouched, setSlugTouched] = useState(!!existing);
  const [showPreview, setShowPreview] = useState(true);
  const [error, setError] = useState("");
  const [saved, setSaved] = useState(false);

  const set = (patch) => setArt((a) => ({ ...a, ...patch }));
  const setSeo = (seo) => setArt((a) => ({ ...a, seo }));
  const setMedia = (type, patch) =>
    setArt((a) => ({ ...a, media: { ...a.media, [type]: { ...a.media[type], ...patch } } }));

  const changeType = (type) => {
    setArt((a) => ({ ...a, type, template: TEMPLATES[type][0].id }));
    setError("");
  };

  const onTitle = (title) => {
    setArt((a) => ({
      ...a,
      title,
      slug: slugTouched ? a.slug : slugify(title),
    }));
  };

  const toggleCategory = (slug) => {
    setArt((a) => ({
      ...a,
      categories: a.categories.includes(slug)
        ? a.categories.filter((c) => c !== slug)
        : [...a.categories, slug],
    }));
  };

  const related = useMemo(
    () =>
      (state.articles || [])
        .filter((a) => a.id !== art.id && a.type === art.type && a.status === "publicado")
        .slice(0, 4),
    [state.articles, art.id, art.type]
  );
  const previewCats = (state.categories || []).filter((c) => art.categories.includes(c.slug));
  const previewArticle = {
    ...art,
    cover:
      art.cover ||
      (art.type === "image"
        ? art.media.image.url
        : art.type === "video"
          ? art.media.video.poster
          : art.media.audio.cover),
    date: art.date ? new Date(art.date).toISOString() : new Date().toISOString(),
  };

  const save = () => {
    setError("");
    const title = art.title.trim();
    if (!title) return setError("O título é obrigatório.");
    const slug = (art.slug || slugify(title)).trim() || slugify(title);
    const dup = (state.articles || []).find(
      (a) => a.slug === slug && a.id !== art.id
    );
    if (dup) return setError(`Já existe um artigo com o slug "${slug}". Altere o slug.`);
    if (!art.categories.length)
      return setError("Selecione pelo menos uma categoria (obrigatório).");
    if (art.status === "agendado" && !art.scheduledAt)
      return setError("Informe a data/hora de agendamento.");
    if (!art.content || !art.content.replace(/<[^>]*>/g, "").trim())
      return setError("O conteúdo do artigo não pode ficar vazio.");

    const toSave = {
      ...art,
      title,
      slug,
      excerpt: art.excerpt.trim() || excerptFromHtml(art.content, 160),
      date: art.date ? new Date(art.date).toISOString() : new Date().toISOString(),
      scheduledAt: art.status === "agendado" && art.scheduledAt ? new Date(art.scheduledAt).toISOString() : "",
      updatedAt: new Date().toISOString(),
    };
    updateState((s) => {
      const i = s.articles.findIndex((a) => a.id === art.id);
      if (i >= 0) s.articles[i] = toSave;
      else s.articles.unshift(toSave);
    });
    setSaved(true);
    setTimeout(() => navigate("/admin/artigos"), 600);
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-white">
            {existing ? "Editar artigo" : "Novo artigo"}
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Escolha o tipo, o modelo de layout e veja o preview em tempo real →
          </p>
        </div>
        <div className="flex gap-2">
          <button type="button" className={btnGhost} onClick={() => setShowPreview((v) => !v)}>
            {showPreview ? "Ocultar preview" : "Mostrar preview"}
          </button>
          <button type="button" className={btnGhost} onClick={() => navigate("/admin/artigos")}>
            Cancelar
          </button>
          <button type="button" className={btnPrimary} onClick={save}>
            {saved ? "✓ Salvo!" : "Salvar artigo"}
          </button>
        </div>
      </div>

      {error && (
        <p role="alert" className="rounded-xl border border-rose-500/40 bg-rose-500/10 px-4 py-3 text-sm text-rose-300">
          {error}
        </p>
      )}

      <div className={`grid gap-6 ${showPreview ? "xl:grid-cols-[1fr_420px]" : ""}`}>
        {/* ------------------------------ FORMULÁRIO ------------------------------ */}
        <div className="min-w-0 space-y-5">
          {/* 1. Tipo de artigo */}
          <Card title="1 · Tipo de artigo" subtitle="Alterne entre imagem, vídeo e áudio — os modelos abaixo mudam conforme o tipo.">
            <div className="grid gap-3 sm:grid-cols-3" role="radiogroup" aria-label="Tipo de artigo">
              {TYPE_CARDS.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  role="radio"
                  aria-checked={art.type === t.id}
                  onClick={() => changeType(t.id)}
                  className={`rounded-xl border p-4 text-left transition ${
                    art.type === t.id
                      ? "border-amber-500 bg-amber-500/10 ring-2 ring-amber-500/30"
                      : "border-slate-700 bg-slate-800/50 hover:border-slate-500"
                  }`}
                >
                  <span className="text-2xl" aria-hidden="true">{t.icon}</span>
                  <span className="mt-2 block text-sm font-bold text-slate-100">{t.label}</span>
                  <span className="mt-0.5 block text-xs text-slate-400">{t.desc}</span>
                </button>
              ))}
            </div>
          </Card>

          {/* 2. Modelo de layout */}
          <Card title={`2 · Modelo de layout — ${art.type === "image" ? "🖼️ Imagem" : art.type === "video" ? "🎬 Vídeo" : "🎧 Áudio"}`}
            subtitle="Escolha um dos modelos; o preview à direita atualiza na hora.">
            <TemplatePicker
              type={art.type}
              value={art.template}
              onChange={(template) => set({ template })}
            />
          </Card>

          {/* 3. Campos comuns */}
          <Card title="3 · Conteúdo" subtitle="Campos comuns a todos os tipos.">
            <div className="space-y-4">
              <div>
                <label htmlFor="f-title" className={labelCls}>Título *</label>
                <input id="f-title" className={inputCls} value={art.title} onChange={(e) => onTitle(e.target.value)}
                  placeholder="Título do artigo" />
              </div>
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <label htmlFor="f-slug" className={labelCls}>Slug (URL)</label>
                  <div className="flex items-center gap-2">
                    <span className="whitespace-nowrap text-sm text-slate-500">{articlePath({ ...art, slug: "§" }, state).replace("§", "")}</span>
                    <input id="f-slug" className={inputCls} value={art.slug}
                      onChange={(e) => { setSlugTouched(true); set({ slug: slugify(e.target.value) }); }}
                      placeholder="gerado-automaticamente" />
                  </div>
                </div>
                <div>
                  <label htmlFor="f-author" className={labelCls}>Autor</label>
                  <input id="f-author" className={inputCls} value={art.author} onChange={(e) => set({ author: e.target.value })} />
                </div>
              </div>
              <div>
                <label htmlFor="f-excerpt" className={labelCls}>Resumo (opcional)</label>
                <textarea id="f-excerpt" className={inputCls} rows={2} value={art.excerpt}
                  onChange={(e) => set({ excerpt: e.target.value })}
                  placeholder="Se vazio, um resumo é gerado do conteúdo" />
              </div>
              <div>
                <label htmlFor="f-content" className={labelCls}>Conteúdo *</label>
                <RichEditor value={art.content} onChange={(content) => set({ content })} />
              </div>
              <div>
                <label htmlFor="f-cover" className={labelCls}>Imagem de destaque (capa / card) — URL ou upload</label>
                <div className="flex flex-wrap items-center gap-2">
                  <input id="f-cover" className={`${inputCls} min-w-0 flex-1`} value={art.cover} onChange={(e) => set({ cover: e.target.value })}
                    placeholder="https://…/capa.jpg — se vazio, usa a mídia do tipo" />
                  <UploadField kind="image" label="Upload capa" onUploaded={(d) => set({ cover: d })} />
                  {art.cover && (
                    <button type="button" onClick={() => set({ cover: "" })} title="Remover capa"
                      className="rounded-lg border border-rose-500/40 px-2 py-2 text-xs text-rose-300 hover:bg-rose-500/10">🗑</button>
                  )}
                </div>
                {art.cover && (
                  <img src={art.cover} alt="Prévia da capa" className="mt-2 h-24 rounded-lg border border-slate-700 object-cover" />
                )}
              </div>
              <div className="grid gap-4 md:grid-cols-3">
                <div>
                  <label htmlFor="f-date" className={labelCls}>Data de publicação</label>
                  <input id="f-date" type="datetime-local" className={inputCls} value={art.date}
                    onChange={(e) => set({ date: e.target.value })} />
                </div>
                <div>
                  <label htmlFor="f-status" className={labelCls}>Status</label>
                  <select id="f-status" className={inputCls} value={art.status} onChange={(e) => set({ status: e.target.value })}>
                    <option value="rascunho">Rascunho</option>
                    <option value="publicado">Publicado</option>
                    <option value="agendado">Agendado</option>
                  </select>
                </div>
                {art.status === "agendado" && (
                  <div>
                    <label htmlFor="f-sched" className={labelCls}>Publicar em</label>
                    <input id="f-sched" type="datetime-local" className={inputCls} value={art.scheduledAt}
                      onChange={(e) => set({ scheduledAt: e.target.value })} />
                  </div>
                )}
              </div>
            </div>
          </Card>

          {/* 4. Categorias (obrigatório, múltiplas) */}
          <Card title="4 · Categorias *" subtitle="Obrigatório marcar ao menos uma — é possível marcar várias.">
            <div className="flex flex-wrap gap-2" role="group" aria-label="Categorias do artigo">
              {(state.categories || []).map((c) => {
                const active = art.categories.includes(c.slug);
                return (
                  <button
                    key={c.id}
                    type="button"
                    aria-pressed={active}
                    onClick={() => toggleCategory(c.slug)}
                    className={`rounded-full border px-3 py-1.5 text-sm font-medium transition ${
                      active
                        ? "border-amber-500 bg-amber-500/15 text-amber-300"
                        : "border-slate-700 bg-slate-800/60 text-slate-400 hover:border-slate-500 hover:text-slate-200"
                    }`}
                  >
                    {c.icon} {c.name}
                  </button>
                );
              })}
              {!(state.categories || []).length && (
                <p className="text-sm text-slate-500">
                  Nenhuma categoria criada.{" "}
                  <button type="button" className="text-amber-400 underline" onClick={() => navigate("/admin/categorias")}>
                    Criar categorias
                  </button>
                </p>
              )}
            </div>
          </Card>

          {/* 5. Mídia específica do tipo */}
          <Card title={`5 · Mídia — ${art.type === "image" ? "🖼️ Imagem" : art.type === "video" ? "🎬 Vídeo" : "🎧 Áudio"}`}
            subtitle="Campos específicos do tipo selecionado.">
            <MediaFields type={art.type} media={art.media} onChange={setMedia} />
          </Card>

          {/* 6. SEO do artigo */}
          <Card title="6 · SEO deste artigo" subtitle="Título, description, palavras-chave, OG e canônica + prévia no Google.">
            <SeoFields seo={art.seo} onChange={setSeo} slug={art.slug || slugify(art.title)} path={articlePath({ ...art, slug: art.slug || slugify(art.title) || "seu-slug" }, state)} />
          </Card>
        </div>

        {/* ------------------------------ PREVIEW ------------------------------ */}
        {showPreview && (
          <div className="xl:sticky xl:top-24 xl:self-start">
            <Card
              title="Preview em tempo real"
              subtitle={`Modelo: ${art.type}/${art.template}`}
              className="border-amber-500/30"
            >
              <div className="max-h-[75vh] overflow-y-auto admin-scroll rounded-xl border border-slate-800 bg-slate-50 p-4 dark:bg-slate-950/60">
                <ArticleView article={previewArticle} related={related} categories={previewCats} embedded />
              </div>
              <p className="mt-3 text-xs text-slate-500">
                {TYPE_ICONS[art.type]} Tipo: <strong>{art.type}</strong> · Modelo: <strong>{art.template}</strong>
              </p>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
