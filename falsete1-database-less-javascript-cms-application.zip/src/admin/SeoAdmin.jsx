// Área de controle de SEO global: título, description, keywords, Open Graph,
// Twitter Cards, canônica, favicon, robots.txt e sitemap (gerado dinamicamente).
import { useState } from "react";
import { Card, inputCls, labelCls, btnPrimary, Toggle } from "./ui.jsx";
import { updateState } from "../store.js";
import { buildSitemap, applySeo } from "../seo.js";
import { addLog } from "../auth.js";
import { download, slugify } from "../utils.js";
import { PERMALINK_OPTIONS, RESERVED_BASES, articlePath } from "../permalink.js";

export default function SeoAdmin({ state }) {
  const [seo, setSeo] = useState(() => JSON.parse(JSON.stringify(state.seo)));
  const [saved, setSaved] = useState(false);
  const set = (k, v) => setSeo((s) => ({ ...s, [k]: v }));

  const [plError, setPlError] = useState("");
  const pl = seo.permalink || { structure: "titulo", base: "" };
  const setPl = (patch) => setSeo((s) => ({ ...s, permalink: { ...pl, ...patch } }));
  const previewState = { ...state, seo };
  const sampleArticles = (state.articles || []).filter((a) => a.status === "publicado").slice(0, 4);

  const save = () => {
    const firstSeg = (pl.base || "").split("/").map(slugify).filter(Boolean)[0];
    if (firstSeg && RESERVED_BASES.includes(firstSeg)) {
      setPlError(`O prefixo "/${firstSeg}" é reservado pelo sistema. Escolha outro (ex.: blog, noticias).`);
      return;
    }
    setPlError("");
    updateState((s) => {
      s.seo = seo;
    });
    applySeo(seo, { path: "/" }, false);
    addLog("sistema", "Configurações de SEO global atualizadas");
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const sitemap = buildSitemap({ ...state, seo });

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-white">SEO global</h1>
          <p className="mt-1 text-sm text-slate-400">
            Aplicado imediatamente ao &lt;head&gt; do site ao salvar. Também há SEO por artigo e por categoria.
          </p>
        </div>
        <button type="button" className={btnPrimary} onClick={save}>
          {saved ? "✓ Salvo!" : "Salvar SEO"}
        </button>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card title="Identidade e metadados" subtitle="Título padrão, description e palavras-chave do site.">
          <div className="space-y-4">
            <div>
              <label htmlFor="s-title" className={labelCls}>Título padrão</label>
              <input id="s-title" className={inputCls} value={seo.title || ""} onChange={(e) => set("title", e.target.value)} />
            </div>
            <div>
              <label htmlFor="s-desc" className={labelCls}>Meta description</label>
              <textarea id="s-desc" className={inputCls} rows={2} maxLength={170} value={seo.description || ""} onChange={(e) => set("description", e.target.value)} />
            </div>
            <div>
              <label htmlFor="s-kw" className={labelCls}>Palavras-chave</label>
              <input id="s-kw" className={inputCls} value={seo.keywords || ""} onChange={(e) => set("keywords", e.target.value)} placeholder="a, b, c" />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="s-url" className={labelCls}>URL canônica base (siteUrl)</label>
                <input id="s-url" className={inputCls} value={seo.siteUrl || ""} onChange={(e) => set("siteUrl", e.target.value)} placeholder="https://meusite.com" />
              </div>
              <div>
                <label htmlFor="s-fav" className={labelCls}>Favicon (URL)</label>
                <input id="s-fav" className={inputCls} value={seo.favicon || ""} onChange={(e) => set("favicon", e.target.value)} placeholder="/favicon.svg" />
              </div>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="s-lang" className={labelCls}>Idioma (lang)</label>
                <input id="s-lang" className={inputCls} value={seo.language || "pt-BR"} onChange={(e) => set("language", e.target.value)} />
              </div>
              <div>
                <label htmlFor="s-author" className={labelCls}>Autor</label>
                <input id="s-author" className={inputCls} value={seo.author || ""} onChange={(e) => set("author", e.target.value)} />
              </div>
            </div>
            <div>
              <label htmlFor="s-robots" className={labelCls}>Meta robots padrão</label>
              <select id="s-robots" className={inputCls} value={seo.robots || "index, follow"} onChange={(e) => set("robots", e.target.value)}>
                <option value="index, follow">index, follow</option>
                <option value="noindex, follow">noindex, follow</option>
                <option value="index, nofollow">index, nofollow</option>
                <option value="noindex, nofollow">noindex, nofollow</option>
              </select>
            </div>
          </div>
        </Card>

        <Card title="Open Graph & Twitter Cards" subtitle="Como o link aparece ao ser compartilhado.">
          <div className="space-y-4">
            <div>
              <label htmlFor="s-ogname" className={labelCls}>og:site_name</label>
              <input id="s-ogname" className={inputCls} value={seo.ogSiteName || ""} onChange={(e) => set("ogSiteName", e.target.value)} />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="s-ogtype" className={labelCls}>og:type padrão</label>
                <select id="s-ogtype" className={inputCls} value={seo.ogType || "website"} onChange={(e) => set("ogType", e.target.value)}>
                  <option value="website">website</option>
                  <option value="article">article</option>
                </select>
              </div>
              <div>
                <label htmlFor="s-ogimg" className={labelCls}>Imagem OG padrão</label>
                <input id="s-ogimg" className={inputCls} value={seo.ogImage || ""} onChange={(e) => set("ogImage", e.target.value)} placeholder="https://…/og-1200x630.jpg" />
              </div>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="s-twcard" className={labelCls}>Twitter Card</label>
                <select id="s-twcard" className={inputCls} value={seo.twitterCard || "summary_large_image"} onChange={(e) => set("twitterCard", e.target.value)}>
                  <option value="summary_large_image">summary_large_image</option>
                  <option value="summary">summary</option>
                </select>
              </div>
              <div>
                <label htmlFor="s-twsite" className={labelCls}>Twitter @site</label>
                <input id="s-twsite" className={inputCls} value={seo.twitterSite || ""} onChange={(e) => set("twitterSite", e.target.value)} placeholder="@seuperfil" />
              </div>
            </div>
            {seo.ogImage && (
              <div>
                <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">Prévia do card</p>
                <div className="overflow-hidden rounded-xl border border-slate-700">
                  <img src={seo.ogImage} alt="Prévia OG" className="h-40 w-full object-cover" loading="lazy" />
                  <div className="bg-slate-900 p-3">
                    <p className="truncate text-sm font-bold text-white">{seo.ogSiteName || seo.title}</p>
                    <p className="line-clamp-1 text-xs text-slate-400">{seo.description}</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </Card>
      </div>

      {/* Página principal do site */}
      <Card title="🏠 Página principal do site" subtitle='Escolha o que aparece em "/". A home original continua disponível em /inicio.'>
        <div className="grid gap-3 md:grid-cols-3" role="radiogroup" aria-label="Página principal">
          {[
            { id: "home", icon: "🏠", name: "Página principal", desc: "Hero, 15 categorias e últimos artigos.", flag: true },
            { id: "loja", icon: "🛒", name: "Loja virtual", desc: "A loja vira a página inicial do site.", flag: state.features?.loja !== false },
            { id: "forum", icon: "💬", name: "Fórum", desc: "O fórum vira a página inicial do site.", flag: state.features?.forum !== false },
          ].map((o) => {
            const active = (seo.homepage || "home") === o.id;
            return (
              <button key={o.id} type="button" role="radio" aria-checked={active} onClick={() => set("homepage", o.id)}
                className={`rounded-xl border p-4 text-left transition ${active ? "border-amber-500 bg-amber-500/10 ring-2 ring-amber-500/30" : "border-slate-700 bg-slate-800/50 hover:border-slate-500"}`}>
                <span className="text-2xl" aria-hidden="true">{o.icon}</span>
                <p className="mt-1 text-sm font-bold text-slate-100">{o.name}</p>
                <p className="mt-0.5 text-xs text-slate-400">{o.desc}</p>
                {!o.flag && <p className="mt-1 text-xs text-rose-400">⚠ sessão desabilitada — o site usará a página principal</p>}
              </button>
            );
          })}
        </div>
      </Card>

      {/* Estrutura de links (slug padrão dos artigos) */}
      <Card
        title="🔗 Estrutura de links dos artigos (slug padrão)"
        subtitle='Escolha como as URLs dos artigos são montadas. A antiga base "/artigo/" não é mais usada; links antigos redirecionam automaticamente.'
      >
        <div className="grid gap-3 md:grid-cols-3" role="radiogroup" aria-label="Estrutura de links">
          {PERMALINK_OPTIONS.map((o) => {
            const active = (pl.structure || "titulo") === o.id;
            return (
              <button key={o.id} type="button" role="radio" aria-checked={active} onClick={() => setPl({ structure: o.id })}
                className={`rounded-xl border p-4 text-left transition ${active ? "border-amber-500 bg-amber-500/10 ring-2 ring-amber-500/30" : "border-slate-700 bg-slate-800/50 hover:border-slate-500"}`}>
                <p className="text-sm font-bold text-slate-100">{o.name}</p>
                <code className="mt-1 block truncate text-xs text-amber-300">{(pl.base ? "/" + pl.base.replace(/^\/+|\/+$/g, "") : "") + o.example}</code>
                <p className="mt-1 text-xs text-slate-400">{o.desc}</p>
              </button>
            );
          })}
        </div>
        <div className="mt-4 grid gap-4 md:grid-cols-2">
          <div>
            <label htmlFor="pl-base" className={labelCls}>Prefixo opcional (slug base)</label>
            <div className="flex items-center gap-1">
              <span className="text-sm text-slate-500">/</span>
              <input id="pl-base" className={inputCls} value={pl.base || ""} onChange={(e) => setPl({ base: e.target.value })}
                placeholder="vazio = sem prefixo (ex.: blog, noticias)" />
            </div>
            <p className="mt-1 text-xs text-slate-500">Reservados: {RESERVED_BASES.map((r) => "/" + r).join(", ")}.</p>
            {plError && <p role="alert" className="mt-2 text-sm text-rose-400">{plError}</p>}
          </div>
          <div>
            <p className={labelCls}>Prévia com artigos reais</p>
            <ul className="space-y-1 rounded-xl border border-slate-800 bg-slate-950 p-3 font-mono text-xs">
              {sampleArticles.map((a) => (
                <li key={a.id} className="truncate text-emerald-300" data-permalink-preview>{articlePath(a, previewState)}</li>
              ))}
            </ul>
            <p className="mt-1 text-xs text-slate-500">Subcategoria: defina a “categoria-mãe” em Painel → Categorias (ou marque 2 categorias no artigo).</p>
          </div>
        </div>
      </Card>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card title="robots.txt" subtitle="Conteúdo servido em /robots.txt (bloqueia /login e /admin por padrão).">
          <textarea
            className={`${inputCls} font-mono`}
            rows={8}
            value={seo.robotsTxt || ""}
            onChange={(e) => set("robotsTxt", e.target.value)}
            aria-label="Conteúdo do robots.txt"
          />
          <p className="mt-2 text-xs text-slate-500">
            A rota /login e o painel /admin também são noindex via meta tag e bloqueados no robots.txt estático do projeto.
          </p>
        </Card>

        <Card
          title="Sitemap"
          subtitle="Gerado dinamicamente a partir de categorias e artigos publicados."
          actions={
            <button type="button" className="rounded-lg border border-slate-700 px-3 py-1.5 text-xs font-semibold text-slate-300 hover:bg-slate-800"
              onClick={() => download("sitemap.xml", sitemap, "application/xml")}>
              ⬇ Baixar sitemap.xml
            </button>
          }
        >
          <pre className="admin-scroll max-h-64 overflow-y-auto rounded-xl bg-slate-950 p-4 font-mono text-xs text-emerald-300/90">
            {sitemap}
          </pre>
        </Card>
      </div>
    </div>
  );
}
