// Painel → Redes Sociais: links oficiais (ou trocados por outras redes) exibidos no
// rodapé esquerdo do site, abrindo em nova aba. Toggle geral + toggle individual.
import { useState } from "react";
import { Card, inputCls, btnPrimary, btnGhost, btnDanger, Toggle } from "./ui.jsx";
import { SocialIcon } from "../components/SocialIcon.jsx";
import { SOCIAL_NETWORKS, NETWORK_BY_ID } from "../data/socialNetworks.js";
import { updateState } from "../store.js";
import { addLog } from "../auth.js";
import { uid } from "../utils.js";

export default function SocialAdmin({ state }) {
  const [form, setForm] = useState(() => JSON.parse(JSON.stringify(state.social || { enabled: true, items: [] })));
  const [error, setError] = useState("");
  const [saved, setSaved] = useState(false);

  const setItem = (id, patch) => setForm((f) => ({ ...f, items: f.items.map((i) => (i.id === id ? { ...i, ...patch } : i)) }));
  const move = (idx, dir) => setForm((f) => {
    const items = [...f.items];
    const j = idx + dir;
    if (j < 0 || j >= items.length) return f;
    [items[idx], items[j]] = [items[j], items[idx]];
    return { ...f, items };
  });

  const save = () => {
    setError("");
    const bad = form.items.find((i) => i.enabled && !/^https?:\/\/\S+$/i.test(i.url || ""));
    if (bad) return setError(`Link inválido em ${NETWORK_BY_ID[bad.network]?.name}: use um endereço completo (https://…).`);
    updateState((s) => { s.social = form; });
    addLog("sistema", `Redes sociais atualizadas (${form.items.filter((i) => i.enabled).length} ativas, geral ${form.enabled ? "ligado" : "desligado"})`);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const active = form.items.filter((i) => i.enabled).length;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-white">🌐 Redes Sociais</h1>
          <p className="mt-1 text-sm text-slate-400">
            Links exibidos no rodapé esquerdo do site, com ícones oficiais, abrindo em nova aba.
          </p>
        </div>
        <button type="button" className={btnPrimary} onClick={save}>{saved ? "✓ Salvo!" : "Salvar redes sociais"}</button>
      </div>

      <Card title="Exibição no site">
        <Toggle
          label={form.enabled ? `Redes sociais HABILITADAS (${active} ativas)` : "Redes sociais DESABILITADAS"}
          desc="Liga/desliga todas as redes sociais do rodapé de uma vez (as configurações individuais são mantidas)."
          checked={form.enabled !== false}
          onChange={(v) => setForm((f) => ({ ...f, enabled: v }))}
        />
        <div className="mt-3 flex flex-wrap gap-2">
          <button type="button" className={btnGhost} onClick={() => setForm((f) => ({ ...f, items: f.items.map((i) => ({ ...i, enabled: true })) }))}>Ativar todas</button>
          <button type="button" className={btnGhost} onClick={() => setForm((f) => ({ ...f, items: f.items.map((i) => ({ ...i, enabled: false })) }))}>Desativar todas</button>
        </div>
      </Card>

      {error && <p role="alert" className="rounded-xl border border-rose-500/40 bg-rose-500/10 px-4 py-3 text-sm text-rose-300">{error}</p>}

      <Card
        title={`Redes (${form.items.length})`}
        subtitle="Cole o link oficial do seu perfil, troque a rede pelo seletor ou adicione novas."
        actions={
          <button type="button" className={btnGhost}
            onClick={() => setForm((f) => ({ ...f, items: [...f.items, { id: uid(), network: "instagram", url: NETWORK_BY_ID.instagram.url, enabled: true }] }))}>
            + Adicionar rede
          </button>
        }
      >
        <ul className="divide-y divide-slate-800">
          {form.items.map((i, idx) => {
            const n = NETWORK_BY_ID[i.network];
            return (
              <li key={i.id} className={`flex flex-wrap items-center gap-3 py-3 ${i.enabled ? "" : "opacity-50"}`} data-social-row={i.network}>
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg" style={{ background: n?.color === "#000000" || n?.color === "#181717" ? "#334155" : n?.color }}>
                  <SocialIcon network={i.network} className="h-5 w-5" color={n?.color === "#FFFC00" ? "#111" : "#fff"} />
                </span>
                <select
                  className={`${inputCls} w-auto`}
                  value={i.network}
                  aria-label="Trocar rede social"
                  onChange={(e) => {
                    const old = NETWORK_BY_ID[i.network];
                    const next = NETWORK_BY_ID[e.target.value];
                    // se o link era o padrão da rede antiga, troca pelo padrão da nova
                    setItem(i.id, { network: next.id, url: !i.url || i.url === old?.url ? next.url : i.url });
                  }}
                >
                  {SOCIAL_NETWORKS.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}
                </select>
                <input
                  className={`${inputCls} min-w-0 flex-1 basis-56`}
                  value={i.url}
                  onChange={(e) => setItem(i.id, { url: e.target.value })}
                  placeholder={`${n?.url}seu-perfil`}
                  aria-label={`Link do ${n?.name}`}
                />
                <a href={i.url} target="_blank" rel="noopener noreferrer" className="text-xs text-amber-400 hover:underline" title="Testar link em nova aba">testar ↗</a>
                <div className="flex items-center gap-1">
                  <button type="button" className={`${btnGhost} !px-2 !py-1`} onClick={() => move(idx, -1)} aria-label="Mover para cima">↑</button>
                  <button type="button" className={`${btnGhost} !px-2 !py-1`} onClick={() => move(idx, 1)} aria-label="Mover para baixo">↓</button>
                </div>
                <button
                  type="button"
                  role="switch"
                  aria-checked={!!i.enabled}
                  aria-label={`Exibir ${n?.name}`}
                  onClick={() => setItem(i.id, { enabled: !i.enabled })}
                  className={`relative h-6 w-11 shrink-0 rounded-full transition-colors ${i.enabled ? "bg-amber-500" : "bg-slate-700"}`}
                >
                  <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${i.enabled ? "left-[22px]" : "left-0.5"}`} />
                </button>
                <button type="button" className={`${btnDanger} !px-2 !py-1`} aria-label={`Remover ${n?.name}`}
                  onClick={() => setForm((f) => ({ ...f, items: f.items.filter((x) => x.id !== i.id) }))}>✕</button>
              </li>
            );
          })}
        </ul>
      </Card>
    </div>
  );
}
