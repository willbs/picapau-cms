// Painel → Tema: 10 modelos de página inicial no estilo Revista Digital (+ a página Original),
// blocos que podem ser adicionados/retirados/reordenados, categorias e postagens em destaque.
// As alterações são salvas na hora e aparecem na prévia ao vivo.
import { Card, btnGhost, btnPrimary, Badge } from "./ui.jsx";
import { updateState } from "../store.js";
import { addLog } from "../auth.js";
import { navigate } from "../router.js";
import { cn, TYPE_ICONS } from "../utils.js";
import { MAG_TEMPLATES, BLOCK_TYPES, DEFAULT_THEME, themeConfig, MagazineBody } from "../pages/MagazineHome.jsx";

const HERO_ICON = { split: "◧", full: "▣", mosaic: "▦", slider: "⇆", list: "☰", masthead: "📰" };

function Thumb({ t }) {
  return (
    <div className="flex h-16 w-full flex-col gap-1 rounded-md border border-slate-700 p-1.5" style={{ background: t.dark ? "#0f172a" : "#f8fafc" }}>
      <div className="flex items-center gap-1">
        <span className="h-1.5 w-6 rounded" style={{ background: t.thumb }} />
        <span className="text-[10px]" style={{ color: t.thumb }}>{HERO_ICON[t.hero]}</span>
      </div>
      <div className="flex flex-1 gap-1">
        <span className="flex-[2] rounded-sm" style={{ background: t.thumb, opacity: 0.75 }} />
        <span className="flex flex-1 flex-col gap-1">
          <span className="flex-1 rounded-sm bg-slate-400/60" />
          <span className="flex-1 rounded-sm bg-slate-400/60" />
        </span>
        {t.sidebar && <span className="w-3 rounded-sm bg-slate-500/60" />}
      </div>
    </div>
  );
}

export default function ThemeAdmin({ state }) {
  const cfg = themeConfig(state);
  const pub = (state.articles || []).filter((a) => a.status === "publicado");
  const save = (patch, log) => {
    updateState((s) => { s.theme = { ...themeConfig(s), ...patch }; });
    if (log) addLog("sistema", log);
  };
  const setTemplate = (id) => save({ template: id }, `Tema da página inicial alterado para "${id}"`);
  const toggleBlock = (id) => save({ blocks: cfg.blocks.map((b) => (b.id === id ? { ...b, enabled: !b.enabled } : b)) });
  const moveBlock = (i, d) => {
    const arr = [...cfg.blocks];
    const j = i + d;
    if (j < 0 || j >= arr.length) return;
    [arr[i], arr[j]] = [arr[j], arr[i]];
    save({ blocks: arr });
  };
  const toggleCat = (slug) => save({
    featuredCategories: cfg.featuredCategories.includes(slug) ? cfg.featuredCategories.filter((s) => s !== slug) : [...cfg.featuredCategories, slug],
  });
  const toggleArt = (id) => save({
    featuredArticles: cfg.featuredArticles.includes(id) ? cfg.featuredArticles.filter((x) => x !== id) : [...cfg.featuredArticles, id],
  });
  const moveArt = (i, d) => {
    const arr = [...cfg.featuredArticles];
    const j = i + d;
    if (j < 0 || j >= arr.length) return;
    [arr[i], arr[j]] = [arr[j], arr[i]];
    save({ featuredArticles: arr });
  };
  const isOriginal = cfg.template === "original";

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-white">🖌️ Tema</h1>
          <p className="mt-1 text-sm text-slate-400">Modelos de página inicial no estilo Revista Digital — as alterações são aplicadas na hora.</p>
        </div>
        <button type="button" className={btnGhost} onClick={() => navigate("/")}>🌐 Ver página inicial</button>
      </div>

      <Card title="Modelo da página inicial" subtitle="10 modelos de Revista Digital, ou a página Original do site.">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-6" role="radiogroup" aria-label="Modelo da página inicial">
          <button type="button" role="radio" aria-checked={isOriginal} onClick={() => setTemplate("original")}
            className={cn("rounded-xl border p-3 text-left transition", isOriginal ? "border-amber-500 bg-amber-500/10 ring-2 ring-amber-500/30" : "border-slate-700 bg-slate-800/50 hover:border-slate-500")}>
            <div className="flex h-16 items-center justify-center rounded-md border border-slate-700 bg-slate-900 text-2xl">🏠</div>
            <p className="mt-2 text-sm font-bold text-slate-100">Original</p>
            <p className="mt-0.5 text-xs text-slate-400">Hero, 15 categorias e últimos artigos (blocos fixos).</p>
          </button>
          {MAG_TEMPLATES.map((t, i) => {
            const active = cfg.template === t.id;
            return (
              <button key={t.id} type="button" role="radio" aria-checked={active} onClick={() => setTemplate(t.id)} data-theme-option={t.id}
                className={cn("rounded-xl border p-3 text-left transition", active ? "border-amber-500 bg-amber-500/10 ring-2 ring-amber-500/30" : "border-slate-700 bg-slate-800/50 hover:border-slate-500")}>
                <Thumb t={t} />
                <p className="mt-2 text-sm font-bold text-slate-100">{i + 1}. {t.name}</p>
                <p className="mt-0.5 text-xs text-slate-400">{t.desc}</p>
              </button>
            );
          })}
        </div>
      </Card>

      {isOriginal ? (
        <p className="rounded-xl border border-slate-800 bg-slate-900/60 p-4 text-sm text-slate-400">
          A página Original tem blocos fixos. Escolha um dos 10 modelos de Revista Digital para adicionar/retirar blocos e escolher destaques.
        </p>
      ) : (
        <>
          <div className="grid gap-5 lg:grid-cols-2">
            <Card title="Blocos da página inicial" subtitle="Adicione ou retire blocos e mude a ordem.">
              <ul className="space-y-2" aria-label="Blocos da página inicial">
                {cfg.blocks.map((b, i) => {
                  const meta = BLOCK_TYPES.find((x) => x.id === b.id);
                  return (
                    <li key={b.id} className={cn("flex items-center gap-2 rounded-xl border px-3 py-2", b.enabled ? "border-amber-500/40 bg-amber-500/5" : "border-slate-800 opacity-60")} data-block-row={b.id}>
                      <button type="button" role="switch" aria-checked={b.enabled} aria-label={`Exibir bloco ${meta.label}`} onClick={() => toggleBlock(b.id)}
                        className={`relative h-6 w-11 shrink-0 rounded-full transition-colors ${b.enabled ? "bg-amber-500" : "bg-slate-700"}`}>
                        <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${b.enabled ? "left-[22px]" : "left-0.5"}`} />
                      </button>
                      <span className="min-w-0 flex-1 text-sm text-slate-200">{meta.label}</span>
                      <button type="button" className={`${btnGhost} !px-2 !py-1`} onClick={() => moveBlock(i, -1)} aria-label={`Subir ${meta.label}`}>↑</button>
                      <button type="button" className={`${btnGhost} !px-2 !py-1`} onClick={() => moveBlock(i, 1)} aria-label={`Descer ${meta.label}`}>↓</button>
                    </li>
                  );
                })}
              </ul>
              <button type="button" className={`${btnGhost} mt-3`} onClick={() => save({ blocks: DEFAULT_THEME.blocks })}>Restaurar blocos padrão</button>
            </Card>

            <Card title="Categorias em destaque" subtitle="Usadas nos blocos “Categorias em destaque” e “Seções por categoria”. Nenhuma marcada = todas.">
              <div className="flex flex-wrap gap-2" aria-label="Categorias em destaque">
                {state.categories.map((c) => {
                  const on = cfg.featuredCategories.includes(c.slug);
                  return (
                    <button key={c.id} type="button" aria-pressed={on} onClick={() => toggleCat(c.slug)} data-feat-cat={c.slug}
                      className={cn("rounded-full border px-3 py-1.5 text-sm", on ? "border-amber-500 bg-amber-500/15 text-amber-200" : "border-slate-700 text-slate-400 hover:text-slate-200")}>
                      {c.icon} {c.name}{on && ` · ${cfg.featuredCategories.indexOf(c.slug) + 1}`}
                    </button>
                  );
                })}
              </div>
            </Card>
          </div>

          <Card title={`Postagens em destaque (${cfg.featuredArticles.length})`} subtitle="Aparecem no destaque principal e no bloco “Postagens em destaque”, na ordem abaixo. Nenhuma marcada = mais recentes.">
            {cfg.featuredArticles.length > 0 && (
              <ol className="mb-4 space-y-2" aria-label="Ordem das postagens em destaque">
                {cfg.featuredArticles.map((id, i) => {
                  const a = pub.find((x) => x.id === id);
                  if (!a) return null;
                  return (
                    <li key={id} className="flex items-center gap-2 rounded-xl border border-amber-500/40 bg-amber-500/5 px-3 py-2 text-sm text-slate-200">
                      <Badge tone="agendado">{i + 1}</Badge>
                      <span className="min-w-0 flex-1 truncate">{TYPE_ICONS[a.type]} {a.title}</span>
                      <button type="button" className={`${btnGhost} !px-2 !py-1`} onClick={() => moveArt(i, -1)} aria-label={`Subir ${a.title}`}>↑</button>
                      <button type="button" className={`${btnGhost} !px-2 !py-1`} onClick={() => moveArt(i, 1)} aria-label={`Descer ${a.title}`}>↓</button>
                      <button type="button" className={`${btnGhost} !px-2 !py-1`} onClick={() => toggleArt(id)} aria-label={`Tirar ${a.title} dos destaques`}>✕</button>
                    </li>
                  );
                })}
              </ol>
            )}
            <ul className="grid gap-2 md:grid-cols-2" aria-label="Postagens publicadas">
              {pub.map((a) => (
                <li key={a.id}>
                  <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-slate-800 px-3 py-2 text-sm text-slate-300 hover:border-slate-600">
                    <input type="checkbox" checked={cfg.featuredArticles.includes(a.id)} onChange={() => toggleArt(a.id)} aria-label={`Destacar ${a.title}`} />
                    <span className="truncate">{TYPE_ICONS[a.type]} {a.title}</span>
                  </label>
                </li>
              ))}
            </ul>
          </Card>
        </>
      )}

      <Card title="👁 Prévia ao vivo" subtitle="Miniatura da página inicial com o modelo e os blocos escolhidos."
        actions={<button type="button" className={btnPrimary} onClick={() => navigate("/")}>Abrir página inicial</button>}>
        {isOriginal ? (
          <p className="text-sm text-slate-400">A página Original está ativa.</p>
        ) : (
          <div className="relative h-[520px] overflow-hidden rounded-xl border border-slate-700 bg-white" data-theme-preview>
            <div className="pointer-events-none absolute left-0 top-0 w-[1280px] origin-top-left select-none" style={{ transform: "scale(0.55)" }} aria-hidden="true">
              <MagazineBody state={state} />
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}
