// Gerenciador de menus: menus simples e mega menus (até 3 níveis de profundidade),
// reordenação por arrastar e soltar, colunas com links/imagens/descrições,
// definição do menu principal (header) e menus secundários (footer), com preview.
import { useState } from "react";
import { Card, inputCls, labelCls, btnPrimary, btnGhost, btnDanger, Badge } from "./ui.jsx";
import Modal from "../components/Modal.jsx";
import { itemUrl } from "../components/Layout.jsx";
import { updateState } from "../store.js";
import { uid } from "../utils.js";
import { articlePath } from "../permalink.js";

/* ------------------------- helpers de árvore imutável ------------------------- */

function mapItems(items, id, fn) {
  return (items || []).map((it) => {
    if (it.id === id) return fn(it);
    if (it.children) return { ...it, children: mapItems(it.children, id, fn) };
    return it;
  });
}

function blankItem() {
  return { id: uid(), label: "Novo item", type: "link", url: "/", children: [] };
}

function blankColumn() {
  return { id: uid(), title: "Coluna", links: [] };
}

function blankMegaLink() {
  return { id: uid(), label: "Novo link", type: "link", url: "/", desc: "", image: "" };
}

/* ------------------------------ editor de itens ------------------------------ */

function ItemRow({ item, items, onItemsChange, depth, state, dragId, setDragId }) {
  const isMega = item.mega || item.type === "mega";

  const patch = (p) => onItemsChange(mapItems(items, item.id, (it) => ({ ...it, ...p })));
  const patchChild = (children) => patch({ children });

  const addChild = () =>
    patchChild([...(item.children || []), blankItem()]);

  const remove = () => onItemsChange(items.filter((i) => i.id !== item.id));

  const onDropHere = () => {
    if (!dragId || dragId === item.id) return;
    const from = items.findIndex((i) => i.id === dragId);
    const to = items.findIndex((i) => i.id === item.id);
    if (from < 0 || to < 0) return;
    const arr = [...items];
    const [moved] = arr.splice(from, 1);
    arr.splice(to, 0, moved);
    onItemsChange(arr);
    setDragId(null);
  };

  return (
    <li
      className={`rounded-xl border border-slate-800 bg-slate-900/70 p-3 ${dragId === item.id ? "opacity-40" : ""}`}
      draggable
      onDragStart={(e) => {
        e.stopPropagation();
        setDragId(item.id);
      }}
      onDragOver={(e) => e.preventDefault()}
      onDrop={(e) => {
        e.stopPropagation();
        onDropHere();
      }}
    >
      <div className="flex flex-wrap items-center gap-2">
        <span className="cursor-grab select-none text-slate-600" title="Arrastar para reordenar" aria-hidden="true">⠿</span>
        <input
          className={`${inputCls} max-w-40`}
          value={item.label}
          onChange={(e) => patch({ label: e.target.value })}
          aria-label="Rótulo do item"
        />
        <select
          className={`${inputCls} w-auto`}
          value={isMega ? "mega" : item.type}
          onChange={(e) => {
            const v = e.target.value;
            if (v === "mega") patch({ type: "mega", mega: true, columns: item.columns?.length ? item.columns : [blankColumn()] });
            else patch({ type: v, mega: false, columns: [] });
          }}
          aria-label="Tipo do item"
        >
          <option value="link">🔗 Link</option>
          <option value="category">🗂️ Categoria</option>
          <option value="article">✍️ Artigo</option>
          <option value="mega">🌐 Mega menu</option>
        </select>

        {!isMega && item.type === "link" && (
          <input
            className={`${inputCls} max-w-48`}
            value={item.url || ""}
            onChange={(e) => patch({ url: e.target.value })}
            placeholder="/rota"
            aria-label="URL do link"
          />
        )}
        {!isMega && item.type === "category" && (
          <select
            className={`${inputCls} w-auto`}
            value={item.categorySlug || ""}
            onChange={(e) => patch({ categorySlug: e.target.value, url: `/categoria/${e.target.value}` })}
            aria-label="Categoria"
          >
            <option value="">— escolha —</option>
            {state.categories.map((c) => (
              <option key={c.id} value={c.slug}>{c.icon} {c.name}</option>
            ))}
          </select>
        )}
        {!isMega && item.type === "article" && (
          <select
            className={`${inputCls} w-auto max-w-56`}
            value={item.articleSlug || ""}
            onChange={(e) => patch({ articleSlug: e.target.value, url: articlePath(e.target.value) })}
            aria-label="Artigo"
          >
            <option value="">— escolha —</option>
            {state.articles.map((a) => (
              <option key={a.id} value={a.slug}>{a.title || a.slug}</option>
            ))}
          </select>
        )}

        {!isMega && depth < 3 && (
          <button type="button" className={`${btnGhost} !px-2 !py-1 !text-xs`} onClick={addChild} title="Adicionar subitem (até 3 níveis)">
            + subitem
          </button>
        )}
        <div className="ml-auto">
          <button type="button" className={`${btnDanger} !px-2 !py-1 !text-xs`} onClick={remove}>✕</button>
        </div>
      </div>

      {!isMega && (
        <div className="mt-2 grid gap-2 sm:grid-cols-2">
          <input className={inputCls} value={item.desc || ""} onChange={(e) => patch({ desc: e.target.value })} placeholder="Descrição curta (opcional)" aria-label="Descrição do item" />
          <input className={inputCls} value={item.image || ""} onChange={(e) => patch({ image: e.target.value })} placeholder="Imagem/banner (URL, opcional)" aria-label="Imagem do item" />
        </div>
      )}

      {/* Editor do mega menu: colunas com links */}
      {isMega && (
        <div className="mt-3 rounded-xl border border-indigo-500/30 bg-indigo-500/5 p-3">
          <p className="mb-2 text-xs font-bold uppercase tracking-wide text-indigo-300">🌐 Colunas do mega menu</p>
          <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            {(item.columns || []).map((col, ci) => (
              <div key={col.id} className="rounded-lg border border-slate-700 bg-slate-900/80 p-3">
                <div className="mb-2 flex items-center gap-2">
                  <input
                    className={`${inputCls} !py-1`}
                    value={col.title}
                    onChange={(e) =>
                      patch({
                        columns: item.columns.map((c, i) => (i === ci ? { ...c, title: e.target.value } : c)),
                      })
                    }
                    aria-label="Título da coluna"
                  />
                  <button
                    type="button"
                    className={`${btnDanger} !px-2 !py-1 !text-xs`}
                    onClick={() => patch({ columns: item.columns.filter((c) => c.id !== col.id) })}
                    aria-label="Remover coluna"
                  >
                    ✕
                  </button>
                </div>
                <ul className="space-y-2">
                  {(col.links || []).map((l, li) => (
                    <li key={l.id} className="rounded-lg border border-slate-800 p-2">
                      <div className="flex items-center gap-2">
                        <input className={`${inputCls} !py-1`} value={l.label} placeholder="Rótulo"
                          onChange={(e) =>
                            patch({
                              columns: item.columns.map((c, i) =>
                                i === ci ? { ...c, links: c.links.map((x, j) => (j === li ? { ...x, label: e.target.value } : x)) } : c
                              ),
                            })
                          } />
                        <select
                          className={`${inputCls} !w-auto !py-1`}
                          value={l.type || "link"}
                          onChange={(e) => {
                            const v = e.target.value;
                            patch({
                              columns: item.columns.map((c, i) =>
                                i === ci ? { ...c, links: c.links.map((x, j) => (j === li ? { ...x, type: v } : x)) } : c
                              ),
                            });
                          }}
                        >
                          <option value="link">Link</option>
                          <option value="category">Categoria</option>
                          <option value="article">Artigo</option>
                        </select>
                        <button type="button" className={`${btnDanger} !px-1.5 !py-1 !text-xs`} aria-label="Remover link"
                          onClick={() =>
                            patch({
                              columns: item.columns.map((c, i) =>
                                i === ci ? { ...c, links: c.links.filter((x) => x.id !== l.id) } : c
                              ),
                            })
                          }>✕</button>
                      </div>
                      <div className="mt-1.5 grid gap-1.5">
                        {(l.type || "link") === "link" && (
                          <input className={`${inputCls} !py-1 !text-xs`} value={l.url || ""} placeholder="/rota"
                            onChange={(e) =>
                              patch({
                                columns: item.columns.map((c, i) =>
                                  i === ci ? { ...c, links: c.links.map((x, j) => (j === li ? { ...x, url: e.target.value } : x)) } : c
                                ),
                              })
                            } />
                        )}
                        {(l.type || "link") === "category" && (
                          <select className={`${inputCls} !py-1 !text-xs`}
                            value={l.categorySlug || ""}
                            onChange={(e) =>
                              patch({
                                columns: item.columns.map((c, i) =>
                                  i === ci ? { ...c, links: c.links.map((x, j) => (j === li ? { ...x, categorySlug: e.target.value, url: `/categoria/${e.target.value}` } : x)) } : c
                                ),
                              })
                            }>
                            <option value="">— categoria —</option>
                            {state.categories.map((c) => <option key={c.id} value={c.slug}>{c.icon} {c.name}</option>)}
                          </select>
                        )}
                        {(l.type || "link") === "article" && (
                          <select className={`${inputCls} !py-1 !text-xs`}
                            value={l.articleSlug || ""}
                            onChange={(e) =>
                              patch({
                                columns: item.columns.map((c, i) =>
                                  i === ci ? { ...c, links: c.links.map((x, j) => (j === li ? { ...x, articleSlug: e.target.value, url: articlePath(e.target.value) } : x)) } : c
                                ),
                              })
                            }>
                            <option value="">— artigo —</option>
                            {state.articles.map((a) => <option key={a.id} value={a.slug}>{a.title || a.slug}</option>)}
                          </select>
                        )}
                        <input className={`${inputCls} !py-1 !text-xs`} value={l.desc || ""} placeholder="Descrição curta"
                          onChange={(e) =>
                            patch({
                              columns: item.columns.map((c, i) =>
                                i === ci ? { ...c, links: c.links.map((x, j) => (j === li ? { ...x, desc: e.target.value } : x)) } : c
                              ),
                            })
                          } />
                        <input className={`${inputCls} !py-1 !text-xs`} value={l.image || ""} placeholder="Imagem destaque (URL)"
                          onChange={(e) =>
                            patch({
                              columns: item.columns.map((c, i) =>
                                i === ci ? { ...c, links: c.links.map((x, j) => (j === li ? { ...x, image: e.target.value } : x)) } : c
                              ),
                            })
                          } />
                      </div>
                    </li>
                  ))}
                </ul>
                <button
                  type="button"
                  className={`${btnGhost} mt-2 !px-2 !py-1 !text-xs`}
                  onClick={() =>
                    patch({
                      columns: item.columns.map((c, i) =>
                        i === ci ? { ...c, links: [...c.links, blankMegaLink()] } : c
                      ),
                    })
                  }
                >
                  + link na coluna
                </button>
              </div>
            ))}
          </div>
          <button
            type="button"
            className={`${btnGhost} mt-3 !text-xs`}
            onClick={() => patch({ columns: [...(item.columns || []), blankColumn()] })}
          >
            + Adicionar coluna
          </button>
        </div>
      )}

      {/* Subitens (até 3 níveis) */}
      {!isMega && (item.children || []).length > 0 && (
        <ul className="ml-6 mt-2 space-y-2 border-l-2 border-slate-800 pl-3">
          <ItemList items={item.children} onChange={patchChild} depth={depth + 1} state={state} dragId={dragId} setDragId={setDragId} />
        </ul>
      )}
    </li>
  );
}

function ItemList({ items, onChange, depth, state, dragId, setDragId }) {
  return (
    <>
      {items.map((item) => (
        <ItemRow
          key={item.id}
          item={item}
          items={items}
          onItemsChange={onChange}
          depth={depth}
          state={state}
          dragId={dragId}
          setDragId={setDragId}
        />
      ))}
    </>
  );
}

/* ------------------------------ preview do menu ------------------------------ */

function MenuPreview({ menu, state }) {
  return (
    <div className="overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-700 dark:bg-slate-900">
      <div className="flex items-center gap-2 border-b border-slate-200 bg-slate-50 px-4 py-3 dark:border-slate-700 dark:bg-slate-800">
        <img src={state.seo.favicon || "/favicon.svg"} alt="" className="h-6 w-6 rounded" />
        <span className="text-sm font-extrabold text-slate-900 dark:text-white">{state.seo.ogSiteName || state.seo.title}</span>
        <nav className="ml-4 flex flex-wrap items-center gap-1" aria-label="Prévia do menu">
          {menu.items.map((it) => (
            <span key={it.id} className="rounded-lg px-2.5 py-1.5 text-sm font-medium text-slate-700 dark:text-slate-200">
              {it.label} {it.mega || it.type === "mega" ? " ▾(mega)" : (it.children || []).length ? " ▸" : ""}
            </span>
          ))}
        </nav>
      </div>
      {/* Detalhe expandido */}
      <div className="space-y-3 p-4">
        {menu.items.map((it) => (
          <div key={it.id}>
            <p className="text-xs font-bold uppercase tracking-wide text-amber-600">{it.label}</p>
            {it.mega || it.type === "mega" ? (
              <div className="mt-2 grid gap-3 sm:grid-cols-3">
                {(it.columns || []).map((col) => (
                  <div key={col.id}>
                    <p className="mb-1 text-xs font-semibold text-slate-500">{col.title}</p>
                    <ul className="space-y-1">
                      {(col.links || []).map((l) => (
                        <li key={l.id} className="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300">
                          {l.image && <img src={l.image} alt="" className="h-7 w-10 rounded object-cover" loading="lazy" />}
                          <span>
                            {l.label}
                            {l.desc && <span className="block text-xs text-slate-400">{l.desc}</span>}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            ) : (
              <ul className="mt-1 space-y-1">
                {(it.children || []).map((c) => (
                  <li key={c.id} className="text-sm text-slate-700 dark:text-slate-300">
                    {c.label}
                    {(c.children || []).length > 0 && (
                      <ul className="ml-4 list-disc">
                        {c.children.map((g) => (
                          <li key={g.id} className="text-xs text-slate-500">{g.label} → {itemUrl(g, state)}</li>
                        ))}
                      </ul>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ------------------------------ página principal ------------------------------ */

export default function MenusAdmin({ state }) {
  const [editingId, setEditingId] = useState(null);
  const [draft, setDraft] = useState(null);
  const [dragId, setDragId] = useState(null);
  const [preview, setPreview] = useState(false);

  const openNew = () => {
    setDraft({ id: uid(), name: "Novo menu", location: "footer", isMain: false, items: [] });
    setEditingId("__new__");
  };

  const openEdit = (menu) => {
    setDraft(JSON.parse(JSON.stringify(menu)));
    setEditingId(menu.id);
  };

  const saveDraft = () => {
    if (!draft.name.trim()) return;
    updateState((s) => {
      if (editingId === "__new__") s.menus.push(draft);
      else {
        const i = s.menus.findIndex((m) => m.id === editingId);
        if (i >= 0) s.menus[i] = draft;
      }
      // garante apenas um menu principal no header
      if (draft.location === "header" && draft.isMain) {
        s.menus.forEach((m) => {
          if (m.location === "header" && m.id !== draft.id) m.isMain = false;
        });
      }
    });
    setEditingId(null);
    setDraft(null);
  };

  const removeMenu = (menu) => {
    if (!window.confirm(`Excluir o menu "${menu.name}"?`)) return;
    updateState((s) => {
      s.menus = s.menus.filter((m) => m.id !== menu.id);
    });
  };

  const setMain = (menu) => {
    updateState((s) => {
      s.menus.forEach((m) => {
        m.isMain = m.id === menu.id;
      });
    });
  };

  if (editingId) {
    return (
      <div className="space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-extrabold text-white">Editar menu</h1>
            <p className="mt-1 text-sm text-slate-400">Arraste os itens (⠿) para reordenar · até 3 níveis · mega menu com colunas</p>
          </div>
          <div className="flex gap-2">
            <button type="button" className={btnGhost} onClick={() => setPreview(true)}>👁 Preview</button>
            <button type="button" className={btnGhost} onClick={() => { setEditingId(null); setDraft(null); }}>Cancelar</button>
            <button type="button" className={btnPrimary} onClick={saveDraft}>Salvar menu</button>
          </div>
        </div>

        <Card title="Configurações do menu">
          <div className="grid gap-4 md:grid-cols-3">
            <div>
              <label htmlFor="m-name" className={labelCls}>Nome</label>
              <input id="m-name" className={inputCls} value={draft.name} onChange={(e) => setDraft((d) => ({ ...d, name: e.target.value }))} />
            </div>
            <div>
              <label htmlFor="m-loc" className={labelCls}>Localização</label>
              <select id="m-loc" className={inputCls} value={draft.location} onChange={(e) => setDraft((d) => ({ ...d, location: e.target.value }))}>
                <option value="header">Cabeçalho (header)</option>
                <option value="footer">Rodapé (footer)</option>
              </select>
            </div>
            {draft.location === "header" && (
              <div className="flex items-end">
                <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-slate-700 px-3 py-2 text-sm text-slate-300">
                  <input
                    type="checkbox"
                    checked={!!draft.isMain}
                    onChange={(e) => setDraft((d) => ({ ...d, isMain: e.target.checked }))}
                  />
                  Menu principal do site
                </label>
              </div>
            )}
          </div>
        </Card>

        <Card
          title="Itens do menu"
          actions={
            <button type="button" className={btnGhost} onClick={() => setDraft((d) => ({ ...d, items: [...d.items, blankItem()] }))}>
              + Adicionar item
            </button>
          }
        >
          {draft.items.length === 0 ? (
            <p className="py-6 text-center text-sm text-slate-500">Nenhum item. Adicione o primeiro acima.</p>
          ) : (
            <ul className="space-y-2">
              <ItemList items={draft.items} onChange={(items) => setDraft((d) => ({ ...d, items }))} depth={1} state={state} dragId={dragId} setDragId={setDragId} />
            </ul>
          )}
        </Card>

        <Modal open={preview} onClose={() => setPreview(false)} title={`Preview — ${draft.name}`} wide>
          <MenuPreview menu={draft} state={state} />
        </Modal>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-white">Menus</h1>
          <p className="mt-1 text-sm text-slate-400">
            Crie menus simples ou mega menus (colunas com links, imagens e descrições) para header e footer.
          </p>
        </div>
        <button type="button" className={btnPrimary} onClick={openNew}>+ Novo menu</button>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {state.menus.map((menu) => (
          <Card key={menu.id} title={menu.name} subtitle={`${menu.items.length} itens`}>
            <div className="flex flex-wrap items-center gap-2">
              <Badge tone={menu.location === "header" ? "video" : "audio"}>
                {menu.location === "header" ? "☰ header" : "🦶 footer"}
              </Badge>
              {menu.isMain && <Badge tone="agendado">⭐ principal</Badge>}
              {menu.location === "header" && !menu.isMain && (
                <button type="button" className={`${btnGhost} !px-2 !py-1 !text-xs`} onClick={() => setMain(menu)}>
                  definir como principal
                </button>
              )}
              <div className="ml-auto flex gap-2">
                <button type="button" className={btnGhost} onClick={() => openEdit(menu)}>Editar</button>
                <button type="button" className={btnDanger} onClick={() => removeMenu(menu)}>Excluir</button>
              </div>
            </div>
            <ul className="mt-3 space-y-1">
              {menu.items.slice(0, 5).map((it) => (
                <li key={it.id} className="truncate text-sm text-slate-400">
                  {it.mega || it.type === "mega" ? "🌐" : "•"} {it.label}
                  {it.mega || it.type === "mega" ? ` (${(it.columns || []).length} colunas)` : ""}
                </li>
              ))}
              {menu.items.length > 5 && <li className="text-xs text-slate-600">… e mais {menu.items.length - 5}</li>}
            </ul>
          </Card>
        ))}
      </div>
    </div>
  );
}
