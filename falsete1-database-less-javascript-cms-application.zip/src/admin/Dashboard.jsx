// Dashboard do painel: estatísticas gerais e artigos recentes.
import { Card, Badge } from "./ui.jsx";
import { navigate } from "../router.js";
import { articlePath } from "../permalink.js";
import { formatDate, TYPE_ICONS, TYPE_LABELS, STATUS_LABELS } from "../utils.js";

export default function Dashboard({ state }) {
  const arts = state.articles || [];
  const byType = {
    image: arts.filter((a) => a.type === "image").length,
    video: arts.filter((a) => a.type === "video").length,
    audio: arts.filter((a) => a.type === "audio").length,
  };
  const byStatus = {
    publicado: arts.filter((a) => a.status === "publicado").length,
    rascunho: arts.filter((a) => a.status === "rascunho").length,
    agendado: arts.filter((a) => a.status === "agendado").length,
  };
  const recent = [...arts]
    .sort((a, b) => new Date(b.updatedAt || b.date) - new Date(a.updatedAt || a.date))
    .slice(0, 6);

  const stats = [
    { label: "Artigos", value: arts.length, icon: "✍️", to: "/admin/artigos" },
    { label: "Categorias", value: (state.categories || []).length, icon: "🗂️", to: "/admin/categorias" },
    { label: "Menus", value: (state.menus || []).length, icon: "☰", to: "/admin/menus" },
    { label: "Modo manutenção", value: state.security.maintenance ? "ON" : "OFF", icon: "🛠️", to: "/admin/seguranca" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-white">Painel</h1>
          <p className="mt-1 text-sm text-slate-400">
            Bem-vindo de volta, {state.security.user}. Tudo é salvo localmente no navegador.
          </p>
        </div>
        <button
          type="button"
          onClick={() => navigate("/admin/artigos/novo")}
          className="rounded-xl bg-amber-500 px-4 py-2.5 text-sm font-bold text-slate-950 shadow transition hover:bg-amber-400"
        >
          + Novo artigo
        </button>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => (
          <button
            key={s.label}
            type="button"
            onClick={() => navigate(s.to)}
            className="rounded-2xl border border-slate-800 bg-slate-900/70 p-5 text-left transition hover:border-amber-500/50 hover:bg-slate-900"
          >
            <span className="text-2xl" aria-hidden="true">{s.icon}</span>
            <p className="mt-2 text-3xl font-extrabold text-white">{s.value}</p>
            <p className="text-sm text-slate-400">{s.label}</p>
          </button>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="Artigos por tipo" className="lg:col-span-1">
          <ul className="space-y-3">
            {Object.entries(byType).map(([t, n]) => (
              <li key={t} className="flex items-center justify-between">
                <span className="flex items-center gap-2 text-sm text-slate-300">
                  {TYPE_ICONS[t]} {TYPE_LABELS[t]}
                </span>
                <Badge tone={t}>{n}</Badge>
              </li>
            ))}
          </ul>
        </Card>
        <Card title="Artigos por status" className="lg:col-span-1">
          <ul className="space-y-3">
            {Object.entries(byStatus).map(([s, n]) => (
              <li key={s} className="flex items-center justify-between">
                <span className="text-sm text-slate-300">{STATUS_LABELS[s]}</span>
                <Badge tone={s}>{n}</Badge>
              </li>
            ))}
          </ul>
        </Card>
        <Card title="Ações rápidas" className="lg:col-span-1">
          <div className="flex flex-col gap-2">
            <button type="button" onClick={() => navigate("/admin/artigos/novo")} className="rounded-lg border border-slate-700 px-3 py-2 text-left text-sm text-slate-300 hover:bg-slate-800">✍️ Publicar artigo</button>
            <button type="button" onClick={() => navigate("/admin/categorias")} className="rounded-lg border border-slate-700 px-3 py-2 text-left text-sm text-slate-300 hover:bg-slate-800">🗂️ Gerenciar categorias</button>
            <button type="button" onClick={() => navigate("/admin/menus")} className="rounded-lg border border-slate-700 px-3 py-2 text-left text-sm text-slate-300 hover:bg-slate-800">☰ Editar menus</button>
            <button type="button" onClick={() => navigate("/admin/seo")} className="rounded-lg border border-slate-700 px-3 py-2 text-left text-sm text-slate-300 hover:bg-slate-800">🔍 Configurar SEO</button>
            <button type="button" onClick={() => navigate("/admin/seguranca")} className="rounded-lg border border-slate-700 px-3 py-2 text-left text-sm text-slate-300 hover:bg-slate-800">🛡️ Segurança</button>
          </div>
        </Card>
      </div>

      <Card title="Artigos recentes" actions={
        <button type="button" onClick={() => navigate("/admin/artigos")} className="text-sm font-semibold text-amber-400 hover:text-amber-300">
          Ver todos →
        </button>
      }>
        {recent.length === 0 ? (
          <p className="text-sm text-slate-400">Nenhum artigo ainda.</p>
        ) : (
          <ul className="divide-y divide-slate-800">
            {recent.map((a) => (
              <li key={a.id} className="flex items-center gap-3 py-3">
                <button
                  type="button"
                  onClick={() => navigate(`/admin/artigos/editar/${a.id}`)}
                  className="flex min-w-0 flex-1 items-center gap-3 text-left"
                >
                  <span className="text-xl" aria-hidden="true">{TYPE_ICONS[a.type]}</span>
                  <span className="min-w-0">
                    <span className="block truncate text-sm font-semibold text-slate-100">{a.title || "(sem título)"}</span>
                    <span className="block text-xs text-slate-500">{formatDate(a.date)} · {articlePath(a, state)}</span>
                  </span>
                </button>
                <Badge tone={a.type}>{TYPE_LABELS[a.type]}</Badge>
                <Badge tone={a.status}>{STATUS_LABELS[a.status] || a.status}</Badge>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}
