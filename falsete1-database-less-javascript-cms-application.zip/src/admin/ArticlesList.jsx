// Listagem administrativa de artigos: busca + filtros por tipo/categoria/status
// e ações de editar, duplicar e excluir.
import { useMemo, useState } from "react";
import { Card, Badge, inputCls, btnPrimary, btnGhost, btnDanger } from "./ui.jsx";
import { navigate } from "../router.js";
import { articlePath } from "../permalink.js";
import { updateState } from "../store.js";
import { addLog } from "../auth.js";
import { uid, formatDate, slugify, TYPE_ICONS, TYPE_LABELS, STATUS_LABELS } from "../utils.js";

export default function ArticlesList({ state }) {
  const [q, setQ] = useState("");
  const [fType, setFType] = useState("");
  const [fCat, setFCat] = useState("");
  const [fStatus, setFStatus] = useState("");
  const [sel, setSel] = useState(() => new Set()); // artigos selecionados (ações em massa)
  const [bulkMsg, setBulkMsg] = useState("");

  const filtered = useMemo(() => {
    return (state.articles || [])
      .filter((a) => {
        if (fType && a.type !== fType) return false;
        if (fStatus && a.status !== fStatus) return false;
        if (fCat && !(a.categories || []).includes(fCat)) return false;
        if (q) {
          const hay = `${a.title} ${a.slug} ${a.excerpt || ""}`.toLowerCase();
          if (!hay.includes(q.toLowerCase())) return false;
        }
        return true;
      })
      .sort((a, b) => new Date(b.updatedAt || b.date) - new Date(a.updatedAt || a.date));
  }, [state.articles, q, fType, fCat, fStatus]);

  const catName = (slug) =>
    (state.categories || []).find((c) => c.slug === slug)?.name || slug;

  const duplicate = (a) => {
    const copy = JSON.parse(JSON.stringify(a));
    copy.id = uid();
    copy.title = `${a.title} (cópia)`;
    copy.slug = `${a.slug}-copia-${Date.now().toString(36)}`;
    copy.status = "rascunho";
    copy.createdAt = new Date().toISOString();
    copy.updatedAt = new Date().toISOString();
    updateState((s) => {
      s.articles.push(copy);
    });
  };

  /* ---------- seleção múltipla ---------- */
  const toggleSel = (id) => setSel((prev) => {
    const n = new Set(prev);
    n.has(id) ? n.delete(id) : n.add(id);
    return n;
  });
  const visibleIds = filtered.map((a) => a.id);
  const selectedVisible = visibleIds.filter((id) => sel.has(id));
  const allSelected = visibleIds.length > 0 && selectedVisible.length === visibleIds.length;
  const toggleAll = () => setSel(allSelected ? new Set() : new Set(visibleIds));
  const bulkDraft = () => {
    const ids = selectedVisible;
    if (!ids.length) return;
    updateState((s) => {
      s.articles.forEach((a) => {
        if (ids.includes(a.id)) { a.status = "rascunho"; a.updatedAt = new Date().toISOString(); }
      });
    });
    addLog("sistema", `${ids.length} artigo(s) movidos para rascunho em massa`);
    setBulkMsg(`${ids.length} artigo(s) movido(s) para rascunho.`);
    setSel(new Set());
  };
  const bulkDelete = () => {
    const ids = selectedVisible;
    if (!ids.length) return;
    if (!window.confirm(`Excluir ${ids.length} artigo(s) selecionado(s)? Essa ação não pode ser desfeita.`)) return;
    updateState((s) => { s.articles = s.articles.filter((a) => !ids.includes(a.id)); });
    addLog("sistema", `${ids.length} artigo(s) excluídos em massa`);
    setBulkMsg(`${ids.length} artigo(s) excluído(s).`);
    setSel(new Set());
  };

  const remove = (a) => {
    if (!window.confirm(`Excluir o artigo "${a.title}"? Essa ação não pode ser desfeita.`)) return;
    updateState((s) => {
      s.articles = s.articles.filter((x) => x.id !== a.id);
    });
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-white">Artigos</h1>
          <p className="mt-1 text-sm text-slate-400">
            {filtered.length} de {(state.articles || []).length} artigo(s) — com imagem, vídeo ou áudio.
          </p>
        </div>
        <button type="button" onClick={() => navigate("/admin/artigos/novo")} className={btnPrimary}>
          + Novo artigo
        </button>
      </div>

      {/* Filtros */}
      <Card>
        <div className="grid gap-3 md:grid-cols-4">
          <input
            className={inputCls}
            placeholder="🔍 Buscar por título, slug…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            aria-label="Buscar artigos"
          />
          <select className={inputCls} value={fType} onChange={(e) => setFType(e.target.value)} aria-label="Filtrar por tipo">
            <option value="">Todos os tipos</option>
            <option value="image">🖼️ Imagem</option>
            <option value="video">🎬 Vídeo</option>
            <option value="audio">🎧 Áudio</option>
          </select>
          <select className={inputCls} value={fCat} onChange={(e) => setFCat(e.target.value)} aria-label="Filtrar por categoria">
            <option value="">Todas as categorias</option>
            {(state.categories || []).map((c) => (
              <option key={c.id} value={c.slug}>{c.icon} {c.name}</option>
            ))}
          </select>
          <select className={inputCls} value={fStatus} onChange={(e) => setFStatus(e.target.value)} aria-label="Filtrar por status">
            <option value="">Todos os status</option>
            <option value="publicado">Publicado</option>
            <option value="rascunho">Rascunho</option>
            <option value="agendado">Agendado</option>
          </select>
        </div>
      </Card>

      {/* Barra de ações em massa */}
      <div className="sticky top-16 z-10 flex flex-wrap items-center gap-3 rounded-2xl border border-slate-800 bg-slate-900/95 px-4 py-3 backdrop-blur" data-bulk-bar>
        <label className="flex cursor-pointer items-center gap-2 text-sm text-slate-300">
          <input type="checkbox" checked={allSelected} onChange={toggleAll} aria-label="Selecionar todos os artigos listados" />
          Selecionar todos ({visibleIds.length})
        </label>
        <span className="text-sm font-semibold text-amber-300" data-selected-count>{selectedVisible.length} selecionado(s)</span>
        <div className="ml-auto flex flex-wrap gap-2">
          <button type="button" className={btnGhost} disabled={!selectedVisible.length} onClick={bulkDraft}>📝 Mover para rascunho</button>
          <button type="button" className={btnDanger} disabled={!selectedVisible.length} onClick={bulkDelete}>🗑 Excluir selecionados</button>
          {selectedVisible.length > 0 && <button type="button" className={btnGhost} onClick={() => setSel(new Set())}>Limpar seleção</button>}
        </div>
        {bulkMsg && <p role="status" className="w-full text-xs text-emerald-400">{bulkMsg}</p>}
      </div>

      {/* Tabela/lista */}
      <Card>
        {filtered.length === 0 ? (
          <div className="py-10 text-center">
            <p className="text-4xl" aria-hidden="true">🗒️</p>
            <p className="mt-3 text-sm text-slate-400">Nenhum artigo encontrado com esses filtros.</p>
            <button type="button" onClick={() => navigate("/admin/artigos/novo")} className={`${btnPrimary} mt-4`}>
              + Criar primeiro artigo
            </button>
          </div>
        ) : (
          <ul className="divide-y divide-slate-800">
            {filtered.map((a) => (
              <li key={a.id} className={`flex flex-wrap items-center gap-3 py-3.5 ${sel.has(a.id) ? "bg-amber-500/5" : ""}`} data-article-row>
                <input type="checkbox" checked={sel.has(a.id)} onChange={() => toggleSel(a.id)} aria-label={`Selecionar ${a.title || "artigo"}`} className="h-4 w-4 shrink-0" />
                <span
                  className="flex h-11 w-11 shrink-0 items-center justify-center overflow-hidden rounded-lg bg-slate-800 text-xl"
                  aria-hidden="true"
                >
                  {a.cover ? <img src={a.cover} alt="" className="h-full w-full object-cover" loading="lazy" /> : TYPE_ICONS[a.type]}
                </span>
                <div className="min-w-0 flex-1 basis-52">
                  <button
                    type="button"
                    onClick={() => navigate(`/admin/artigos/editar/${a.id}`)}
                    className="block truncate text-left text-sm font-semibold text-slate-100 hover:text-amber-300"
                    title={a.title}
                  >
                    {a.title || "(sem título)"}
                  </button>
                  <p className="truncate text-xs text-slate-500">{articlePath(a, state)} · {formatDate(a.date)} · 👁 {state.views?.[a.id] || 0} · 💬 {(state.comments || []).filter((c) => c.articleId === a.id).length}</p>
                  <p className="mt-1 flex flex-wrap gap-1">
                    {(a.categories || []).map((c) => (
                      <span key={c} className="rounded bg-slate-800 px-1.5 py-0.5 text-[11px] text-slate-400">
                        {catName(c)}
                      </span>
                    ))}
                  </p>
                </div>
                <Badge tone={a.type}>{TYPE_LABELS[a.type]}</Badge>
                <Badge tone={a.status}>{STATUS_LABELS[a.status] || a.status}</Badge>
                <div className="flex gap-2">
                  <button type="button" className={btnGhost} onClick={() => navigate(`/admin/artigos/editar/${a.id}`)}>
                    Editar
                  </button>
                  <button type="button" className={btnGhost} onClick={() => duplicate(a)} title="Criar uma cópia como rascunho">
                    Duplicar
                  </button>
                  <button type="button" className={btnDanger} onClick={() => remove(a)}>
                    Excluir
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}
