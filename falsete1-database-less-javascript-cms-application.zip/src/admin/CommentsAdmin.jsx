// Painel → Comentários: moderação dos comentários enviados pelos leitores.
// Aprovar (vai para o site), reprovar (não aparece) ou excluir; filtros, busca,
// ações em massa e configurações (permitir comentários / exigir aprovação).
import { useMemo, useState } from "react";
import { Card, inputCls, btnPrimary, btnGhost, btnDanger, Badge, Toggle } from "./ui.jsx";
import { updateState } from "../store.js";
import { addLog } from "../auth.js";
import { navigate } from "../router.js";
import { articlePath } from "../permalink.js";

const FILTERS = [
  { id: "pendente", label: "⏳ Pendentes" },
  { id: "aprovado", label: "✅ Aprovados" },
  { id: "reprovado", label: "🚫 Reprovados" },
  { id: "todos", label: "Todos" },
];

const fmt = (iso) => new Date(iso).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });

export default function CommentsAdmin({ state }) {
  const cfg = state.html?.comments || { enabled: true, requireApproval: true };
  const all = state.comments || [];
  const [filter, setFilter] = useState(all.some((c) => c.status === "pendente") ? "pendente" : "todos");
  const [q, setQ] = useState("");
  const [art, setArt] = useState("");

  const count = (s) => (s === "todos" ? all.length : all.filter((c) => c.status === s).length);
  const articleOf = (id) => (state.articles || []).find((a) => a.id === id);

  const list = useMemo(() => {
    let l = [...all].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    if (filter !== "todos") l = l.filter((c) => c.status === filter);
    if (art) l = l.filter((c) => c.articleId === art);
    if (q.trim()) {
      const s = q.toLowerCase();
      l = l.filter((c) => [c.name, c.email, c.body].some((x) => String(x || "").toLowerCase().includes(s)));
    }
    return l;
  }, [all, filter, q, art]);

  const setCfg = (patch) => {
    updateState((s) => {
      s.html = s.html || {};
      s.html.comments = { ...(s.html.comments || {}), ...patch };
    });
    addLog("sistema", `Comentários: ${Object.entries(patch).map(([k, v]) => `${k}=${v}`).join(", ")}`);
  };
  const setStatus = (ids, status) => {
    updateState((s) => {
      s.comments.forEach((c) => { if (ids.includes(c.id)) c.status = status; });
    });
    addLog("sistema", `${ids.length} comentário(s) marcados como "${status}"`);
  };
  const remove = (ids) => {
    if (!window.confirm(`Excluir ${ids.length} comentário(s) definitivamente?`)) return;
    updateState((s) => { s.comments = s.comments.filter((c) => !ids.includes(c.id)); });
  };

  const pendingIds = all.filter((c) => c.status === "pendente").map((c) => c.id);
  const commented = [...new Set(all.map((c) => c.articleId))].map(articleOf).filter(Boolean);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-white">💬 Comentários</h1>
          <p className="mt-1 text-sm text-slate-400">
            Aprove ou não os comentários dos leitores. Somente os aprovados aparecem no site.
          </p>
        </div>
        {pendingIds.length > 0 && (
          <button type="button" className={btnPrimary} onClick={() => setStatus(pendingIds, "aprovado")}>
            ✅ Aprovar todos os pendentes ({pendingIds.length})
          </button>
        )}
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Toggle label="Permitir comentários" desc="Exibe o formulário (nome, e-mail e comentário) no final de cada artigo."
          checked={cfg.enabled !== false} onChange={(v) => setCfg({ enabled: v })} />
        <Toggle label="Exigir aprovação antes de publicar" desc="Novos comentários ficam pendentes até você aprovar aqui (recomendado)."
          checked={cfg.requireApproval !== false} onChange={(v) => setCfg({ requireApproval: v })} />
      </div>

      <Card>
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex flex-wrap gap-1.5" role="tablist" aria-label="Filtrar comentários">
            {FILTERS.map((f) => (
              <button key={f.id} type="button" role="tab" aria-selected={filter === f.id} onClick={() => setFilter(f.id)}
                className={`rounded-lg px-3 py-1.5 text-xs font-semibold ${filter === f.id ? "bg-amber-500 text-slate-950" : "border border-slate-700 text-slate-300 hover:bg-slate-800"}`}>
                {f.label} ({count(f.id)})
              </button>
            ))}
          </div>
          <select className={`${inputCls} w-auto`} value={art} onChange={(e) => setArt(e.target.value)} aria-label="Filtrar por artigo">
            <option value="">Todos os artigos</option>
            {commented.map((a) => <option key={a.id} value={a.id}>{a.title}</option>)}
          </select>
          <input className={`${inputCls} ml-auto max-w-xs`} placeholder="🔍 Buscar nome, e-mail ou texto…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Buscar comentários" />
        </div>
      </Card>

      <Card title={`${list.length} comentário(s)`}>
        {list.length === 0 ? (
          <p className="py-8 text-center text-sm text-slate-400">Nenhum comentário neste filtro.</p>
        ) : (
          <ul className="divide-y divide-slate-800">
            {list.map((c) => {
              const a = articleOf(c.articleId);
              return (
                <li key={c.id} className="flex flex-wrap items-start gap-3 py-4" data-comment-row={c.status}>
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-amber-500/15 font-bold text-amber-300" aria-hidden="true">
                    {(c.name || "?")[0].toUpperCase()}
                  </span>
                  <div className="min-w-0 flex-1 basis-64">
                    <p className="text-sm">
                      <strong className="text-slate-100">{c.name}</strong>{" "}
                      {c.email ? <a href={`mailto:${c.email}`} className="text-xs text-indigo-300 hover:underline">{c.email}</a> : <span className="text-xs text-slate-500">(sem e-mail)</span>}
                    </p>
                    <p className="mt-1 whitespace-pre-wrap text-sm text-slate-300">{c.body}</p>
                    <p className="mt-1 text-xs text-slate-500">
                      {fmt(c.createdAt)} · em{" "}
                      {a ? <button type="button" className="text-amber-400 hover:underline" onClick={() => navigate(articlePath(a, state))}>{a.title}</button> : "artigo removido"}
                    </p>
                  </div>
                  <Badge tone={c.status === "aprovado" ? "publicado" : c.status === "pendente" ? "agendado" : "falha"}>{c.status}</Badge>
                  <div className="flex flex-wrap gap-2">
                    {c.status !== "aprovado" && <button type="button" className={btnGhost} onClick={() => setStatus([c.id], "aprovado")}>✅ Aprovar</button>}
                    {c.status !== "reprovado" && <button type="button" className={btnGhost} onClick={() => setStatus([c.id], "reprovado")}>🚫 Reprovar</button>}
                    <button type="button" className={btnDanger} onClick={() => remove([c.id])}>Excluir</button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </Card>
    </div>
  );
}
