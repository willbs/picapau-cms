// Painel → Marca: altera o título do site, a logo (URL ou upload) e a favicon
// (URL ou upload de imagem). Aplica imediatamente no documento (título da aba + ícone).
import { useState } from "react";
import { Card, inputCls, labelCls, btnPrimary } from "./ui.jsx";
import UploadField from "../components/UploadField.jsx";
import { updateState } from "../store.js";
import { addLog } from "../auth.js";
import { applySeo } from "../seo.js";

export default function BrandingAdmin({ state }) {
  const [form, setForm] = useState(() => ({
    siteName: state.branding?.siteName || state.seo.ogSiteName || state.seo.title || "Pica-Pau",
    logo: state.branding?.logo || "",
    favicon: state.branding?.favicon || state.seo.favicon || "/favicon.svg",
  }));
  const [saved, setSaved] = useState(false);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const save = () => {
    updateState((s) => {
      s.branding = { ...form };
      // O título do site também vira título SEO padrão e og:site_name
      s.seo.title = form.siteName || s.seo.title;
      s.seo.ogSiteName = form.siteName || s.seo.ogSiteName;
      s.seo.favicon = form.favicon || "/favicon.svg";
    });
    const fresh = updateState((s) => s); // estado atualizado
    applySeo(fresh.seo, { path: "/" }, false);
    addLog("sistema", `Marca atualizada: site="${form.siteName}", logo=${form.logo ? "alterada" : "(padrão)"}, favicon=${form.favicon ? "alterada" : "(padrão)"}`);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const logoPreview = form.logo || form.favicon || "/favicon.svg";

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-white">🎨 Marca do site</h1>
          <p className="mt-1 text-sm text-slate-400">
            Título do site, logo e favicon — por URL ou upload de imagem — aplicados na hora em todo o site.
          </p>
        </div>
        <button type="button" className={btnPrimary} onClick={save}>
          {saved ? "✓ Salvo!" : "Salvar marca"}
        </button>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card title="Identidade" subtitle="Campos aplicados ao salvar.">
          <div className="space-y-4">
            <div>
              <label htmlFor="b-name" className={labelCls}>Título do site</label>
              <input id="b-name" className={inputCls} value={form.siteName} onChange={(e) => set("siteName", e.target.value)}
                placeholder="Nome exibido no cabeçalho, rodapé e título da aba" />
              <p className="mt-1 text-xs text-slate-500">Também atualiza o título SEO padrão (og:site_name e &lt;title&gt;).</p>
            </div>
            <div>
              <label htmlFor="b-logo" className={labelCls}>Logo — URL ou upload</label>
              <div className="flex flex-wrap items-center gap-2">
                <input id="b-logo" className={`${inputCls} min-w-0 flex-1`} value={form.logo} onChange={(e) => set("logo", e.target.value)}
                  placeholder="https://…/logo.png — vazio usa a favicon" />
                <UploadField kind="image" label="Upload logo" onUploaded={(d) => set("logo", d)} />
                {form.logo && (
                  <button type="button" onClick={() => set("logo", "")} title="Remover logo"
                    className="rounded-lg border border-rose-500/40 px-2 py-2 text-xs text-rose-300 hover:bg-rose-500/10">🗑</button>
                )}
              </div>
              {form.logo && (
                <img src={form.logo} alt="Prévia da logo" className="mt-2 h-16 rounded-lg border border-slate-700 bg-slate-950 object-contain p-1" />
              )}
            </div>
            <div>
              <label htmlFor="b-fav" className={labelCls}>Favicon — URL ou upload de imagem</label>
              <div className="flex flex-wrap items-center gap-2">
                <input id="b-fav" className={`${inputCls} min-w-0 flex-1`} value={form.favicon} onChange={(e) => set("favicon", e.target.value)}
                  placeholder="/favicon.svg" />
                <UploadField kind="image" label="Upload favicon" maxDim={64} onUploaded={(d) => set("favicon", d)} />
                {form.favicon && (
                  <button type="button" onClick={() => set("favicon", "/favicon.svg")} title="Restaurar padrão"
                    className="rounded-lg border border-rose-500/40 px-2 py-2 text-xs text-rose-300 hover:bg-rose-500/10">🗑</button>
                )}
              </div>
              <p className="mt-1 text-xs text-slate-500">
                Aplicada imediatamente como ícone da aba (link rel="icon"). Upload de imagem é redimensionado para 64px.
              </p>
              {form.favicon && (
                <img src={form.favicon} alt="Prévia da favicon" className="mt-2 h-10 w-10 rounded border border-slate-700 bg-slate-950 object-contain p-0.5" />
              )}
            </div>
          </div>
        </Card>

        <Card title="Prévia" subtitle="Como aparece no cabeçalho do site público.">
          <div className="overflow-hidden rounded-xl border border-slate-700">
            <div className="flex items-center gap-2.5 border-b border-slate-200 bg-white px-4 py-3 dark:border-slate-800 dark:bg-slate-900">
              <img src={logoPreview} alt="logo" className="h-9 w-9 rounded-lg object-cover shadow"
                onError={(e) => { e.currentTarget.style.display = "none"; }} />
              <span className="text-lg font-extrabold tracking-tight text-slate-900 dark:text-white">
                {form.siteName || "Nome do site"}
              </span>
              <span className="ml-auto rounded-lg px-2.5 py-1 text-xs font-medium text-slate-500 dark:text-slate-400">menu…</span>
            </div>
            <div className="bg-slate-50 p-4 dark:bg-slate-950">
              <div className="h-24 rounded-lg bg-gradient-to-br from-amber-100 to-orange-50 dark:from-slate-800 dark:to-slate-900" />
              <p className="mt-3 text-xs text-slate-400">Conteúdo da página…</p>
            </div>
            <div className="flex items-center gap-2 border-t border-slate-800 bg-slate-950 px-4 py-3">
              <img src={logoPreview} alt="logo" className="h-7 w-7 rounded" onError={(e) => { e.currentTarget.style.display = "none"; }} />
              <span className="text-sm font-extrabold text-white">{form.siteName || "Nome do site"}</span>
              <span className="ml-auto text-[11px] text-slate-500">rodapé</span>
            </div>
          </div>
          <div className="mt-4 flex items-center gap-3 rounded-xl border border-slate-800 bg-slate-900/60 p-3">
            <img src={form.favicon || "/favicon.svg"} alt="favicon" className="h-8 w-8 rounded" onError={(e) => { e.currentTarget.style.display = "none"; }} />
            <div className="min-w-0">
              <p className="truncate text-sm font-semibold text-slate-200">{form.siteName || "Nome do site"}</p>
              <p className="truncate text-xs text-slate-500">aba do navegador — favicon: {String(form.favicon || "/favicon.svg").slice(0, 40)}…</p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
