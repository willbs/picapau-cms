// Painel → Loja Virtual:
// - botão habilitar/desabilitar a sessão Loja
// - escolha entre 5 layouts de página de produtos
// - produtos próprios (carrinho) e produtos de AFILIADO (botão "Comprar" redireciona p/ outro site)
// - pedidos
import { useState } from "react";
import { Card, inputCls, labelCls, btnPrimary, btnGhost, btnDanger, Badge, Toggle } from "./ui.jsx";
import Modal from "../components/Modal.jsx";
import UploadField from "../components/UploadField.jsx";
import { updateState } from "../store.js";
import { addLog } from "../auth.js";
import { uid, slugify, formatDate } from "../utils.js";
import { navigate } from "../router.js";
import { brl, LOJA_TEMPLATES } from "../pages/Loja.jsx";

function blankProduct(kind = "proprio") {
  return {
    id: uid(),
    kind,
    name: "",
    slug: "",
    price: "",
    oldPrice: "",
    description: "",
    image: "",
    category: kind === "afiliado" ? "Afiliados" : "",
    stock: "",
    active: true,
    affiliateUrl: "",
    affiliateStore: "",
    createdAt: new Date().toISOString(),
  };
}

const ORDER_STATUS = ["novo", "em separação", "enviado", "entregue", "cancelado"];

/** Miniatura esquemática de cada layout de loja. */
function LayoutThumb({ id }) {
  const b = "rounded-sm bg-amber-400/80";
  const l = "h-1 rounded bg-slate-500";
  const box = "flex h-16 w-full gap-1 rounded-md border border-slate-700 bg-slate-800/60 p-1.5";
  if (id === "grade")
    return <div className={`${box} grid grid-cols-4`}>{[0, 1, 2, 3].map((i) => <div key={i} className={`${b} h-full`} />)}</div>;
  if (id === "lista")
    return <div className={`${box} flex-col`}>{[0, 1, 2].map((i) => <div key={i} className="flex flex-1 gap-1"><div className={`${b} w-4`} /><div className={`${l} mt-1 flex-1`} /></div>)}</div>;
  if (id === "vitrine")
    return <div className={`${box} flex-col`}><div className={`${b} h-1/2 w-full`} /><div className="grid flex-1 grid-cols-3 gap-1">{[0, 1, 2].map((i) => <div key={i} className={`${b} opacity-60`} />)}</div></div>;
  if (id === "minimal")
    return <div className={`${box} grid grid-cols-2 gap-2 px-3`}>{[0, 1].map((i) => <div key={i} className="flex flex-col items-center gap-1"><div className={`${b} h-9 w-full`} /><div className={`${l} w-2/3`} /></div>)}</div>;
  return <div className={`${box} flex-col`}><div className="flex flex-1 gap-1"><div className={`${b} w-1/2`} /><div className={`${l} mt-2 flex-1`} /></div><div className="flex flex-1 gap-1"><div className={`${l} mt-2 flex-1`} /><div className={`${b} w-1/2`} /></div></div>;
}

export default function LojaAdmin({ state }) {
  const loja = state.loja || { products: [], orders: [], template: "grade" };
  const enabled = state.features?.loja !== false;
  const [editing, setEditing] = useState(null);
  const [slugTouched, setSlugTouched] = useState(false);
  const [error, setError] = useState("");

  const openNew = (kind) => {
    setEditing(blankProduct(kind));
    setSlugTouched(false);
    setError("");
  };
  const openEdit = (p) => {
    setEditing({ kind: "proprio", oldPrice: "", affiliateUrl: "", affiliateStore: "", ...JSON.parse(JSON.stringify(p)) });
    setSlugTouched(true);
    setError("");
  };

  const toggleLoja = (on) => {
    updateState((s) => {
      s.features.loja = on;
    });
    addLog("sistema", `Sessão Loja ${on ? "HABILITADA" : "DESABILITADA"}`);
  };

  const setTemplate = (id) => {
    updateState((s) => {
      s.loja.template = id;
    });
    addLog("sistema", `Layout da página de produtos alterado para "${id}"`);
  };

  const save = () => {
    const p = { ...editing };
    if (!p.name.trim()) return setError("O nome do produto é obrigatório.");
    const price = Number(String(p.price).replace(",", "."));
    if (Number.isNaN(price) || price < 0) return setError("Informe um preço válido.");
    p.price = price;
    const oldPrice = Number(String(p.oldPrice || "").replace(",", "."));
    p.oldPrice = oldPrice > 0 ? oldPrice : null;
    if (p.kind === "afiliado") {
      if (!/^https?:\/\/.+/i.test((p.affiliateUrl || "").trim())) {
        return setError("Informe o link de afiliado completo (começando com https://).");
      }
      p.affiliateUrl = p.affiliateUrl.trim();
      p.stock = null;
    } else {
      p.stock = p.stock === "" || p.stock === null ? null : Math.max(0, Number(p.stock) || 0);
    }
    p.slug = (p.slug || slugify(p.name)).trim() || slugify(p.name);
    const dup = loja.products.find((x) => x.slug === p.slug && x.id !== p.id);
    if (dup) return setError(`Já existe um produto com o slug "${p.slug}".`);
    updateState((s) => {
      const i = s.loja.products.findIndex((x) => x.id === p.id);
      if (i >= 0) s.loja.products[i] = p;
      else s.loja.products.push(p);
    });
    addLog("sistema", `Produto ${p.kind === "afiliado" ? "de afiliado " : ""}salvo: ${p.name}`);
    setEditing(null);
  };

  const remove = (p) => {
    if (!window.confirm(`Excluir o produto "${p.name}"?`)) return;
    updateState((s) => {
      s.loja.products = s.loja.products.filter((x) => x.id !== p.id);
    });
  };
  const removeOrder = (o) => {
    if (!window.confirm("Excluir este pedido?")) return;
    updateState((s) => {
      s.loja.orders = s.loja.orders.filter((x) => x.id !== o.id);
    });
  };
  const setOrderStatus = (o, status) => {
    updateState((s) => {
      const order = s.loja.orders.find((x) => x.id === o.id);
      if (order) order.status = status;
    });
  };

  const affiliates = loja.products.filter((p) => p.kind === "afiliado");

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-white">🛒 Loja Virtual</h1>
          <p className="mt-1 text-sm text-slate-400">
            Produtos próprios, produtos de afiliados, layouts e pedidos — página pública{" "}
            <code className="rounded bg-slate-800 px-1.5 py-0.5 text-amber-300">/loja</code>.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button type="button" className={btnGhost} onClick={() => navigate("/loja")}>🌐 Ver loja</button>
          <button type="button" className={btnGhost} onClick={() => openNew("afiliado")}>🔗 + Produto de afiliado</button>
          <button type="button" className={btnPrimary} onClick={() => openNew("proprio")}>+ Novo produto</button>
        </div>
      </div>

      {/* Habilitar / desabilitar a sessão Loja */}
      <Card title="Sessão Loja">
        <Toggle
          label={enabled ? "Loja HABILITADA" : "Loja DESABILITADA"}
          desc={enabled
            ? "A página /loja está no ar e o link aparece no menu do site."
            : "A página /loja retorna 404 e o link sai do menu (produtos e pedidos continuam salvos)."}
          checked={enabled}
          onChange={toggleLoja}
        />
      </Card>

      {/* 5 layouts da página de produtos */}
      <Card title="Layout da página de produtos" subtitle="Escolha entre 5 páginas diferentes — aplicado na hora em /loja.">
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5" role="radiogroup" aria-label="Layout da loja">
          {LOJA_TEMPLATES.map((t) => {
            const active = (loja.template || "grade") === t.id;
            return (
              <button
                key={t.id}
                type="button"
                role="radio"
                aria-checked={active}
                onClick={() => setTemplate(t.id)}
                className={`rounded-xl border p-3 text-left transition ${active ? "border-amber-500 bg-amber-500/10 ring-2 ring-amber-500/30" : "border-slate-700 bg-slate-800/50 hover:border-slate-500"}`}
              >
                <LayoutThumb id={t.id} />
                <p className="mt-2 text-sm font-bold text-slate-100">{t.icon} {t.name}</p>
                <p className="mt-0.5 text-xs text-slate-400">{t.desc}</p>
              </button>
            );
          })}
        </div>
      </Card>

      {/* Afiliados */}
      <Card
        title={`🔗 Produtos de afiliados (${affiliates.length})`}
        subtitle="O visitante clica em “Comprar” e é redirecionado para o site parceiro (link abre em nova aba)."
        actions={<button type="button" className={btnPrimary} onClick={() => openNew("afiliado")}>+ Adicionar produto de afiliado</button>}
      >
        {affiliates.length === 0 ? (
          <p className="py-3 text-sm text-slate-400">Nenhum produto de afiliado ainda.</p>
        ) : (
          <ul className="divide-y divide-slate-800">
            {affiliates.map((p) => (
              <li key={p.id} className="flex flex-wrap items-center gap-3 py-3">
                <span className="flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-lg bg-slate-800">
                  {p.image ? <img src={p.image} alt="" className="h-full w-full object-cover" /> : "🔗"}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold text-slate-100">{p.name}</p>
                  <a href={p.affiliateUrl} target="_blank" rel="noopener noreferrer" className="block truncate text-xs text-emerald-400 hover:underline">
                    {p.affiliateStore ? `${p.affiliateStore} — ` : ""}{p.affiliateUrl} ↗
                  </a>
                </div>
                <button type="button" className={btnGhost} onClick={() => openEdit(p)}>Editar</button>
              </li>
            ))}
          </ul>
        )}
      </Card>

      {/* Todos os produtos */}
      <Card title={`Produtos (${loja.products.length})`}>
        {loja.products.length === 0 ? (
          <p className="py-6 text-center text-sm text-slate-400">Nenhum produto.</p>
        ) : (
          <ul className="divide-y divide-slate-800">
            {loja.products.map((p) => (
              <li key={p.id} className="flex flex-wrap items-center gap-3 py-3.5">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center overflow-hidden rounded-lg bg-slate-800 text-2xl" aria-hidden="true">
                  {p.image ? <img src={p.image} alt="" className="h-full w-full object-cover" loading="lazy" /> : "📦"}
                </span>
                <div className="min-w-0 flex-1 basis-52">
                  <p className="truncate text-sm font-semibold text-slate-100">{p.name}</p>
                  <p className="text-xs text-slate-500">
                    {brl(p.price)} · {p.kind === "afiliado" ? `afiliado (${p.affiliateStore || "site parceiro"})` : `estoque ${p.stock ?? "—"}`} · {p.category || "sem categoria"}
                  </p>
                </div>
                <Badge tone={p.kind === "afiliado" ? "audio" : "video"}>{p.kind === "afiliado" ? "🔗 afiliado" : "📦 próprio"}</Badge>
                <Badge tone={p.active ? "publicado" : "rascunho"}>{p.active ? "ativo" : "inativo"}</Badge>
                <div className="flex gap-2">
                  <button type="button" className={btnGhost} onClick={() => openEdit(p)}>Editar</button>
                  <button type="button" className={btnDanger} onClick={() => remove(p)}>Excluir</button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </Card>

      {/* Pedidos */}
      <Card title={`Pedidos (${loja.orders.length})`} subtitle="Pedidos de produtos próprios finalizados em /loja.">
        {loja.orders.length === 0 ? (
          <p className="py-6 text-center text-sm text-slate-400">Nenhum pedido ainda.</p>
        ) : (
          <ul className="divide-y divide-slate-800">
            {loja.orders.map((o) => (
              <li key={o.id} className="flex flex-wrap items-center gap-3 py-3.5">
                <div className="min-w-0 flex-1 basis-64">
                  <p className="text-sm font-semibold text-slate-100">{o.items.map((i) => `${i.qty}× ${i.name}`).join(", ")}</p>
                  <p className="text-xs text-slate-500">{o.customer?.name} · {o.customer?.email} · {formatDate(o.createdAt)}</p>
                </div>
                <span className="text-sm font-extrabold text-amber-400">{brl(o.total)}</span>
                <select className={`${inputCls} w-auto`} value={o.status} onChange={(e) => setOrderStatus(o, e.target.value)} aria-label="Status do pedido">
                  {ORDER_STATUS.map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
                <button type="button" className={btnDanger} onClick={() => removeOrder(o)}>Excluir</button>
              </li>
            ))}
          </ul>
        )}
      </Card>

      {/* Modal de produto */}
      <Modal
        open={!!editing}
        onClose={() => setEditing(null)}
        title={editing?.kind === "afiliado" ? "🔗 Produto de afiliado" : editing?.name ? "Editar produto" : "Novo produto"}
      >
        {editing && (
          <div className="space-y-4">
            {error && <p role="alert" className="rounded-lg border border-rose-500/40 bg-rose-500/10 px-3 py-2 text-sm text-rose-300">{error}</p>}
            <div>
              <span className={labelCls}>Tipo de produto</span>
              <div className="flex gap-2" role="radiogroup" aria-label="Tipo de produto">
                {[
                  { id: "proprio", label: "📦 Próprio (carrinho)" },
                  { id: "afiliado", label: "🔗 Afiliado (redireciona)" },
                ].map((k) => (
                  <button
                    key={k.id}
                    type="button"
                    role="radio"
                    aria-checked={editing.kind === k.id}
                    onClick={() => setEditing((p) => ({ ...p, kind: k.id }))}
                    className={`rounded-lg border px-3 py-2 text-sm font-semibold ${editing.kind === k.id ? "border-amber-500 bg-amber-500/15 text-amber-300" : "border-slate-700 text-slate-400"}`}
                  >
                    {k.label}
                  </button>
                ))}
              </div>
            </div>
            {editing.kind === "afiliado" && (
              <div className="grid gap-4 rounded-xl border border-emerald-500/30 bg-emerald-500/5 p-3 sm:grid-cols-2">
                <div className="sm:col-span-2">
                  <label htmlFor="lp-aff" className={labelCls}>Link de afiliado * (para onde o “Comprar” redireciona)</label>
                  <input id="lp-aff" className={inputCls} value={editing.affiliateUrl} placeholder="https://www.loja-parceira.com/produto?tag=seu-id"
                    onChange={(e) => setEditing((p) => ({ ...p, affiliateUrl: e.target.value }))} />
                </div>
                <div>
                  <label htmlFor="lp-store" className={labelCls}>Loja parceira</label>
                  <input id="lp-store" className={inputCls} value={editing.affiliateStore} placeholder="Amazon, Shopee, Mercado Livre…"
                    onChange={(e) => setEditing((p) => ({ ...p, affiliateStore: e.target.value }))} />
                </div>
                <p className="self-end text-xs text-emerald-300/80">O link abre em nova aba com rel="sponsored nofollow".</p>
              </div>
            )}
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="lp-name" className={labelCls}>Nome *</label>
                <input id="lp-name" className={inputCls} value={editing.name}
                  onChange={(e) => setEditing((p) => ({ ...p, name: e.target.value, slug: slugTouched ? p.slug : slugify(e.target.value) }))} />
              </div>
              <div>
                <label htmlFor="lp-slug" className={labelCls}>Slug</label>
                <input id="lp-slug" className={inputCls} value={editing.slug}
                  onChange={(e) => { setSlugTouched(true); setEditing((p) => ({ ...p, slug: slugify(e.target.value) })); }} />
              </div>
              <div>
                <label htmlFor="lp-price" className={labelCls}>Preço (R$) *</label>
                <input id="lp-price" className={inputCls} value={editing.price} inputMode="decimal" placeholder="79,90"
                  onChange={(e) => setEditing((p) => ({ ...p, price: e.target.value }))} />
              </div>
              <div>
                <label htmlFor="lp-old" className={labelCls}>Preço antigo (opcional, “de/por”)</label>
                <input id="lp-old" className={inputCls} value={editing.oldPrice ?? ""} inputMode="decimal" placeholder="99,90"
                  onChange={(e) => setEditing((p) => ({ ...p, oldPrice: e.target.value }))} />
              </div>
              {editing.kind !== "afiliado" && (
                <div>
                  <label htmlFor="lp-stock" className={labelCls}>Estoque</label>
                  <input id="lp-stock" className={inputCls} value={editing.stock ?? ""} inputMode="numeric" placeholder="10 (vazio = ilimitado)"
                    onChange={(e) => setEditing((p) => ({ ...p, stock: e.target.value }))} />
                </div>
              )}
              <div>
                <label htmlFor="lp-cat" className={labelCls}>Categoria</label>
                <input id="lp-cat" className={inputCls} value={editing.category} placeholder="Camisetas"
                  onChange={(e) => setEditing((p) => ({ ...p, category: e.target.value }))} />
              </div>
              <div className="flex items-end">
                <label className="flex cursor-pointer items-center gap-2 text-sm text-slate-300">
                  <input type="checkbox" checked={!!editing.active} onChange={(e) => setEditing((p) => ({ ...p, active: e.target.checked }))} />
                  produto ativo (visível em /loja)
                </label>
              </div>
            </div>
            <div>
              <label htmlFor="lp-desc" className={labelCls}>Descrição</label>
              <textarea id="lp-desc" className={inputCls} rows={3} value={editing.description}
                onChange={(e) => setEditing((p) => ({ ...p, description: e.target.value }))} />
            </div>
            <div>
              <label htmlFor="lp-img" className={labelCls}>Imagem do produto — URL ou upload</label>
              <div className="flex flex-wrap items-center gap-2">
                <input id="lp-img" className={`${inputCls} min-w-0 flex-1`} value={editing.image} placeholder="https://…/produto.jpg"
                  onChange={(e) => setEditing((p) => ({ ...p, image: e.target.value }))} />
                <UploadField kind="image" label="Upload imagem" onUploaded={(d) => setEditing((p) => ({ ...p, image: d }))} />
              </div>
              {editing.image && <img src={editing.image} alt="Prévia do produto" className="mt-2 h-28 rounded-lg border border-slate-700 object-cover" />}
            </div>
            <div className="flex justify-end gap-2">
              <button type="button" className={btnGhost} onClick={() => setEditing(null)}>Cancelar</button>
              <button type="button" className={btnPrimary} onClick={save}>Salvar produto</button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
