// Campos extras da sessão Segurança: Backup (local + Google Drive, manual + automático)
// e Políticas de privacidade (link + janela de aceite ao entrar no site).
import { useEffect, useRef, useState } from "react";
import { Card, inputCls, labelCls, btnPrimary, btnGhost, btnDanger, Badge, Toggle } from "./ui.jsx";
import { updateState } from "../store.js";
import { addLog, getCurrentUser, updateUser, destroySession } from "../auth.js";
import { navigate } from "../router.js";
import {
  FREQUENCIES, backupConfig, buildBackup, downloadBackup, restoreBackup, sizeOf,
  listSnapshots, saveSnapshot, deleteSnapshot, getSnapshot,
  driveToken, driveUpload, driveConnected, driveDisconnect, logBackup, runScheduledBackup, nextRunAt,
} from "../backup.js";
import { formatBytes } from "../upload.js";
import { smtpConfig, sendMail, relayHealth, testEmail } from "../mailer.js";

const fmt = (d) => (d ? new Date(d).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" }) : "—");

/* ================================ BACKUP ================================ */

export function BackupCard({ state }) {
  const cfg = backupConfig(state);
  const [snaps, setSnaps] = useState([]);
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState("");
  const [clientId, setClientId] = useState(cfg.drive.clientId);
  const [connected, setConnected] = useState(driveConnected());
  const fileRef = useRef(null);

  const refresh = () => listSnapshots().then(setSnaps).catch(() => setSnaps([]));
  useEffect(() => { refresh(); }, [state.backup?.history?.length]);

  const setAuto = (patch) => updateState((s) => { s.backup = backupConfig(s); s.backup.auto = { ...s.backup.auto, ...patch }; });
  const ok = (text) => setMsg({ type: "ok", text });
  const err = (text) => setMsg({ type: "err", text });

  const doDownload = () => {
    const b = buildBackup();
    downloadBackup(b);
    logBackup({ type: "manual", target: "arquivo", ok: true, size: sizeOf(b) });
    ok(`Backup baixado (${formatBytes(sizeOf(b))}).`);
  };
  const doLocal = async () => {
    try {
      const b = buildBackup();
      await saveSnapshot(b, "manual", cfg.auto.keep);
      logBackup({ type: "manual", target: "local", ok: true, size: sizeOf(b) });
      ok("Cópia salva no navegador.");
      refresh();
    } catch (e) { err(`Falha ao salvar cópia local: ${e.message}`); }
  };
  const saveClientId = () => updateState((s) => { s.backup = backupConfig(s); s.backup.drive.clientId = clientId.trim(); });
  const doDrive = async () => {
    setBusy("drive");
    saveClientId(); // o backup automático usa o mesmo Client ID
    try {
      const f = await driveUpload(clientId.trim(), buildBackup(), true);
      setConnected(true);
      logBackup({ type: "manual", target: "drive", ok: true, file: f.name });
      ok(`Backup enviado ao Google Drive: ${f.name}`);
    } catch (e) {
      logBackup({ type: "manual", target: "drive", ok: false, error: e.message });
      err(e.message);
    }
    setBusy("");
  };
  const connect = async () => {
    setBusy("connect");
    try {
      saveClientId();
      await driveToken(clientId.trim(), true);
      setConnected(true);
      ok("Google Drive conectado.");
    } catch (e) { err(e.message); }
    setBusy("");
  };
  const restoreFrom = (obj, label) => {
    if (!window.confirm(`Restaurar o backup ${label}? Os dados atuais do site serão substituídos.`)) return;
    try {
      restoreBackup(obj);
      addLog("seguranca", `Backup restaurado (${label})`);
      ok("Backup restaurado com sucesso.");
    } catch (e) { err(e.message); }
  };
  const onFile = (e) => {
    const f = e.target.files?.[0];
    e.target.value = "";
    if (!f) return;
    const r = new FileReader();
    r.onload = () => {
      try { restoreFrom(JSON.parse(r.result), `do arquivo ${f.name}`); } catch { err("Arquivo inválido (JSON corrompido)."); }
    };
    r.readAsText(f);
  };
  const runNow = async () => {
    setBusy("auto");
    const res = await runScheduledBackup({ force: true });
    setBusy("");
    refresh();
    ok(`Backup automático executado agora${res?.length ? "" : " (nenhum destino marcado)"}.`);
  };

  const next = nextRunAt(state);

  return (
    <Card title="💾 Backup" subtitle="Backup completo do site (conteúdo, configurações, usuários, comentários e mídias enviadas).">
      {msg && (
        <p role="status" className={`mb-4 rounded-xl border px-4 py-2.5 text-sm ${msg.type === "ok" ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-300" : "border-rose-500/40 bg-rose-500/10 text-rose-300"}`}>
          {msg.text}
        </p>
      )}

      {/* Manual */}
      <h3 className="mb-2 text-sm font-bold text-slate-200">Backup manual</h3>
      <div className="flex flex-wrap gap-2">
        <button type="button" className={btnPrimary} onClick={doDownload}>⬇ Baixar backup (.json)</button>
        <button type="button" className={btnGhost} onClick={doLocal}>💾 Salvar cópia no navegador</button>
        <button type="button" className={btnGhost} onClick={doDrive} disabled={busy === "drive"}>{busy === "drive" ? "Enviando…" : "☁️ Enviar para o Google Drive"}</button>
        <button type="button" className={btnGhost} onClick={() => fileRef.current?.click()}>⬆ Restaurar de arquivo</button>
        <input ref={fileRef} type="file" accept="application/json,.json" className="hidden" onChange={onFile} aria-label="Arquivo de backup para restaurar" />
      </div>

      {/* Automático */}
      <h3 className="mb-2 mt-6 text-sm font-bold text-slate-200">Backup automático (pré-programado)</h3>
      <div className="grid gap-3 md:grid-cols-2">
        <Toggle label={cfg.auto.enabled ? "Backup automático LIGADO" : "Backup automático DESLIGADO"}
          desc="Executa na frequência escolhida enquanto o painel estiver aberto em algum momento (sem servidor, o navegador é quem executa)."
          checked={!!cfg.auto.enabled} onChange={(v) => { setAuto({ enabled: v }); addLog("seguranca", `Backup automático ${v ? "ligado" : "desligado"}`); }} />
        <div className="space-y-3 rounded-xl border border-slate-800 bg-slate-900/60 p-4">
          <div>
            <label htmlFor="bk-freq" className={labelCls}>Frequência</label>
            <select id="bk-freq" className={inputCls} value={cfg.auto.frequency} onChange={(e) => setAuto({ frequency: e.target.value })}>
              {FREQUENCIES.map((f) => <option key={f.id} value={f.id}>{f.label}</option>)}
            </select>
          </div>
          <div className="flex flex-wrap gap-4 text-sm text-slate-300">
            <label className="flex items-center gap-2"><input type="checkbox" checked={!!cfg.auto.local} onChange={(e) => setAuto({ local: e.target.checked })} aria-label="Destino: cópia local" /> Cópia local (navegador)</label>
            <label className="flex items-center gap-2"><input type="checkbox" checked={!!cfg.auto.drive} onChange={(e) => setAuto({ drive: e.target.checked })} aria-label="Destino: Google Drive" /> Google Drive</label>
          </div>
          <div>
            <label htmlFor="bk-keep" className={labelCls}>Manter cópias locais</label>
            <select id="bk-keep" className={inputCls} value={cfg.auto.keep} onChange={(e) => setAuto({ keep: Number(e.target.value) })}>
              {[3, 5, 10, 20, 30].map((n) => <option key={n} value={n}>últimas {n}</option>)}
            </select>
          </div>
          <p className="text-xs text-slate-400">
            Último automático: {fmt(cfg.lastAuto)} · Próximo: {next ? fmt(next) : "—"}
          </p>
          <button type="button" className={btnGhost} onClick={runNow} disabled={busy === "auto"}>▶ Executar backup automático agora</button>
        </div>
      </div>

      {/* Google Drive */}
      <h3 className="mb-2 mt-6 text-sm font-bold text-slate-200">Google Drive</h3>
      <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
        <label htmlFor="bk-client" className={labelCls}>Client ID OAuth do Google</label>
        <div className="flex flex-wrap gap-2">
          <input id="bk-client" className={`${inputCls} min-w-0 flex-1`} value={clientId} onChange={(e) => setClientId(e.target.value)} onBlur={saveClientId}
            placeholder="123456789-abc.apps.googleusercontent.com" />
          <button type="button" className={btnPrimary} onClick={connect} disabled={busy === "connect"}>{connected ? "✓ Conectado" : busy === "connect" ? "Conectando…" : "Conectar Google Drive"}</button>
          {connected && <button type="button" className={btnDanger} onClick={() => { driveDisconnect(); setConnected(false); }}>Desconectar</button>}
        </div>
        <details className="mt-3 text-xs text-slate-400">
          <summary className="cursor-pointer text-slate-300">Como obter o Client ID (5 minutos)</summary>
          <ol className="ml-4 mt-2 list-decimal space-y-1">
            <li>Acesse console.cloud.google.com e crie (ou escolha) um projeto.</li>
            <li>Em “APIs e serviços → Biblioteca”, ative a <strong>Google Drive API</strong>.</li>
            <li>Configure a “Tela de consentimento OAuth” (tipo Externo) e adicione seu e-mail como usuário de teste.</li>
            <li>Em “Credenciais → Criar credenciais → ID do cliente OAuth”, escolha <strong>Aplicativo da Web</strong> e adicione a URL do seu site em “Origens JavaScript autorizadas”.</li>
            <li>Copie o Client ID e cole aqui. O site só acessa os arquivos que ele mesmo cria (escopo drive.file).</li>
          </ol>
          <p className="mt-2">O acesso do Google dura cerca de 1 hora; no backup automático o site tenta renovar sem abrir janela. Se não conseguir, o histórico mostra “reconecte” e basta clicar em Conectar.</p>
        </details>
      </div>

      {/* Cópias locais */}
      <h3 className="mb-2 mt-6 text-sm font-bold text-slate-200">Cópias guardadas no navegador ({snaps.length})</h3>
      {snaps.length === 0 ? (
        <p className="text-sm text-slate-500">Nenhuma cópia local ainda.</p>
      ) : (
        <ul className="divide-y divide-slate-800" data-snapshots>
          {snaps.map((s) => (
            <li key={s.id} className="flex flex-wrap items-center gap-3 py-2.5 text-sm">
              <span className="min-w-0 flex-1 text-slate-200">{fmt(s.createdAt)} <span className="text-xs text-slate-500">· {formatBytes(s.size)}</span></span>
              <Badge tone={s.origin === "automático" ? "video" : "agendado"}>{s.origin}</Badge>
              <button type="button" className={btnGhost} onClick={async () => downloadBackup(JSON.parse((await getSnapshot(s.id)).payload))}>Baixar</button>
              <button type="button" className={btnGhost} onClick={async () => restoreFrom(JSON.parse((await getSnapshot(s.id)).payload), `de ${fmt(s.createdAt)}`)}>Restaurar</button>
              <button type="button" className={btnDanger} onClick={async () => { await deleteSnapshot(s.id); refresh(); }}>Excluir</button>
            </li>
          ))}
        </ul>
      )}

      {/* Histórico */}
      <h3 className="mb-2 mt-6 text-sm font-bold text-slate-200">Histórico de backups</h3>
      {cfg.history.length === 0 ? (
        <p className="text-sm text-slate-500">Nenhum backup realizado ainda.</p>
      ) : (
        <ul className="max-h-56 divide-y divide-slate-800 overflow-y-auto admin-scroll" data-backup-history>
          {cfg.history.map((h) => (
            <li key={h.id} className="flex flex-wrap items-center gap-2 py-2 text-xs">
              <Badge tone={h.ok ? "publicado" : "falha"}>{h.ok ? "ok" : "falhou"}</Badge>
              <span className="text-slate-300">{h.type} → {h.target === "drive" ? "Google Drive" : h.target === "arquivo" ? "arquivo" : "navegador"}</span>
              <span className="min-w-0 flex-1 truncate text-slate-500">{h.file || h.error || (h.size ? formatBytes(h.size) : "")}</span>
              <span className="text-slate-500">{fmt(h.at)}</span>
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}

/* ========================== POLÍTICAS DE PRIVACIDADE ========================== */

export function PrivacyCard({ state }) {
  const [url, setUrl] = useState(state.security.privacyUrl || "");
  const [msg, setMsg] = useState(null);
  const save = () => {
    const v = url.trim();
    if (v && !/^https?:\/\/\S+$/i.test(v)) return setMsg({ type: "err", text: "Cole um link completo (https://…)." });
    updateState((s) => {
      if ((s.security.privacyUrl || "") !== v) s.security.privacyVersion = Date.now(); // link novo: pede aceite de novo
      s.security.privacyUrl = v;
    });
    addLog("seguranca", v ? `Link das políticas de privacidade definido: ${v}` : "Link das políticas de privacidade removido");
    setMsg({ type: "ok", text: v ? "Link salvo. Ao entrar no site, os usuários precisarão aceitar as políticas." : "Link removido." });
  };
  return (
    <Card title="🔏 Políticas de privacidade" subtitle="Cole o link da página de políticas de privacidade.">
      <label htmlFor="privacy-url" className={labelCls}>Link da página de políticas de privacidade</label>
      <div className="flex flex-wrap gap-2">
        <input id="privacy-url" className={`${inputCls} min-w-0 flex-1`} value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://seusite.com/politica-de-privacidade" />
        <button type="button" className={btnPrimary} onClick={save}>Salvar</button>
      </div>
      {msg && <p role="status" className={`mt-2 text-sm ${msg.type === "ok" ? "text-emerald-400" : "text-rose-400"}`}>{msg.text}</p>}
    </Card>
  );
}

/** Janela obrigatória de aceite das políticas, exibida ao entrar no site (login). */
export function PrivacyGate({ state }) {
  const [checked, setChecked] = useState(false);
  const url = state.security.privacyUrl;
  const version = state.security.privacyVersion || 0;
  const user = getCurrentUser();
  if (!url || !user || user.privacyAccepted?.version === version) return null;

  const accept = () => {
    updateUser(user.id, { privacyAccepted: { version, url, at: new Date().toISOString() } });
    addLog("seguranca", `Políticas de privacidade aceitas por ${user.email}`);
  };
  const decline = () => {
    addLog("seguranca", `Políticas de privacidade recusadas por ${user.email} — sessão encerrada`);
    destroySession();
    navigate("/");
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-950/80 p-4 backdrop-blur-sm" role="dialog" aria-modal="true" aria-labelledby="privacy-title" data-privacy-gate>
      <div className="w-full max-w-md rounded-2xl border border-slate-700 bg-slate-900 p-6 shadow-2xl">
        <p className="text-3xl" aria-hidden="true">🔏</p>
        <h2 id="privacy-title" className="mt-2 text-xl font-bold text-white">Políticas de privacidade</h2>
        <p className="mt-2 text-sm text-slate-300">
          Para continuar usando o site, leia e aceite as nossas políticas de privacidade.
        </p>
        <a href={url} target="_blank" rel="noopener noreferrer" className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-amber-400 hover:underline">
          📄 Ler as políticas de privacidade ↗
        </a>
        <label className="mt-4 flex cursor-pointer items-start gap-2 text-sm text-slate-200">
          <input type="checkbox" className="mt-1" checked={checked} onChange={(e) => setChecked(e.target.checked)} aria-label="Li e aceito as políticas de privacidade" />
          Li e aceito as políticas de privacidade.
        </label>
        <div className="mt-6 flex flex-wrap justify-end gap-2">
          <button type="button" className={btnGhost} onClick={decline}>Recusar e sair</button>
          <button type="button" className={btnPrimary} disabled={!checked} onClick={accept}>Aceitar e continuar</button>
        </div>
      </div>
    </div>
  );
}

/* ================================ SMTP ================================ */

const PRESETS = [
  { name: "Gmail / Google Workspace", host: "smtp.gmail.com", port: 587, security: "starttls" },
  { name: "Outlook / Microsoft 365", host: "smtp.office365.com", port: 587, security: "starttls" },
  { name: "Zoho Mail", host: "smtp.zoho.com", port: 465, security: "ssl" },
  { name: "Hostinger", host: "smtp.hostinger.com", port: 465, security: "ssl" },
  { name: "SendGrid", host: "smtp.sendgrid.net", port: 587, security: "starttls" },
];

export function SmtpCard({ state }) {
  const [f, setF] = useState(() => { const c = smtpConfig(state); delete c.log; return c; });
  const [msg, setMsg] = useState(null);
  const [showPass, setShowPass] = useState(false);
  const [test, setTest] = useState(() => ({ to: smtpConfig(state).adminEmail || getCurrentUser()?.email || "", text: "" }));
  const [busy, setBusy] = useState("");
  const log = smtpConfig(state).log;
  const set = (k, v) => setF((x) => ({ ...x, [k]: v }));
  const isEmail = (v) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v || "");

  const save = () => {
    if (f.enabled) {
      if (!f.host.trim()) return setMsg({ type: "err", text: "Informe o servidor SMTP (host)." });
      if (!Number(f.port)) return setMsg({ type: "err", text: "Informe uma porta válida." });
      if (!isEmail(f.fromEmail)) return setMsg({ type: "err", text: "Informe um e-mail de remetente válido." });
      if (f.replyTo && !isEmail(f.replyTo)) return setMsg({ type: "err", text: "E-mail de resposta inválido." });
      if (f.adminEmail && !isEmail(f.adminEmail)) return setMsg({ type: "err", text: "E-mail do administrador inválido." });
      if (!/^https?:\/\/\S+$/i.test(f.relayUrl)) return setMsg({ type: "err", text: "Informe o endereço completo do servidor de envio (http(s)://…/send)." });
    }
    updateState((s) => { s.smtp = { ...smtpConfig(s), ...f, port: Number(f.port), host: f.host.trim() }; });
    addLog("seguranca", `Configurações SMTP salvas (${f.enabled ? `ativo: ${f.host}:${f.port}` : "desativado"})`);
    setMsg({ type: "ok", text: "Configurações SMTP salvas." });
  };
  const checkRelay = async () => {
    setBusy("health");
    try {
      const h = await relayHealth(f.relayUrl);
      setMsg({ type: "ok", text: `Servidor de envio no ar${h.keyRequired ? " (exige chave)" : " — atenção: sem chave (defina RELAY_KEY)"}.` });
    } catch (e) {
      setMsg({ type: "err", text: `Servidor de envio inacessível em ${f.relayUrl}: ${e.message}` });
    }
    setBusy("");
  };
  const sendTest = async () => {
    if (!isEmail(test.to)) return setMsg({ type: "err", text: "Informe um destinatário válido para o teste." });
    save();
    setBusy("test");
    try {
      const t = testEmail(test.text);
      await sendMail({ to: test.to, subject: t.subject, html: t.html, kind: "teste" });
      setMsg({ type: "ok", text: `E-mail de teste enviado para ${test.to}. Verifique a caixa de entrada (e o spam).` });
    } catch (e) {
      setMsg({ type: "err", text: `Falha no envio de teste: ${e.message}` });
    }
    setBusy("");
  };

  const field = (id, label, key, props = {}) => (
    <div>
      <label htmlFor={id} className={labelCls}>{label}</label>
      <input id={id} className={inputCls} value={f[key] ?? ""} onChange={(e) => set(key, e.target.value)} {...props} />
    </div>
  );

  return (
    <Card title="✉️ SMTP" subtitle="Configuração manual do envio de e-mails do site — usado na criação de contas, redefinição de senha e avisos ao administrador.">
      {msg && (
        <p role="status" className={`mb-4 rounded-xl border px-4 py-2.5 text-sm ${msg.type === "ok" ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-300" : "border-rose-500/40 bg-rose-500/10 text-rose-300"}`}>
          {msg.text}
        </p>
      )}
      <Toggle label={f.enabled ? "Envio de e-mails ATIVADO" : "Envio de e-mails DESATIVADO"}
        desc="Desativado: o “esqueci a senha” mostra o link na tela (modo demonstração) e nenhum e-mail é enviado."
        checked={!!f.enabled} onChange={(v) => set("enabled", v)} />

      <div className="mt-4 flex flex-wrap items-center gap-2 text-xs text-slate-400">
        Preencher com:
        {PRESETS.map((p) => (
          <button key={p.name} type="button" className="rounded-full border border-slate-700 px-2.5 py-1 text-slate-300 hover:border-amber-500"
            onClick={() => setF((x) => ({ ...x, host: p.host, port: p.port, security: p.security }))}>{p.name}</button>
        ))}
      </div>

      <div className="mt-4 grid gap-4 md:grid-cols-3">
        {field("smtp-host", "Servidor SMTP (host)", "host", { placeholder: "smtp.seuprovedor.com" })}
        {field("smtp-port", "Porta", "port", { inputMode: "numeric", placeholder: "587" })}
        <div>
          <label htmlFor="smtp-sec" className={labelCls}>Criptografia</label>
          <select id="smtp-sec" className={inputCls} value={f.security} onChange={(e) => set("security", e.target.value)}>
            <option value="starttls">STARTTLS (porta 587)</option>
            <option value="ssl">SSL/TLS (porta 465)</option>
            <option value="none">Nenhuma (porta 25/2525)</option>
          </select>
        </div>
        {field("smtp-user", "Usuário", "user", { autoComplete: "off", placeholder: "voce@seudominio.com" })}
        <div>
          <label htmlFor="smtp-pass" className={labelCls}>Senha (ou senha de app)</label>
          <div className="flex gap-1">
            <input id="smtp-pass" type={showPass ? "text" : "password"} autoComplete="new-password" className={inputCls} value={f.pass} onChange={(e) => set("pass", e.target.value)} />
            <button type="button" className={btnGhost} onClick={() => setShowPass((v) => !v)} aria-label={showPass ? "Ocultar senha" : "Mostrar senha"}>{showPass ? "🙈" : "👁"}</button>
          </div>
        </div>
        {field("smtp-fromname", "Nome do remetente", "fromName", { placeholder: "Pica-Pau" })}
        {field("smtp-from", "E-mail do remetente", "fromEmail", { type: "email", placeholder: "nao-responda@seudominio.com" })}
        {field("smtp-reply", "Responder para (opcional)", "replyTo", { type: "email", placeholder: "contato@seudominio.com" })}
        {field("smtp-admin", "E-mail do administrador (recebe avisos)", "adminEmail", { type: "email", placeholder: "voce@seudominio.com" })}
      </div>
      <label className="mt-3 flex items-center gap-2 text-sm text-slate-300">
        <input type="checkbox" checked={!!f.notifyNewAccounts} onChange={(e) => set("notifyNewAccounts", e.target.checked)} aria-label="Avisar o administrador sobre novas contas" />
        Avisar o administrador por e-mail quando uma nova conta for criada
      </label>

      <div className="mt-4 grid gap-4 rounded-xl border border-slate-800 bg-slate-900/60 p-4 md:grid-cols-2">
        {field("smtp-relay", "Servidor de envio (relay)", "relayUrl", { placeholder: "https://seu-relay.com/send" })}
        {field("smtp-relaykey", "Chave do servidor de envio (RELAY_KEY)", "relayKey", { type: "password", autoComplete: "new-password" })}
        <p className="text-xs text-slate-400 md:col-span-2">
          O navegador não fala SMTP diretamente: rode o servidor de envio incluído no projeto com{" "}
          <code className="rounded bg-slate-800 px-1 text-amber-300">RELAY_KEY=sua-chave node smtp-relay/server.js</code> (Node.js, sem dependências)
          num servidor/hospedagem Node e informe o endereço acima. Gmail/Outlook exigem “senha de app”.
          A senha SMTP fica salva neste navegador e é enviada apenas ao seu servidor de envio — use HTTPS.
        </p>
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        <button type="button" className={btnPrimary} onClick={save}>Salvar SMTP</button>
        <button type="button" className={btnGhost} onClick={checkRelay} disabled={busy === "health"}>{busy === "health" ? "Verificando…" : "🔌 Verificar servidor de envio"}</button>
      </div>

      {/* Envio de e-mail de teste */}
      <div className="mt-6 rounded-xl border border-amber-500/30 bg-amber-500/5 p-4" data-smtp-test>
        <h3 className="text-sm font-bold text-slate-100">📨 Enviar e-mail de teste</h3>
        <div className="mt-3 grid gap-3 md:grid-cols-[1fr_2fr_auto]">
          <input className={inputCls} type="email" value={test.to} onChange={(e) => setTest((t) => ({ ...t, to: e.target.value }))} placeholder="destinatario@exemplo.com" aria-label="Destinatário do teste" />
          <input className={inputCls} value={test.text} onChange={(e) => setTest((t) => ({ ...t, text: e.target.value }))} placeholder="Mensagem (opcional)" aria-label="Mensagem do teste" />
          <button type="button" className={btnPrimary} onClick={sendTest} disabled={busy === "test"}>{busy === "test" ? "Enviando…" : "Enviar teste"}</button>
        </div>
        <p className="mt-2 text-xs text-slate-500">As configurações são salvas antes do envio.</p>
      </div>

      {/* Registro de envios */}
      <h3 className="mb-2 mt-6 text-sm font-bold text-slate-200">Registro de e-mails ({log.length})</h3>
      {log.length === 0 ? (
        <p className="text-sm text-slate-500">Nenhum e-mail enviado ainda.</p>
      ) : (
        <ul className="max-h-56 divide-y divide-slate-800 overflow-y-auto admin-scroll" data-mail-log>
          {log.map((l) => (
            <li key={l.id} className="flex flex-wrap items-center gap-2 py-2 text-xs">
              <Badge tone={l.ok ? "publicado" : "falha"}>{l.ok ? "enviado" : "falhou"}</Badge>
              <span className="text-slate-300">{l.kind}</span>
              <span className="text-slate-400">→ {l.to}</span>
              <span className="min-w-0 flex-1 truncate text-slate-500">{l.ok ? l.subject : l.error}</span>
              <span className="text-slate-500">{fmt(l.at)}</span>
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}
