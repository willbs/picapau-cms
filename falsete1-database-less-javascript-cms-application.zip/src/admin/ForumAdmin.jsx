// Painel → Fórum:
// - botão habilitar/desabilitar a sessão Fórum
// - escolha entre 5 layouts da página do fórum
// - área de personalização de páginas de usuários cadastrados (5 modelos, foto de perfil/capa)
// - categorias e moderação de tópicos
import { useState } from "react";
import { Card, inputCls, labelCls, btnPrimary, btnGhost, btnDanger, Badge, Toggle } from "./ui.jsx";
import Modal from "../components/Modal.jsx";
import { updateState } from "../store.js";
import { addLog } from "../auth.js";
import { uid, slugify, formatDate } from "../utils.js";
import { navigate } from "../router.js";
import { FORUM_TEMPLATES } from "../pages/Forum.jsx";
import { PROFILE_TEMPLATES, ProfileForm } from "../pages/ForumProfile.jsx";

export default function ForumAdmin({ state }) {
  const forum = state.forum || { categories: [], topics: [], profiles: [], template: "classico" };
  const profiles = forum.profiles || [];
  const enabled = state.features?.forum !== false;
  const [catModal, setCatModal] = useState(null);
  const [catError, setCatError] = useState("");
  const [profModal, setProfModal] = useState(null); // perfil em edição (ou novo)

  const topics = [...(forum.topics || [])].sort((a, b) => b.pinned - a.pinned || new Date(b.createdAt) - new Date(a.createdAt));
  const catName = (slug) => forum.categories.find((c) => c.slug === slug)?.name || slug || "—";

  const toggleForum = (on) => {
    updateState((s) => { s.features.forum = on; });
    addLog("sistema", `Sessão Fórum ${on ? "HABILITADA" : "DESABILITADA"}`);
  };
  const setTemplate = (id) => {
    updateState((s) => { s.forum.template = id; });
    addLog("sistema", `Layout da página do fórum alterado para "${id}"`);
  };

  const patchTopic = (id, patch) => updateState((s) => {
    const t = s.forum.topics.find((x) => x.id === id);
    if (t) Object.assign(t, patch);
  });
  const deleteTopic = (t) => {
    if (!window.confirm(`Excluir o tópico "${t.title}" e todas as respostas?`)) return;
    updateState((s) => { s.forum.topics = s.forum.topics.filter((x) => x.id !== t.id); });
  };
  const deleteReply = (topicId, replyId) => updateState((s) => {
    const t = s.forum.topics.find((x) => x.id === topicId);
    if (t) t.replies = t.replies.filter((r) => r.id !== replyId);
  });

  const saveCat = () => {
    const c = { ...catModal };
    if (!c.name.trim()) return setCatError("O nome da categoria é obrigatório.");
    c.slug = (c.slug || slugify(c.name)).trim() || slugify(c.name);
    if (forum.categories.find((x) => x.slug === c.slug && x.id !== c.id)) return setCatError(`Já existe uma categoria com o slug "${c.slug}".`);
    updateState((s) => {
      const i = s.forum.categories.findIndex((x) => x.id === c.id);
      if (i >= 0) s.forum.categories[i] = c;
      else s.forum.categories.push(c);
    });
    setCatModal(null);
  };
  const deleteCat = (c) => {
    if (!window.confirm(`Excluir a categoria "${c.name}"?`)) return;
    updateState((s) => {
      s.forum.categories = s.forum.categories.filter((x) => x.id !== c.id);
      s.forum.topics.forEach((t) => { if (t.category === c.slug) t.category = ""; });
    });
  };

  const newProfile = () => setProfModal({
    id: uid(), username: "", name: "", bio: "", avatar: "", cover: "", template: "classico",
    following: [], videos: [], createdAt: new Date().toISOString(), _new: true,
  });
  const saveProfile = (data) => {
    const base = { ...profModal };
    delete base._new;
    const p = { ...base, ...data };
    updateState((s) => {
      const i = s.forum.profiles.findIndex((x) => x.id === p.id);
      if (i >= 0) s.forum.profiles[i] = p;
      else s.forum.profiles.push(p);
    });
    addLog("sistema", `Perfil do fórum salvo: @${p.username} (modelo ${p.template})`);
    setProfModal(null);
  };
  const deleteProfile = (p) => {
    if (!window.confirm(`Excluir o perfil @${p.username}?`)) return;
    updateState((s) => {
      s.forum.profiles = s.forum.profiles.filter((x) => x.id !== p.id);
      s.forum.profiles.forEach((x) => { x.following = x.following.filter((id) => id !== p.id); });
    });
  };
  const followersOf = (p) => profiles.filter((x) => x.following.includes(p.id)).length;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-white">💬 Fórum</h1>
          <p className="mt-1 text-sm text-slate-400">
            Layouts, perfis de usuários, categorias e moderação — página pública{" "}
            <code className="rounded bg-slate-800 px-1.5 py-0.5 text-amber-300">/forum</code>.
          </p>
        </div>
        <div className="flex gap-2">
          <button type="button" className={btnGhost} onClick={() => navigate("/forum")}>🌐 Ver fórum</button>
          <button type="button" className={btnPrimary} onClick={newProfile}>+ Novo perfil</button>
        </div>
      </div>

      {/* Habilitar / desabilitar */}
      <Card title="Sessão Fórum">
        <Toggle
          label={enabled ? "Fórum HABILITADO" : "Fórum DESABILITADO"}
          desc={enabled
            ? "As páginas /forum, tópicos e perfis estão no ar e o link aparece no menu."
            : "Todas as páginas do fórum retornam 404 e o link sai do menu (dados continuam salvos)."}
          checked={enabled}
          onChange={toggleForum}
        />
      </Card>

      {/* 5 layouts da página do fórum */}
      <Card title="Layout da página do fórum" subtitle="Escolha entre 5 opções — aplicado na hora em /forum.">
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5" role="radiogroup" aria-label="Layout do fórum">
          {FORUM_TEMPLATES.map((t) => {
            const active = (forum.template || "classico") === t.id;
            return (
              <button key={t.id} type="button" role="radio" aria-checked={active} onClick={() => setTemplate(t.id)}
                className={`rounded-xl border p-3 text-left transition ${active ? "border-amber-500 bg-amber-500/10 ring-2 ring-amber-500/30" : "border-slate-700 bg-slate-800/50 hover:border-slate-500"}`}>
                <span className="text-2xl" aria-hidden="true">{t.icon}</span>
                <p className="mt-1 text-sm font-bold text-slate-100">{t.name}</p>
                <p className="mt-0.5 text-xs text-slate-400">{t.desc}</p>
              </button>
            );
          })}
        </div>
      </Card>

      {/* Perfis de usuários */}
      <Card
        title={`👤 Páginas de usuários (${profiles.length})`}
        subtitle="Personalize a página de cada usuário: 5 modelos, foto de perfil, foto de capa e bio. Os próprios usuários também podem personalizar pela página de perfil."
        actions={<button type="button" className={btnPrimary} onClick={newProfile}>+ Novo perfil</button>}
      >
        <div className="mb-4 flex flex-wrap gap-2 text-xs text-slate-400">
          {PROFILE_TEMPLATES.map((t) => (
            <span key={t.id} className="rounded-full border border-slate-700 px-2 py-1">
              {t.icon} {t.name}: {profiles.filter((p) => p.template === t.id).length}
            </span>
          ))}
        </div>
        {profiles.length === 0 ? (
          <p className="py-4 text-sm text-slate-400">Nenhum perfil ainda.</p>
        ) : (
          <ul className="grid gap-3 md:grid-cols-2">
            {profiles.map((p) => {
              const tpl = PROFILE_TEMPLATES.find((t) => t.id === p.template);
              return (
                <li key={p.id} className="overflow-hidden rounded-xl border border-slate-800 bg-slate-900/70">
                  <div className="h-16 bg-gradient-to-r from-indigo-600 to-amber-500">
                    {p.cover && <img src={p.cover} alt="" className="h-full w-full object-cover" />}
                  </div>
                  <div className="flex flex-wrap items-center gap-3 p-3">
                    {p.avatar ? <img src={p.avatar} alt="" className="-mt-8 h-14 w-14 rounded-full object-cover ring-4 ring-slate-900" />
                      : <span className="-mt-8 flex h-14 w-14 items-center justify-center rounded-full bg-indigo-500/30 text-lg font-bold text-indigo-200 ring-4 ring-slate-900">{p.name[0]}</span>}
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-bold text-slate-100">{p.name}</p>
                      <p className="text-xs text-slate-500">
                        @{p.username} · {followersOf(p)} seguidores · segue {p.following.length} · {(p.videos || []).length} vídeos · ❤️ {(p.wishlist || []).length} na lista de desejos
                      </p>
                    </div>
                    <Badge tone="video">{tpl?.icon} {tpl?.name || p.template}</Badge>
                  </div>
                  <div className="flex flex-wrap gap-2 border-t border-slate-800 p-3">
                    <button type="button" className={btnGhost} onClick={() => setProfModal(JSON.parse(JSON.stringify(p)))}>Personalizar</button>
                    <button type="button" className={btnGhost} onClick={() => navigate(`/forum/u/${p.username}`)}>Ver página</button>
                    <button type="button" className={btnDanger} onClick={() => deleteProfile(p)}>Excluir</button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </Card>

      {/* Categorias */}
      <Card title={`Categorias (${forum.categories.length})`}
        actions={<button type="button" className={btnGhost} onClick={() => { setCatModal({ id: uid(), name: "", slug: "", icon: "💬", description: "" }); setCatError(""); }}>+ Nova categoria</button>}>
        <ul className="divide-y divide-slate-800">
          {forum.categories.map((c) => (
            <li key={c.id} className="flex flex-wrap items-center gap-3 py-3">
              <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-indigo-500/15 text-lg" aria-hidden="true">{c.icon}</span>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-semibold text-slate-100">{c.name}</p>
                <p className="truncate text-xs text-slate-500">slug: {c.slug} · {c.description}</p>
              </div>
              <button type="button" className={btnGhost} onClick={() => { setCatModal(JSON.parse(JSON.stringify(c))); setCatError(""); }}>Editar</button>
              <button type="button" className={btnDanger} onClick={() => deleteCat(c)}>Excluir</button>
            </li>
          ))}
        </ul>
      </Card>

      {/* Tópicos */}
      <Card title={`Tópicos (${topics.length})`} subtitle="Fixar, bloquear ou excluir tópicos e respostas.">
        <ul className="divide-y divide-slate-800">
          {topics.map((t) => (
            <li key={t.id} className="py-3.5">
              <div className="flex flex-wrap items-center gap-3">
                <button type="button" onClick={() => navigate(`/forum/${t.id}`)} className="min-w-0 flex-1 text-left">
                  <p className="truncate text-sm font-semibold text-slate-100 hover:text-amber-300">{t.pinned && "📌 "}{t.locked && "🔒 "}{t.title}</p>
                  <p className="text-xs text-slate-500">{t.author} · {catName(t.category)} · {formatDate(t.createdAt)} · 💬 {t.replies.length}</p>
                </button>
                <Badge tone={t.pinned ? "agendado" : "rascunho"}>{t.pinned ? "fixado" : "normal"}</Badge>
                <Badge tone={t.locked ? "audio" : "publicado"}>{t.locked ? "bloqueado" : "aberto"}</Badge>
                <button type="button" className={btnGhost} onClick={() => patchTopic(t.id, { pinned: !t.pinned })}>{t.pinned ? "Desafixar" : "Fixar"}</button>
                <button type="button" className={btnGhost} onClick={() => patchTopic(t.id, { locked: !t.locked })}>{t.locked ? "Desbloquear" : "Bloquear"}</button>
                <button type="button" className={btnDanger} onClick={() => deleteTopic(t)}>Excluir</button>
              </div>
              {t.replies.length > 0 && (
                <ul className="ml-6 mt-2 space-y-1.5 border-l-2 border-slate-800 pl-3">
                  {t.replies.map((r) => (
                    <li key={r.id} className="flex items-center gap-2 text-xs text-slate-400">
                      <span className="min-w-0 flex-1 truncate"><strong className="text-slate-300">{r.author}:</strong> {r.body}</span>
                      <button type="button" className={`${btnDanger} !px-1.5 !py-0.5 !text-[11px]`} onClick={() => deleteReply(t.id, r.id)}>✕</button>
                    </li>
                  ))}
                </ul>
              )}
            </li>
          ))}
        </ul>
      </Card>

      {/* Modal: personalizar perfil */}
      <Modal open={!!profModal} onClose={() => setProfModal(null)} title={profModal?._new ? "Novo perfil de usuário" : `Personalizar @${profModal?.username}`} wide>
        {profModal && (
          <ProfileForm profile={profModal} allProfiles={profiles} onCancel={() => setProfModal(null)} onSaved={saveProfile} />
        )}
      </Modal>

      {/* Modal: categoria */}
      <Modal open={!!catModal} onClose={() => setCatModal(null)} title={catModal?.name ? "Editar categoria" : "Nova categoria"}>
        {catModal && (
          <div className="space-y-4">
            {catError && <p role="alert" className="rounded-lg border border-rose-500/40 bg-rose-500/10 px-3 py-2 text-sm text-rose-300">{catError}</p>}
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="fc-name" className={labelCls}>Nome *</label>
                <input id="fc-name" className={inputCls} value={catModal.name} onChange={(e) => setCatModal((c) => ({ ...c, name: e.target.value, slug: c.slug || slugify(e.target.value) }))} />
              </div>
              <div>
                <label htmlFor="fc-slug" className={labelCls}>Slug</label>
                <input id="fc-slug" className={inputCls} value={catModal.slug} onChange={(e) => setCatModal((c) => ({ ...c, slug: slugify(e.target.value) }))} />
              </div>
              <div>
                <label htmlFor="fc-icon" className={labelCls}>Ícone (emoji)</label>
                <input id="fc-icon" className={inputCls} value={catModal.icon} maxLength={4} onChange={(e) => setCatModal((c) => ({ ...c, icon: e.target.value }))} />
              </div>
            </div>
            <div>
              <label htmlFor="fc-desc" className={labelCls}>Descrição</label>
              <textarea id="fc-desc" className={inputCls} rows={2} value={catModal.description} onChange={(e) => setCatModal((c) => ({ ...c, description: e.target.value }))} />
            </div>
            <div className="flex justify-end gap-2">
              <button type="button" className={btnGhost} onClick={() => setCatModal(null)}>Cancelar</button>
              <button type="button" className={btnPrimary} onClick={saveCat}>Salvar categoria</button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
