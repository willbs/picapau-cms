// Estrutura do painel administrativo: sidebar escura, topo com sessão e ações.
import { useEffect, useState } from "react";
import { navigate } from "../router.js";
import { getSession, destroySession, addLog, getSessionMinutes } from "../auth.js";
import { cn } from "../utils.js";
import { PrivacyGate } from "./SecurityExtras.jsx";

const NAV = [
  { to: "/admin", label: "Painel", icon: "📊", exact: true },
  { to: "/admin/artigos", label: "Artigos", icon: "✍️" },
  { to: "/admin/categorias", label: "Categorias", icon: "🗂️" },
  { to: "/admin/menus", label: "Menus", icon: "☰" },
  { to: "/admin/podcasts", label: "Podcasts", icon: "🎧" },
  { to: "/admin/tema", label: "Tema", icon: "🖌️" },
  { to: "/admin/marca", label: "Marca", icon: "🎨" },
  { to: "/admin/loja", label: "Loja", icon: "🛒" },
  { to: "/admin/forum", label: "Fórum", icon: "💬" },
  { to: "/admin/comentarios", label: "Comentários", icon: "💬" },
  { to: "/admin/html", label: "HTML", icon: "</>" },
  { to: "/admin/redes-sociais", label: "Redes Sociais", icon: "🌐" },
  { to: "/admin/rodape", label: "Rodapé", icon: "🦶" },
  { to: "/admin/traducao", label: "Tradução", icon: "🌍" },
  { to: "/admin/seo", label: "SEO", icon: "🔍" },
  { to: "/admin/seguranca", label: "Segurança", icon: "🛡️" },
];

export default function AdminLayout({ state, route, children }) {
  const [open, setOpen] = useState(false);
  const [remaining, setRemaining] = useState("");
  const pendingComments = (state.comments || []).filter((c) => c.status === "pendente").length;

  // Contagem regressiva da sessão (expiração deslizante por atividade).
  useEffect(() => {
    const tick = () => {
      const s = getSession();
      if (!s) {
        setRemaining("");
        return;
      }
      const ms = s.expiresAt - Date.now();
      const mm = Math.floor(ms / 60000);
      const ss = Math.floor((ms % 60000) / 1000);
      setRemaining(`${mm}:${String(ss).padStart(2, "0")}`);
    };
    tick();
    const iv = setInterval(tick, 1000);
    return () => clearInterval(iv);
  }, [route]);

  const logout = () => {
    addLog("logout", "Logout manual pelo painel");
    destroySession();
    navigate("/");
  };

  const linkCls = (to, exact) =>
    cn(
      "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition",
      exact ? (route === to ? "bg-amber-500/15 text-amber-300" : "text-slate-400 hover:bg-slate-800 hover:text-white")
        : (route.startsWith(to) ? "bg-amber-500/15 text-amber-300" : "text-slate-400 hover:bg-slate-800 hover:text-white")
    );

  const sidebar = (
    <div className="flex h-full flex-col">
      <button
        type="button"
        onClick={() => navigate("/admin")}
        className="flex items-center gap-2.5 border-b border-slate-800 px-5 py-4 text-left"
      >
        <img src={state.branding?.logo || state.seo.favicon || "/favicon.svg"} alt="" className="h-8 w-8 rounded-lg object-cover" />
        <span>
          <span className="block text-sm font-extrabold text-white">{state.branding?.siteName || "Pica-Pau"} CMS</span>
          <span className="block text-[11px] text-slate-500">painel administrativo</span>
        </span>
      </button>
      <nav className="flex-1 space-y-1 overflow-y-auto admin-scroll p-3" aria-label="Navegação do painel">
        {NAV.map((n) => (
          <button
            key={n.to}
            type="button"
            onClick={() => {
              setOpen(false);
              navigate(n.to);
            }}
            className={cn(linkCls(n.to, n.exact), "w-full")}
            aria-current={n.exact ? route === n.to : route.startsWith(n.to) ? "page" : undefined}
          >
            <span aria-hidden="true">{n.icon}</span>
            {n.label}
            {n.to === "/admin/comentarios" && pendingComments > 0 && (
              <span className="ml-auto rounded-full bg-rose-500 px-1.5 text-[11px] font-bold text-white" aria-label={`${pendingComments} comentários pendentes`} data-pending-badge>
                {pendingComments}
              </span>
            )}
          </button>
        ))}
      </nav>
      <div className="border-t border-slate-800 p-3">
        <button
          type="button"
          onClick={logout}
          className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-rose-300 transition hover:bg-rose-500/10"
        >
          <span aria-hidden="true">⏻</span> Sair
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200">
      {/* Aceite obrigatório das políticas de privacidade ao entrar */}
      <PrivacyGate state={state} />

      {/* Sidebar desktop */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-60 border-r border-slate-800 bg-slate-900/90 lg:block">
        {sidebar}
      </aside>

      {/* Sidebar mobile */}
      {open && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-black/60" onClick={() => setOpen(false)} />
          <aside className="absolute inset-y-0 left-0 w-64 bg-slate-900 shadow-2xl">{sidebar}</aside>
        </div>
      )}

      <div className="lg:pl-60">
        {/* Topbar */}
        <header className="sticky top-0 z-20 flex h-16 items-center justify-between gap-3 border-b border-slate-800 bg-slate-950/85 px-4 backdrop-blur">
          <div className="flex items-center gap-3">
            <button
              type="button"
              className="rounded-lg p-2 text-slate-300 hover:bg-slate-800 lg:hidden"
              aria-label="Abrir menu do painel"
              onClick={() => setOpen(true)}
            >
              <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                <path d="M4 7h16M4 12h16M4 17h16" />
              </svg>
            </button>
            <p className="text-sm font-semibold text-white">Painel de controle</p>
            {state.security.maintenance && (
              <span className="rounded-full bg-amber-500/15 px-2 py-0.5 text-xs font-semibold text-amber-300">
                🛠️ modo manutenção ativo
              </span>
            )}
          </div>
          <div className="flex items-center gap-3">
            <span
              className="hidden items-center gap-1.5 rounded-lg border border-slate-800 px-2.5 py-1.5 text-xs text-slate-400 sm:flex"
              title={`Sessão expira em ${getSessionMinutes()} min de inatividade`}
            >
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" aria-hidden="true" />
              sessão {remaining}
            </span>
            <button
              type="button"
              onClick={() => navigate("/")}
              className="rounded-lg border border-slate-700 px-3 py-1.5 text-xs font-medium text-slate-300 transition hover:bg-slate-800"
            >
              🌐 Ver site
            </button>
            <button
              type="button"
              onClick={logout}
              className="rounded-lg border border-rose-500/40 px-3 py-1.5 text-xs font-medium text-rose-300 transition hover:bg-rose-500/10"
            >
              Sair
            </button>
          </div>
        </header>

        <main className="mx-auto max-w-7xl p-4 sm:p-6">{children}</main>
      </div>
    </div>
  );
}
