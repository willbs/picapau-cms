// Painel → Rodapé: escolha entre 8 modelos, o que colocar/retirar do rodapé
// (inclusive os ícones das redes sociais), texto de direitos autorais e menu inferior.
import { useState } from "react";
import { Card, inputCls, labelCls, btnPrimary, btnGhost, btnDanger } from "./ui.jsx";
import Footer, { FOOTER_TEMPLATES, FOOTER_PARTS, footerConfig, renderCopyright } from "../components/Footer.jsx";
import { updateState } from "../store.js";
import { addLog } from "../auth.js";
import { uid, cn } from "../utils.js";

/** Miniatura esquemática de cada modelo de rodapé. */
function Thumb({ id }) {
  const bar = "h-1 rounded bg-slate-500";
  const dot = "h-1.5 w-1.5 rounded-full bg-amber-400";
  const base = "flex h-14 w-full flex-col justify-between rounded-md p-1.5";
  const dark = "bg-slate-950 border border-slate-700";
  if (id === "centralizado") return <div className={cn(base, dark, "items-center")}><div className={`${bar} w-1/3`} /><div className="flex gap-1">{[0,1,2,3].map((i)=><span key={i} className={dot} />)}</div><div className={`${bar} w-1/2`} /></div>;
  if (id === "minimal") return <div className={cn(base, dark, "justify-end")}><div className="flex items-center justify-between"><div className={`${bar} w-1/4`} /><div className={`${bar} w-1/4`} /><div className="flex gap-0.5">{[0,1,2].map((i)=><span key={i} className={dot} />)}</div></div></div>;
  if (id === "colunas") return <div className={cn(base, "bg-gradient-to-br from-slate-950 to-indigo-900 border border-slate-700")}><div className="grid grid-cols-5 gap-1"><div className={`${bar} col-span-2`} />{[0,1,2].map((i)=><div key={i} className={bar} />)}</div><div className={`${bar} w-1/3`} /></div>;
  if (id === "claro") return <div className={cn(base, "bg-slate-100 border border-slate-300")}><div className="grid grid-cols-4 gap-1">{[0,1,2,3].map((i)=><div key={i} className="h-1 rounded bg-slate-400" />)}</div><div className="h-1 w-1/3 rounded bg-slate-400" /></div>;
  if (id === "cartao") return <div className={cn(base, "bg-slate-800 border border-slate-700 p-2")}><div className="flex-1 rounded bg-white p-1"><div className="grid grid-cols-3 gap-1">{[0,1,2].map((i)=><div key={i} className="h-1 rounded bg-slate-400" />)}</div></div></div>;
  if (id === "dividido") return <div className={cn(base, "flex-row gap-0 p-0 border border-slate-700 overflow-hidden")}><div className="flex-1 bg-slate-950 p-1.5"><div className={`${bar} w-2/3`} /></div><div className="flex-1 bg-amber-500 p-1.5"><div className="h-1 w-2/3 rounded bg-slate-900" /></div></div>;
  if (id === "social") return <div className={cn(base, dark, "items-center justify-center gap-1")}><div className="flex gap-1">{[0,1,2,3].map((i)=><span key={i} className="h-3 w-3 rounded-full bg-amber-400" />)}</div><div className={`${bar} w-1/3`} /></div>;
  return <div className={cn(base, dark)}><div className="grid grid-cols-4 gap-1">{[0,1,2,3].map((i)=><div key={i} className={bar} />)}</div><div className="flex justify-between"><div className={`${bar} w-1/3`} /><div className={`${bar} w-1/4`} /></div></div>;
}

export default function FooterAdmin({ state }) {
  const [form, setForm] = useState(() => JSON.parse(JSON.stringify(footerConfig(state))));
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");

  const setShow = (id, v) => setForm((f) => ({ ...f, show: { ...f.show, [id]: v } }));
  const setItem = (id, patch) => setForm((f) => ({ ...f, bottomMenu: f.bottomMenu.map((i) => (i.id === id ? { ...i, ...patch } : i)) }));
  const move = (idx, dir) => setForm((f) => {
    const arr = [...f.bottomMenu];
    const j = idx + dir;
    if (j < 0 || j >= arr.length) return f;
    [arr[idx], arr[j]] = [arr[j], arr[idx]];
    return { ...f, bottomMenu: arr };
  });

  const save = () => {
    setError("");
    const bad = form.bottomMenu.find((i) => !i.label.trim() || !i.url.trim());
    if (bad) return setError("Preencha o texto e o link de todos os itens do menu inferior (ou remova os vazios).");
    updateState((s) => { s.footer = form; });
    addLog("sistema", `Rodapé atualizado (modelo "${form.template}")`);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-white">🦶 Rodapé</h1>
          <p className="mt-1 text-sm text-slate-400">Modelo, conteúdo, direitos autorais e menu inferior do rodapé do site.</p>
        </div>
        <button type="button" className={btnPrimary} onClick={save}>{saved ? "✓ Salvo!" : "Salvar rodapé"}</button>
      </div>

      {error && <p role="alert" className="rounded-xl border border-rose-500/40 bg-rose-500/10 px-4 py-3 text-sm text-rose-300">{error}</p>}

      <Card title="Modelo do rodapé" subtitle="8 opções — a prévia abaixo atualiza na hora.">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4" role="radiogroup" aria-label="Modelo do rodapé">
          {FOOTER_TEMPLATES.map((t) => {
            const active = form.template === t.id;
            return (
              <button key={t.id} type="button" role="radio" aria-checked={active} onClick={() => setForm((f) => ({ ...f, template: t.id }))}
                className={`rounded-xl border p-3 text-left transition ${active ? "border-amber-500 bg-amber-500/10 ring-2 ring-amber-500/30" : "border-slate-700 bg-slate-800/50 hover:border-slate-500"}`}>
                <Thumb id={t.id} />
                <p className="mt-2 text-sm font-bold text-slate-100">{t.name}</p>
                <p className="mt-0.5 text-xs text-slate-400">{t.desc}</p>
              </button>
            );
          })}
        </div>
      </Card>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card title="O que exibir no rodapé" subtitle="Coloque ou retire cada item (inclusive os ícones das redes sociais).">
          <ul className="grid gap-2 sm:grid-cols-2" aria-label="Itens do rodapé">
            {FOOTER_PARTS.map((p) => (
              <li key={p.id}>
                <label className={cn("flex cursor-pointer items-center gap-3 rounded-xl border px-3 py-2.5 text-sm transition",
                  form.show[p.id] ? "border-amber-500/50 bg-amber-500/10 text-slate-100" : "border-slate-700 text-slate-400")}>
                  <input type="checkbox" checked={!!form.show[p.id]} onChange={(e) => setShow(p.id, e.target.checked)} aria-label={p.label} />
                  {p.label}
                </label>
              </li>
            ))}
          </ul>
          {!form.show.access && (
            <p className="mt-3 text-xs text-amber-300/80">Sem o botão “Acesso”, o login continua disponível pela rota /login.</p>
          )}
          <p className="mt-2 text-xs text-slate-500">Quais redes aparecem e seus links são definidos em Painel → Redes Sociais.</p>
        </Card>

        <Card title="©️ Direitos autorais" subtitle="Texto exibido no rodapé. Variáveis: {{ano}} e {{site}}.">
          <label htmlFor="ft-copy" className={labelCls}>Texto de direitos autorais</label>
          <textarea id="ft-copy" className={inputCls} rows={3} value={form.copyright}
            onChange={(e) => setForm((f) => ({ ...f, copyright: e.target.value }))} />
          <p className="mt-2 rounded-lg border border-slate-800 bg-slate-950 p-2 text-xs text-slate-300">
            Prévia: {renderCopyright(form.copyright, state) || <em className="text-slate-500">vazio</em>}
          </p>
        </Card>
      </div>

      <Card
        title={`Menu inferior (${form.bottomMenu.length})`}
        subtitle="Links da barra inferior do rodapé. Links externos (https://…) abrem em nova aba; links de sessões desabilitadas somem sozinhos."
        actions={<button type="button" className={btnGhost} onClick={() => setForm((f) => ({ ...f, bottomMenu: [...f.bottomMenu, { id: uid(), label: "Novo link", url: "/" }] }))}>+ Adicionar link</button>}
      >
        {form.bottomMenu.length === 0 ? (
          <p className="text-sm text-slate-500">Nenhum link no menu inferior.</p>
        ) : (
          <ul className="space-y-2">
            {form.bottomMenu.map((i, idx) => (
              <li key={i.id} className="flex flex-wrap items-center gap-2" data-bottom-row>
                <input className={`${inputCls} w-48`} value={i.label} onChange={(e) => setItem(i.id, { label: e.target.value })} aria-label="Texto do link" placeholder="Texto" />
                <input className={`${inputCls} min-w-0 flex-1 basis-48`} value={i.url} onChange={(e) => setItem(i.id, { url: e.target.value })} aria-label="Endereço do link" placeholder="/pagina ou https://…" />
                <button type="button" className={`${btnGhost} !px-2 !py-1`} onClick={() => move(idx, -1)} aria-label="Mover para cima">↑</button>
                <button type="button" className={`${btnGhost} !px-2 !py-1`} onClick={() => move(idx, 1)} aria-label="Mover para baixo">↓</button>
                <button type="button" className={`${btnDanger} !px-2 !py-1`} onClick={() => setForm((f) => ({ ...f, bottomMenu: f.bottomMenu.filter((x) => x.id !== i.id) }))} aria-label={`Remover ${i.label}`}>✕</button>
              </li>
            ))}
          </ul>
        )}
      </Card>

      <Card title="👁 Prévia ao vivo" subtitle="Como o rodapé ficará no site (salve para aplicar).">
        <div className="overflow-hidden rounded-xl border border-slate-700 bg-slate-100" data-footer-preview>
          <Footer state={{ ...state, footer: form }} preview />
        </div>
      </Card>
    </div>
  );
}
