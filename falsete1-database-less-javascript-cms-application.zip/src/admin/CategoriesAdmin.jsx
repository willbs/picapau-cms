// Gerenciamento de categorias: criar, editar, reordenar (arrastar e soltar) e excluir.
import { useState } from "react";
import { Card, inputCls, labelCls, btnPrimary, btnGhost, btnDanger } from "./ui.jsx";
import Modal from "../components/Modal.jsx";
import { updateState } from "../store.js";
import { uid, slugify } from "../utils.js";

function blankCategory() {
  return {
    id: uid(),
    slug: "",
    name: "",
    icon: "📁",
    color: "#f59e0b",
    description: "",
    image: "",
    seo: { title: "", description: "", keywords: "", ogImage: "" },
  };
}

export default function CategoriesAdmin({ state }) {
  const [editing, setEditing] = useState(null); // categoria em edição (ou nova)
  const [slugTouched, setSlugTouched] = useState(false);
  const [error, setError] = useState("");
  const [dragId, setDragId] = useState(null);

  const openNew = () => {
    setEditing(blankCategory());
    setSlugTouched(false);
    setError("");
  };
  const openEdit = (cat) => {
    setEditing(JSON.parse(JSON.stringify(cat)));
    setSlugTouched(true);
    setError("");
  };

  const save = () => {
    const c = { ...editing };
    if (!c.name.trim()) return setError("O nome é obrigatório.");
    c.slug = (c.slug || slugify(c.name)).trim() || slugify(c.name);
    const dup = state.categories.find(
      (x) => x.slug === c.slug && x.id !== c.id
    );
    if (dup) return setError(`Já existe uma categoria com o slug "${c.slug}".`);
    updateState((s) => {
      const i = s.categories.findIndex((x) => x.id === c.id);
      if (i >= 0) s.categories[i] = c;
      else s.categories.push(c);
    });
    setEditing(null);
  };

  const remove = (cat) => {
    if (
      !window.confirm(
        `Excluir a categoria "${cat.name}"? Os artigos não são apagados, apenas ficam sem essa categoria.`
      )
    )
      return;
    updateState((s) => {
      s.categories = s.categories.filter((c) => c.id !== cat.id);
      s.articles.forEach((a) => {
        a.categories = (a.categories || []).filter((slug) => slug !== cat.slug);
      });
    });
  };

  // Reordenação por arrastar e soltar
  const onDrop = (targetId) => {
    if (!dragId || dragId === targetId) return;
    updateState((s) => {
      const from = s.categories.findIndex((c) => c.id === dragId);
      const to = s.categories.findIndex((c) => c.id === targetId);
      if (from < 0 || to < 0) return;
      const [item] = s.categories.splice(from, 1);
      s.categories.splice(to, 0, item);
    });
    setDragId(null);
  };

  const countFor = (slug) =>
    (state.articles || []).filter(
      (a) => a.status === "publicado" && (a.categories || []).includes(slug)
    ).length;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-white">Categorias</h1>
          <p className="mt-1 text-sm text-slate-400">
            {state.categories.length} categoria(s) — arraste para reordenar a grade da home.
          </p>
        </div>
        <button type="button" className={btnPrimary} onClick={openNew}>
          + Nova categoria
        </button>
      </div>

      <Card>
        <ul className="divide-y divide-slate-800">
          {state.categories.map((c, i) => (
            <li
              key={c.id}
              draggable
              onDragStart={() => setDragId(c.id)}
              onDragOver={(e) => e.preventDefault()}
              onDrop={() => onDrop(c.id)}
              className={`flex items-center gap-3 py-3 ${dragId === c.id ? "opacity-40" : ""}`}
            >
              <span className="cursor-grab text-slate-600 hover:text-slate-400" title="Arrastar para reordenar" aria-hidden="true">
                ⠿
              </span>
              <span className="w-6 text-center text-xs text-slate-600">{i + 1}</span>
              <span
                className="flex h-10 w-10 items-center justify-center rounded-lg text-xl"
                style={{ background: `${c.color}22` }}
                aria-hidden="true"
              >
                {c.icon}
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold text-slate-100">{c.name}</p>
                <p className="truncate text-xs text-slate-500">/categoria/{c.slug}{c.parent ? ` · subcategoria de ${c.parent}` : ""} · {countFor(c.slug)} artigo(s)</p>
              </div>
              <div className="flex gap-2">
                <button type="button" className={btnGhost} onClick={() => openEdit(c)}>Editar</button>
                <button type="button" className={btnDanger} onClick={() => remove(c)}>Excluir</button>
              </div>
            </li>
          ))}
        </ul>
      </Card>

      <Modal open={!!editing} onClose={() => setEditing(null)} title={editing?.name ? "Editar categoria" : "Nova categoria"}>
        {editing && (
          <div className="space-y-4">
            {error && <p role="alert" className="rounded-lg border border-rose-500/40 bg-rose-500/10 px-3 py-2 text-sm text-rose-300">{error}</p>}
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="c-name" className={labelCls}>Nome *</label>
                <input id="c-name" className={inputCls} value={editing.name}
                  onChange={(e) => setEditing((c) => ({ ...c, name: e.target.value, slug: slugTouched ? c.slug : slugify(e.target.value) }))} />
              </div>
              <div>
                <label htmlFor="c-slug" className={labelCls}>Slug</label>
                <input id="c-slug" className={inputCls} value={editing.slug}
                  onChange={(e) => { setSlugTouched(true); setEditing((c) => ({ ...c, slug: slugify(e.target.value) })); }} />
              </div>
              <div>
                <label htmlFor="c-icon" className={labelCls}>Ícone (emoji)</label>
                <input id="c-icon" className={inputCls} value={editing.icon} maxLength={4}
                  onChange={(e) => setEditing((c) => ({ ...c, icon: e.target.value }))} />
              </div>
              <div>
                <label htmlFor="c-color" className={labelCls}>Cor</label>
                <input id="c-color" type="color" value={editing.color || "#f59e0b"} className="h-10 w-full rounded-lg border border-slate-700 bg-slate-800"
                  onChange={(e) => setEditing((c) => ({ ...c, color: e.target.value }))} />
              </div>
            </div>
            <div>
              <label htmlFor="c-parent" className={labelCls}>Categoria-mãe (torna esta uma subcategoria)</label>
              <select id="c-parent" className={inputCls} value={editing.parent || ""}
                onChange={(e) => setEditing((c) => ({ ...c, parent: e.target.value }))}>
                <option value="">— nenhuma (categoria principal) —</option>
                {state.categories.filter((x) => x.id !== editing.id && !x.parent).map((x) => (
                  <option key={x.id} value={x.slug}>{x.icon} {x.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="c-desc" className={labelCls}>Descrição</label>
              <textarea id="c-desc" className={inputCls} rows={2} value={editing.description}
                onChange={(e) => setEditing((c) => ({ ...c, description: e.target.value }))} />
            </div>
            <div>
              <label htmlFor="c-img" className={labelCls}>Imagem (URL, opcional)</label>
              <input id="c-img" className={inputCls} value={editing.image || ""}
                onChange={(e) => setEditing((c) => ({ ...c, image: e.target.value }))} placeholder="https://…/categoria.jpg" />
            </div>
            <details className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
              <summary className="cursor-pointer text-sm font-semibold text-slate-200">SEO da categoria</summary>
              <div className="mt-3 space-y-3">
                <div>
                  <label htmlFor="c-seotitle" className={labelCls}>Título SEO</label>
                  <input id="c-seotitle" className={inputCls} value={editing.seo.title || ""}
                    onChange={(e) => setEditing((c) => ({ ...c, seo: { ...c.seo, title: e.target.value } }))} />
                </div>
                <div>
                  <label htmlFor="c-seodesc" className={labelCls}>Meta description</label>
                  <textarea id="c-seodesc" className={inputCls} rows={2} value={editing.seo.description || ""}
                    onChange={(e) => setEditing((c) => ({ ...c, seo: { ...c.seo, description: e.target.value } }))} />
                </div>
                <div>
                  <label htmlFor="c-seokw" className={labelCls}>Palavras-chave</label>
                  <input id="c-seokw" className={inputCls} value={editing.seo.keywords || ""}
                    onChange={(e) => setEditing((c) => ({ ...c, seo: { ...c.seo, keywords: e.target.value } }))} />
                </div>
                <div>
                  <label htmlFor="c-seoog" className={labelCls}>Imagem OG</label>
                  <input id="c-seoog" className={inputCls} value={editing.seo.ogImage || ""}
                    onChange={(e) => setEditing((c) => ({ ...c, seo: { ...c.seo, ogImage: e.target.value } }))} />
                </div>
              </div>
            </details>
            <div className="flex justify-end gap-2">
              <button type="button" className={btnGhost} onClick={() => setEditing(null)}>Cancelar</button>
              <button type="button" className={btnPrimary} onClick={save}>Salvar categoria</button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
