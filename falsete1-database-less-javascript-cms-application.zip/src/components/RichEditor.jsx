// Editor de texto rico basado em contentEditable (sem dependências externas).
// Suporta negrito, itálico, sublinhado, títulos, listas, links, imagens, citações e código.
import { useEffect, useRef } from "react";

const BTNS = [
  { cmd: "bold", label: "B", title: "Negrito", cls: "font-bold" },
  { cmd: "italic", label: "I", title: "Itálico", cls: "italic" },
  { cmd: "underline", label: "U", title: "Sublinhado", cls: "underline" },
  { cmd: "formatBlock", arg: "h2", label: "H2", title: "Título 2" },
  { cmd: "formatBlock", arg: "h3", label: "H3", title: "Título 3" },
  { cmd: "formatBlock", arg: "p", label: "P", title: "Parágrafo" },
  { cmd: "insertUnorderedList", label: "• Lista", title: "Lista com marcadores" },
  { cmd: "insertOrderedList", label: "1. Lista", title: "Lista numerada" },
  { cmd: "formatBlock", arg: "blockquote", label: "❝ Citação", title: "Citação" },
];

export default function RichEditor({ value, onChange, placeholder = "Escreva o conteúdo do artigo…" }) {
  const ref = useRef(null);

  // Sincroniza o valor externo sem quebrar o cursor enquanto digita.
  useEffect(() => {
    const el = ref.current;
    if (el && document.activeElement !== el && el.innerHTML !== (value || "")) {
      el.innerHTML = value || "";
    }
  }, [value]);

  const exec = (cmd, arg = null) => {
    const el = ref.current;
    if (!el) return;
    el.focus();
    document.execCommand(cmd, false, arg);
    onChange(el.innerHTML);
  };

  const addLink = () => {
    const url = window.prompt("URL do link (https://…):");
    if (url) exec("createLink", url);
  };

  const addImage = () => {
    const url = window.prompt("URL da imagem:");
    if (url) exec("insertImage", url);
  };

  return (
    <div className="overflow-hidden rounded-xl border border-slate-300 bg-white dark:border-slate-700 dark:bg-slate-800">
      <div
        className="flex flex-wrap items-center gap-1 border-b border-slate-200 bg-slate-50 px-2 py-1.5 dark:border-slate-700 dark:bg-slate-900"
        role="toolbar"
        aria-label="Formatação do texto"
      >
        {BTNS.map((b) => (
          <button
            key={b.label}
            type="button"
            title={b.title}
            onMouseDown={(e) => e.preventDefault()}
            onClick={() => exec(b.cmd, b.arg)}
            className={`rounded-md px-2 py-1 text-xs text-slate-700 hover:bg-slate-200 dark:text-slate-200 dark:hover:bg-slate-700 ${b.cls || ""}`}
          >
            {b.label}
          </button>
        ))}
        <span className="mx-1 h-5 w-px bg-slate-300 dark:bg-slate-600" aria-hidden="true" />
        <button
          type="button"
          title="Inserir link"
          onMouseDown={(e) => e.preventDefault()}
          onClick={addLink}
          className="rounded-md px-2 py-1 text-xs text-slate-700 hover:bg-slate-200 dark:text-slate-200 dark:hover:bg-slate-700"
        >
          🔗 Link
        </button>
        <button
          type="button"
          title="Inserir imagem"
          onMouseDown={(e) => e.preventDefault()}
          onClick={addImage}
          className="rounded-md px-2 py-1 text-xs text-slate-700 hover:bg-slate-200 dark:text-slate-200 dark:hover:bg-slate-700"
        >
          🖼️ Imagem
        </button>
        <button
          type="button"
          title="Limpar formatação"
          onMouseDown={(e) => e.preventDefault()}
          onClick={() => exec("removeFormat")}
          className="rounded-md px-2 py-1 text-xs text-slate-700 hover:bg-slate-200 dark:text-slate-200 dark:hover:bg-slate-700"
        >
          ⌫ Limpar
        </button>
      </div>
      <div
        ref={ref}
        contentEditable
        suppressContentEditableWarning
        data-placeholder={placeholder}
        onInput={(e) => onChange(e.currentTarget.innerHTML)}
        className="article-content rich-editor max-h-[60vh] overflow-y-auto admin-scroll p-4 text-slate-800 focus:outline-none dark:text-slate-100"
        aria-label="Conteúdo do artigo (editor de texto rico)"
      />
    </div>
  );
}
