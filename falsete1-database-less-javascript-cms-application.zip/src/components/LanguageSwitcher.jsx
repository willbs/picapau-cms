// Seletor de idiomas do menu superior (fica à parte do menu principal).
// Mostra apenas os idiomas habilitados em Painel → Tradução.
import { useEffect, useRef, useState } from "react";
import { enabledLanguages, resolveLang, chooseLang } from "../i18n.js";

export default function LanguageSwitcher({ state }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  const langs = enabledLanguages(state);
  const cur = resolveLang(state);
  const active = langs.find((l) => l.code === cur) || langs[0];

  useEffect(() => {
    const close = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, []);

  if (langs.length < 2 || !active) return null;
  return (
    <div ref={ref} className="relative border-l border-slate-200 pl-2 dark:border-slate-700" data-no-translate data-lang-switcher>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-label={`Idioma: ${active.name}`}
        className="flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 px-2.5 text-sm font-semibold text-slate-700 transition hover:bg-amber-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
      >
        <span aria-hidden="true">{active.flag}</span>
        <span>{active.short}</span>
        <svg className="h-3.5 w-3.5" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
          <path fillRule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 11.17l3.71-3.94a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z" clipRule="evenodd" />
        </svg>
      </button>
      {open && (
        <ul role="listbox" aria-label="Escolher idioma"
          className="absolute right-0 top-full z-50 mt-2 w-52 rounded-xl border border-slate-200 bg-white p-1.5 shadow-xl dark:border-slate-700 dark:bg-slate-900">
          {langs.map((l) => (
            <li key={l.code}>
              <button
                type="button"
                role="option"
                aria-selected={l.code === active.code}
                data-lang={l.code}
                onClick={() => { chooseLang(l.code); setOpen(false); }}
                className={`flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm ${l.code === active.code ? "bg-amber-100 font-bold text-amber-900 dark:bg-amber-500/15 dark:text-amber-300" : "text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800"}`}
              >
                <span aria-hidden="true">{l.flag}</span> {l.name}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
