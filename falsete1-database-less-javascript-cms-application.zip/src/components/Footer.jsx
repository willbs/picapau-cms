// Rodapé configurável (Painel → Rodapé):
// - 8 modelos de layout
// - cada peça pode ser exibida ou retirada (logo, descrição, redes sociais, menus, menu inferior,
//   direitos autorais, botão discreto de acesso, voltar ao topo)
// - texto de direitos autorais editável (variáveis {{ano}} e {{site}}) e menu inferior editável
import { navigate } from "../router.js";
import { articlePath } from "../permalink.js";
import SocialLinks from "./SocialIcon.jsx";
import { cn } from "../utils.js";

export const FOOTER_TEMPLATES = [
  { id: "classico", name: "Clássico escuro", desc: "Marca + colunas de menus; barra inferior com direitos e menu." },
  { id: "centralizado", name: "Centralizado", desc: "Tudo centralizado e empilhado, visual elegante." },
  { id: "minimal", name: "Minimal (uma linha)", desc: "Rodapé fino, em uma única faixa." },
  { id: "colunas", name: "Mega colunas", desc: "Várias colunas com gradiente, ideal para muitos links." },
  { id: "claro", name: "Clássico claro", desc: "Mesmo do clássico, em fundo claro." },
  { id: "cartao", name: "Cartão flutuante", desc: "Rodapé em um cartão arredondado com sombra." },
  { id: "dividido", name: "Dividido", desc: "Metade escura com a marca e metade colorida com os links." },
  { id: "social", name: "Foco nas redes", desc: "Ícones das redes sociais em destaque, grandes e centralizados." },
];

export const FOOTER_PARTS = [
  { id: "brand", label: "Logo e nome do site" },
  { id: "description", label: "Descrição do site" },
  { id: "social", label: "Ícones das redes sociais" },
  { id: "menus", label: "Menus do rodapé (Painel → Menus)" },
  { id: "bottomMenu", label: "Menu inferior" },
  { id: "copyright", label: "Direitos autorais" },
  { id: "access", label: "Botão discreto “Acesso” (login)" },
  { id: "backToTop", label: "Botão voltar ao topo" },
];

export const DEFAULT_FOOTER = {
  template: "classico",
  show: { brand: true, description: true, social: true, menus: true, bottomMenu: true, copyright: true, access: true, backToTop: false },
  copyright: "© {{ano}} {{site}}. CMS sem banco de dados — dados salvos no navegador.",
  bottomMenu: [],
};

export function footerConfig(state) {
  const f = state.footer || {};
  return { ...DEFAULT_FOOTER, ...f, show: { ...DEFAULT_FOOTER.show, ...(f.show || {}) }, bottomMenu: f.bottomMenu || [] };
}

export function renderCopyright(text, state) {
  const site = state.branding?.siteName || state.seo?.ogSiteName || state.seo?.title || "Pica-Pau";
  return String(text || "")
    .replace(/\{\{\s*ano\s*\}\}/g, String(new Date().getFullYear()))
    .replace(/\{\{\s*site\s*\}\}/g, site);
}

function itemUrl(item, state) {
  if (item.type === "category" && item.categorySlug) return `/categoria/${item.categorySlug}`;
  if (item.type === "article" && item.articleSlug) return articlePath(item.articleSlug, state);
  return item.url || "/";
}

function Go({ url, className, children }) {
  const external = /^https?:\/\//i.test(url || "");
  return (
    <a
      href={url}
      className={className}
      {...(external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
      onClick={(e) => {
        if (external) return;
        e.preventDefault();
        navigate(url);
      }}
    >
      {children}
    </a>
  );
}

/** Esconde links de sessões desabilitadas (loja, fórum, podcasts). */
function visibleBottomMenu(cfg, state) {
  return cfg.bottomMenu.filter((i) => {
    if (!i.label || !i.url) return false;
    if (i.url === "/loja" && state.features?.loja === false) return false;
    if (i.url === "/forum" && state.features?.forum === false) return false;
    if (i.url === "/podcasts" && state.features?.podcast === false) return false;
    return true;
  });
}

export default function Footer({ state, preview = false }) {
  const cfg = footerConfig(state);
  const show = cfg.show;
  const tpl = FOOTER_TEMPLATES.some((t) => t.id === cfg.template) ? cfg.template : "classico";
  const light = tpl === "claro" || tpl === "cartao";
  const brandName = state.branding?.siteName || state.seo.ogSiteName || state.seo.title || "Pica-Pau";
  const logo = state.branding?.logo || state.seo.favicon || "/favicon.svg";
  const footerMenus = (state.menus || []).filter((m) => m.location === "footer");
  const bottom = visibleBottomMenu(cfg, state);

  const muted = light ? "text-slate-500" : "text-slate-400";
  const strong = light ? "text-slate-900" : "text-white";
  const linkCls = light ? "text-slate-600 hover:text-amber-600" : "text-slate-400 hover:text-amber-400";

  /* ---------------- peças ---------------- */
  const Brand = ({ center = false, small = false }) =>
    show.brand ? (
      <div className={cn("flex items-center gap-2.5", center && "justify-center")} data-footer-part="brand">
        <img src={logo} alt="" className={cn(small ? "h-6 w-6" : "h-8 w-8", "rounded-lg object-cover")} />
        <span className={cn(small ? "text-sm" : "text-lg", "font-extrabold", strong)}>{brandName}</span>
      </div>
    ) : null;
  const Desc = ({ center = false }) =>
    show.description ? (
      <p className={cn("mt-3 max-w-xs text-sm leading-relaxed", muted, center && "mx-auto")} data-footer-part="description">
        {state.seo.description}
      </p>
    ) : null;
  const Social = ({ className = "mt-5", variant }) =>
    show.social ? (
      <div data-footer-part="social">
        <SocialLinks state={state} className={className} variant={variant || (light ? "light" : "dark")} />
      </div>
    ) : null;
  const Menus = ({ inline = false, center = false }) => {
    if (!show.menus || !footerMenus.length) return null;
    if (inline) {
      const links = footerMenus.flatMap((m) => m.items || []).slice(0, 12);
      return (
        <nav aria-label="Menu do rodapé" data-footer-part="menus" className={cn("flex flex-wrap gap-x-5 gap-y-2 text-sm", center && "justify-center")}>
          {links.map((i) => <Go key={i.id} url={itemUrl(i, state)} className={linkCls}>{i.label}</Go>)}
        </nav>
      );
    }
    return footerMenus.map((menu) => (
      <nav key={menu.id} aria-label={menu.name} data-footer-part="menus">
        <p className={cn("mb-3 text-xs font-bold uppercase tracking-wider", light ? "text-slate-400" : "text-slate-500")}>{menu.name}</p>
        <ul className="space-y-2">
          {(menu.items || []).slice(0, 8).map((i) => (
            <li key={i.id}><Go url={itemUrl(i, state)} className={cn("text-sm transition", linkCls)}>{i.label}</Go></li>
          ))}
        </ul>
      </nav>
    ));
  };
  const Bottom = ({ center = false }) =>
    show.bottomMenu && bottom.length ? (
      <nav aria-label="Menu inferior" data-footer-part="bottomMenu" className={cn("flex flex-wrap items-center gap-x-1 gap-y-1", center && "justify-center")}>
        {bottom.map((i) => (
          <Go key={i.id} url={i.url} className={cn("rounded-md px-2 py-1 text-xs transition", light ? "text-slate-500 hover:bg-slate-200 hover:text-slate-800" : "text-slate-400 hover:bg-slate-800 hover:text-white")}>
            {i.label}
          </Go>
        ))}
      </nav>
    ) : null;
  const Copy = () =>
    show.copyright && cfg.copyright ? (
      <p className={cn("text-xs", light ? "text-slate-500" : "text-slate-500")} data-footer-part="copyright">{renderCopyright(cfg.copyright, state)}</p>
    ) : null;
  // Link do Feed — sempre ao lado do botão "Acesso"
  const FeedLink = () => (
    <a
      href="/feed"
      onClick={(e) => { e.preventDefault(); navigate("/feed"); }}
      className={cn("rounded-md px-2 py-1 text-xs font-semibold transition", light ? "text-slate-500 hover:bg-slate-200 hover:text-slate-800" : "text-slate-400 hover:bg-slate-800 hover:text-white")}
      data-footer-part="feed"
    >
      📡 Feed
    </a>
  );
  const AccessOnly = () =>
    show.access ? (
      <a
        href="/login"
        onClick={(e) => { e.preventDefault(); navigate("/login"); }}
        className={cn("rounded-md px-2 py-1 text-xs transition", light ? "text-slate-400 hover:bg-slate-200 hover:text-slate-700" : "text-slate-500 hover:bg-slate-800 hover:text-slate-300")}
        title="Acesso restrito"
        data-footer-part="access"
      >
        Acesso
      </a>
    ) : null;
  const Access = () => (
    <>
      <FeedLink />
      <AccessOnly />
    </>
  );
  const Top = () =>
    show.backToTop ? (
      <button type="button" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} data-footer-part="backToTop"
        className={cn("rounded-md px-2 py-1 text-xs transition", light ? "text-slate-500 hover:bg-slate-200" : "text-slate-400 hover:bg-slate-800 hover:text-white")}>
        ↑ Topo
      </button>
    ) : null;

  const BottomBar = ({ center = false, border = true }) => (
    <div className={cn(border && (light ? "border-t border-slate-200" : "border-t border-slate-800/80"))}>
      <div className={cn("mx-auto flex max-w-7xl flex-wrap items-center gap-3 px-4 py-4", center ? "flex-col justify-center text-center" : "justify-between")}>
        <Copy />
        <div className={cn("flex flex-wrap items-center gap-2", center && "justify-center")}>
          <Bottom center={center} />
          <Access />
          <Top />
        </div>
      </div>
    </div>
  );

  /* ---------------- 8 modelos ---------------- */
  let body;
  if (tpl === "centralizado") {
    body = (
      <footer className="mt-16 bg-slate-950 text-slate-300">
        <div className="mx-auto flex max-w-4xl flex-col items-center px-4 py-14 text-center">
          <Brand center />
          <Desc center />
          <Social className="mt-6 justify-center" />
          <div className="mt-8"><Menus inline center /></div>
        </div>
        <BottomBar center />
      </footer>
    );
  } else if (tpl === "minimal") {
    body = (
      <footer className="mt-16 border-t border-slate-800 bg-slate-950 text-slate-300">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-4 py-4">
          <div className="flex flex-wrap items-center gap-4"><Brand small /><Copy /></div>
          <Menus inline />
          <div className="flex flex-wrap items-center gap-2"><Social className="" /><Bottom /><Access /><Top /></div>
        </div>
      </footer>
    );
  } else if (tpl === "colunas") {
    body = (
      <footer className="mt-16 bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-950 text-slate-300">
        <div className="mx-auto grid max-w-7xl gap-10 px-4 py-16 sm:grid-cols-2 lg:grid-cols-5">
          <div className="lg:col-span-2"><Brand /><Desc /><Social /></div>
          <Menus />
          {show.bottomMenu && bottom.length > 0 && (
            <nav aria-label="Atalhos" data-footer-part="bottomMenu">
              <p className="mb-3 text-xs font-bold uppercase tracking-wider text-slate-500">Atalhos</p>
              <ul className="space-y-2">{bottom.map((i) => <li key={i.id}><Go url={i.url} className={cn("text-sm", linkCls)}>{i.label}</Go></li>)}</ul>
            </nav>
          )}
        </div>
        <div className="border-t border-white/10">
          <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-4"><Copy /><div className="flex gap-2"><Access /><Top /></div></div>
        </div>
      </footer>
    );
  } else if (tpl === "cartao") {
    body = (
      <footer className="mt-16 px-4 pb-6">
        <div className="mx-auto max-w-6xl overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-xl dark:border-slate-200">
          <div className="grid gap-10 p-8 md:grid-cols-3">
            <div><Brand /><Desc /><Social /></div>
            <Menus />
          </div>
          <BottomBar />
        </div>
      </footer>
    );
  } else if (tpl === "dividido") {
    body = (
      <footer className="mt-16 text-slate-300">
        <div className="grid md:grid-cols-2">
          <div className="bg-slate-950 px-8 py-12"><div className="ml-auto max-w-lg"><Brand /><Desc /><Social /></div></div>
          <div className="bg-amber-500 px-8 py-12 text-slate-950">
            <div className="grid max-w-lg gap-8 sm:grid-cols-2 [&_a]:!text-slate-900 [&_a:hover]:!underline [&_p]:!text-slate-800">
              <Menus />
              {show.bottomMenu && bottom.length > 0 && (
                <nav aria-label="Atalhos" data-footer-part="bottomMenu">
                  <p className="mb-3 text-xs font-bold uppercase tracking-wider">Atalhos</p>
                  <ul className="space-y-2">{bottom.map((i) => <li key={i.id}><Go url={i.url} className="text-sm font-semibold">{i.label}</Go></li>)}</ul>
                </nav>
              )}
            </div>
          </div>
        </div>
        <div className="bg-slate-900">
          <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-4"><Copy /><div className="flex gap-2"><Access /><Top /></div></div>
        </div>
      </footer>
    );
  } else if (tpl === "social") {
    body = (
      <footer className="mt-16 bg-slate-950 text-slate-300">
        <div className="mx-auto flex max-w-5xl flex-col items-center px-4 py-14 text-center">
          <Brand center />
          {show.social && <p className="mt-4 text-sm font-semibold uppercase tracking-[0.25em] text-amber-400">Siga nas redes</p>}
          <Social className="mt-5 justify-center" variant="big" />
          <Desc center />
          <div className="mt-6"><Menus inline center /></div>
        </div>
        <BottomBar center />
      </footer>
    );
  } else {
    // "classico" e "claro"
    body = (
      <footer className={cn("mt-16", light ? "border-t border-slate-200 bg-slate-50 text-slate-700" : "border-t border-slate-800 bg-slate-950 text-slate-300")}>
        <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 sm:grid-cols-2 lg:grid-cols-4">
          <div><Brand /><Desc /><Social className="mt-5 max-w-xs" /></div>
          <Menus />
        </div>
        <BottomBar />
      </footer>
    );
  }

  return (
    <div data-footer-template={tpl} className={preview ? "pointer-events-none select-none" : ""}>
      {body}
    </div>
  );
}
