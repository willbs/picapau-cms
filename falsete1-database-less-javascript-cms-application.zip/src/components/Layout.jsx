// Layout público: cabeçalho com menus (simples + mega menu), rodapé com botão
// discreto de acesso à área restrita e estrutura da página.
import { useEffect, useRef, useState } from "react";
import { navigate } from "../router.js";
import { articlePath } from "../permalink.js";
import Footer from "./Footer.jsx";
import LanguageSwitcher from "./LanguageSwitcher.jsx";
import { getCurrentUser, destroySession, addLog } from "../auth.js";
import { PrivacyGate } from "../admin/SecurityExtras.jsx";
import { goToMyProfile } from "../userProfile.js";

/** Links do usuário logado no menu do celular. */
function MobileUserLinks({ state, onDone }) {
  const user = getCurrentUser();
  if (!user) return null;
  const forumOn = state?.features?.forum !== false;
  const cls = "block rounded-lg px-3 py-2 text-sm font-semibold hover:bg-slate-100 dark:hover:bg-slate-800";
  return (
    <div className="mb-2 border-b border-slate-200 pb-2 dark:border-slate-800" data-mobile-user>
      <p className="truncate px-3 py-1 text-xs text-slate-500" data-no-translate>{user.email}</p>
      {forumOn && (
        <a href="/forum/u" className={`${cls} text-emerald-700 dark:text-emerald-300`} data-my-profile
          onClick={(e) => { e.preventDefault(); onDone(); goToMyProfile(user); }}>👤 Meu perfil</a>
      )}
      {user.role === "admin" && (
        <a href="/admin" className={`${cls} text-indigo-600 dark:text-indigo-300`} data-admin-link
          onClick={(e) => { e.preventDefault(); onDone(); navigate("/admin"); }}>⚙️ Painel</a>
      )}
      <button type="button" className={`${cls} w-full text-left text-rose-600 dark:text-rose-300`}
        onClick={() => { addLog("logout", `Logout pelo site (${user.email})`); destroySession(); onDone(); window.dispatchEvent(new Event("cms:changed")); }}>
        Sair
      </button>
    </div>
  );
}

/** Usuário logado no site: editores ficam no front-end; administradores veem o atalho do painel. */
function UserChip({ state }) {
  const user = getCurrentUser();
  if (!user) return null;
  const forumOn = state?.features?.forum !== false;
  const logout = () => {
    addLog("logout", `Logout pelo site (${user.email})`);
    destroySession();
    window.dispatchEvent(new Event("cms:changed"));
  };
  return (
    <div className="hidden items-center gap-1 rounded-lg border border-slate-200 py-1 pl-2 pr-1 text-xs dark:border-slate-700 md:flex" data-user-chip={user.role}>
      <span className="flex h-6 w-6 items-center justify-center rounded-full bg-amber-500/20 font-bold text-amber-700 dark:text-amber-300" aria-hidden="true">
        {user.email[0].toUpperCase()}
      </span>
      <span className="max-w-32 truncate text-slate-600 dark:text-slate-300" data-no-translate title={user.email}>{user.email}</span>
      {/* 1) página do usuário dentro do site */}
      {forumOn && (
        <a href="/forum/u" onClick={(e) => { e.preventDefault(); goToMyProfile(user); }} data-my-profile
          className="rounded-md px-2 py-1 font-semibold text-emerald-700 hover:bg-emerald-50 dark:text-emerald-300 dark:hover:bg-slate-800">
          👤 Meu perfil
        </a>
      )}
      {/* 2) back-end — somente administradores */}
      {user.role === "admin" && (
        <a href="/admin" onClick={(e) => { e.preventDefault(); navigate("/admin"); }} data-admin-link
          className="rounded-md px-2 py-1 font-semibold text-indigo-600 hover:bg-indigo-50 dark:text-indigo-300 dark:hover:bg-slate-800">
          ⚙️ Painel
        </a>
      )}
      <button type="button" onClick={logout} className="rounded-md px-2 py-1 font-semibold text-rose-600 hover:bg-rose-50 dark:text-rose-300 dark:hover:bg-slate-800">Sair</button>
    </div>
  );
}

export { Footer };
import { effectiveTheme, toggleTheme } from "../theme.js";
import { cn, TYPE_ICONS, TYPE_LABELS, formatDate, excerptFromHtml } from "../utils.js";

/** Botão para alternar entre tema claro e escuro (persistido no LocalStorage). */
export function ThemeToggle({ className }) {
  const [dark, setDark] = useState(() => effectiveTheme() === "dark");
  const onToggle = () => {
    const next = toggleTheme();
    setDark(next === "dark");
  };
  return (
    <button
      type="button"
      onClick={onToggle}
      aria-pressed={dark}
      aria-label={dark ? "Mudar para tema claro" : "Mudar para tema escuro"}
      title={dark ? "Tema claro" : "Tema escuro"}
      className={cn(
        "flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 text-slate-600 transition hover:bg-amber-50 hover:text-amber-600 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800",
        className
      )}
    >
      {dark ? (
        <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
          <circle cx="12" cy="12" r="4" />
          <path d="M12 2v2m0 16v2M4.9 4.9l1.4 1.4m11.4 11.4 1.4 1.4M2 12h2m16 0h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" />
        </svg>
      ) : (
        <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
          <path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z" />
        </svg>
      )}
    </button>
  );
}

/** Resolve a URL final de um item de menu. */
export function itemUrl(item, state) {
  if (item.type === "category" && item.categorySlug) return `/categoria/${item.categorySlug}`;
  if (item.type === "article" && item.articleSlug) return articlePath(item.articleSlug, state);
  return item.url || "/";
}

function GoLink({ url, children, className, onNavigate }) {
  return (
    <a
      href={url}
      className={className}
      onClick={(e) => {
        e.preventDefault();
        onNavigate ? onNavigate(url) : navigate(url);
      }}
    >
      {children}
    </a>
  );
}

/* ------------------------------ Itens de navegação ------------------------------ */

function NavItem({ item, state, onNavigate }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  const isMega = item.mega || item.type === "mega";
  const hasChildren = !isMega && (item.children || []).length > 0;

  useEffect(() => {
    const onClick = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  if (isMega) {
    return (
      <div
        ref={ref}
        className="relative"
        onMouseEnter={() => setOpen(true)}
        onMouseLeave={() => setOpen(false)}
      >
        <button
          type="button"
          aria-expanded={open}
          aria-haspopup="true"
          onClick={() => setOpen((v) => !v)}
          onFocus={() => setOpen(true)}
          onKeyDown={(e) => e.key === "Escape" && setOpen(false)}
          className="flex items-center gap-1 rounded-lg px-3 py-2 text-sm font-medium text-slate-700 hover:bg-amber-50 hover:text-amber-700 dark:text-slate-200 dark:hover:bg-slate-800"
        >
          {item.label}
          <svg className={cn("h-3.5 w-3.5 transition-transform", open && "rotate-180")} viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
            <path fillRule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 11.17l3.71-3.94a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z" clipRule="evenodd" />
          </svg>
        </button>
        {open && (
          <div className="absolute left-1/2 top-full z-40 w-[min(92vw,760px)] -translate-x-1/2 pt-3">
            <div className="grid gap-6 rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl dark:border-slate-700 dark:bg-slate-900 sm:grid-cols-2 lg:grid-cols-3">
              {(item.columns || []).map((col) => (
                <div key={col.id}>
                  <p className="mb-2 text-xs font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">{col.title}</p>
                  <ul className="space-y-1">
                    {(col.links || []).map((l) => {
                      const url = itemUrl({ ...l, type: l.type || "link" }, state);
                      return (
                        <li key={l.id}>
                          <GoLink
                            url={url}
                            onNavigate={(u) => { setOpen(false); onNavigate?.(u); }}
                            className="group flex gap-3 rounded-xl p-2 hover:bg-amber-50 dark:hover:bg-slate-800"
                          >
                            {l.image && (
                              <img src={l.image} alt="" loading="lazy" className="h-10 w-14 shrink-0 rounded-lg object-cover" />
                            )}
                            <span className="min-w-0">
                              <span className="block truncate text-sm font-semibold text-slate-800 group-hover:text-amber-700 dark:text-slate-100">
                                {l.label}
                              </span>
                              {l.desc && (
                                <span className="block truncate text-xs text-slate-400">{l.desc}</span>
                              )}
                            </span>
                          </GoLink>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }

  if (hasChildren) {
    return (
      <div
        ref={ref}
        className="relative"
        onMouseEnter={() => setOpen(true)}
        onMouseLeave={() => setOpen(false)}
      >
        <button
          type="button"
          aria-expanded={open}
          aria-haspopup="true"
          onClick={() => setOpen((v) => !v)}
          onFocus={() => setOpen(true)}
          className="flex items-center gap-1 rounded-lg px-3 py-2 text-sm font-medium text-slate-700 hover:bg-amber-50 hover:text-amber-700 dark:text-slate-200 dark:hover:bg-slate-800"
        >
          {item.label}
          <svg className={cn("h-3.5 w-3.5 transition-transform", open && "rotate-180")} viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
            <path fillRule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 11.17l3.71-3.94a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z" clipRule="evenodd" />
          </svg>
        </button>
        {open && (
          <div className="absolute left-0 top-full z-40 min-w-56 pt-2">
            <ul className="rounded-xl border border-slate-200 bg-white p-2 shadow-xl dark:border-slate-700 dark:bg-slate-900">
              {item.children.map((c) => (
                <li key={c.id} className="relative">
                  <SubItem item={c} state={state} onNavigate={(u) => { setOpen(false); onNavigate?.(u); }} depth={1} />
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    );
  }

  return (
    <GoLink
      url={itemUrl(item, state)}
      onNavigate={onNavigate}
      className="rounded-lg px-3 py-2 text-sm font-medium text-slate-700 hover:bg-amber-50 hover:text-amber-700 dark:text-slate-200 dark:hover:bg-slate-800"
    >
      {item.label}
    </GoLink>
  );
}

/** Subitem com suporte a mais um nível de profundidade (3 níveis no total). */
function SubItem({ item, state, onNavigate, depth }) {
  const [open, setOpen] = useState(false);
  const hasChildren = (item.children || []).length > 0 && depth < 3;
  if (hasChildren) {
    return (
      <div className="relative" onMouseEnter={() => setOpen(true)} onMouseLeave={() => setOpen(false)}>
        <button
          type="button"
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
          className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-sm text-slate-700 hover:bg-amber-50 hover:text-amber-700 dark:text-slate-200 dark:hover:bg-slate-800"
        >
          {item.label}
          <span aria-hidden="true">›</span>
        </button>
        {open && (
          <ul className="absolute left-full top-0 z-40 min-w-48 rounded-xl border border-slate-200 bg-white p-2 shadow-xl dark:border-slate-700 dark:bg-slate-900">
            {item.children.map((c) => (
              <li key={c.id}>
                <GoLink
                  url={itemUrl(c, state)}
                  onNavigate={onNavigate}
                  className="block rounded-lg px-3 py-2 text-sm text-slate-700 hover:bg-amber-50 hover:text-amber-700 dark:text-slate-200 dark:hover:bg-slate-800"
                >
                  {c.label}
                </GoLink>
              </li>
            ))}
          </ul>
        )}
      </div>
    );
  }
  return (
    <GoLink
      url={itemUrl(item, state)}
      onNavigate={onNavigate}
      className="block rounded-lg px-3 py-2 text-sm text-slate-700 hover:bg-amber-50 hover:text-amber-700 dark:text-slate-200 dark:hover:bg-slate-800"
    >
      {item.label}
    </GoLink>
  );
}

/* ------------------------------ Header e Footer ------------------------------ */

export function Header({ state }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const headerMenus = (state.menus || []).filter((m) => m.location === "header");
  const main = headerMenus.find((m) => m.isMain) || headerMenus[0];
  const brand = state.branding?.siteName || state.seo.ogSiteName || state.seo.title || "Pica-Pau";
  const logo = state.branding?.logo || state.seo.favicon || "/favicon.svg";
  const podcastOn = state.features?.podcast !== false;
  const lojaOn = state.features?.loja !== false;
  const forumOn = state.features?.forum !== false;

  return (
    <header className="sticky top-0 z-30 border-b border-slate-200/70 bg-white/85 backdrop-blur-md dark:border-slate-800 dark:bg-slate-950/80">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4">
        <GoLink url="/" className="flex items-center gap-2.5">
          <img src={logo} alt="" className="h-9 w-9 rounded-lg object-cover shadow" />
          <span className="text-lg font-extrabold tracking-tight text-slate-900 dark:text-white">{brand}</span>
        </GoLink>

        {/* Navegação desktop */}
        <nav className="hidden items-center gap-1 lg:flex" aria-label="Menu principal">
          {(main?.items || []).map((item) => (
            <NavItem key={item.id} item={item} state={state} />
          ))}
          {podcastOn && (
            <GoLink
              url="/podcasts"
              className="rounded-lg px-3 py-2 text-sm font-semibold text-emerald-700 hover:bg-emerald-50 dark:text-emerald-300 dark:hover:bg-slate-800"
            >
              🎧 Podcasts
            </GoLink>
          )}
          {lojaOn && (
<GoLink
            url="/loja"
            className="rounded-lg px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-amber-50 hover:text-amber-700 dark:text-slate-200 dark:hover:bg-slate-800"
          >
            🛒 Loja
          </GoLink>
)}
          {forumOn && (
<GoLink
            url="/forum"
            className="rounded-lg px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-amber-50 hover:text-amber-700 dark:text-slate-200 dark:hover:bg-slate-800"
          >
            💬 Fórum
          </GoLink>
)}
        </nav>

        <div className="flex items-center gap-2">
          <UserChip state={state} />
          {/* seletor de idiomas: à parte do menu principal */}
          <LanguageSwitcher state={state} />
          <ThemeToggle />
          <GoLink
            url="/feed"
            className="hidden rounded-lg bg-amber-500 px-3.5 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-amber-600 sm:block"
            data-explore
          >
            Explorar
          </GoLink>
          {/* Hambúrguer mobile */}
          <button
            type="button"
            className="rounded-lg p-2 text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800 lg:hidden"
            aria-expanded={mobileOpen}
            aria-label="Abrir menu"
            onClick={() => setMobileOpen((v) => !v)}
          >
            <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
              {mobileOpen ? <path d="M6 6l12 12M18 6L6 18" /> : <path d="M4 7h16M4 12h16M4 17h16" />}
            </svg>
          </button>
        </div>
      </div>

      {/* Menu mobile */}
      {mobileOpen && (
        <nav className="border-t border-slate-200 bg-white px-4 py-3 dark:border-slate-800 dark:bg-slate-950 lg:hidden" aria-label="Menu móvel">
          <MobileUserLinks state={state} onDone={() => setMobileOpen(false)} />
          <ul className="space-y-1">
            {podcastOn && (
              <li>
                <GoLink
                  url="/podcasts"
                  onNavigate={() => setMobileOpen(false)}
                  className="block rounded-lg px-3 py-2 text-sm font-semibold text-emerald-700 hover:bg-emerald-50 dark:text-emerald-300 dark:hover:bg-slate-800"
                >
                  🎧 Podcasts
                </GoLink>
              </li>
            )}
            {lojaOn && (
<li>
              <GoLink
                url="/loja"
                onNavigate={() => setMobileOpen(false)}
                className="block rounded-lg px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-amber-50 dark:text-slate-200 dark:hover:bg-slate-800"
              >
                🛒 Loja
              </GoLink>
            </li>
)}
            {forumOn && (
<li>
              <GoLink
                url="/forum"
                onNavigate={() => setMobileOpen(false)}
                className="block rounded-lg px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-amber-50 dark:text-slate-200 dark:hover:bg-slate-800"
              >
                💬 Fórum
              </GoLink>
            </li>
)}
            {(main?.items || []).map((item) => (
              <li key={item.id}>
                {item.mega || item.type === "mega" ? (
                  <details className="group">
                    <summary className="flex cursor-pointer list-none items-center justify-between rounded-lg px-3 py-2 text-sm font-medium text-slate-700 hover:bg-amber-50 dark:text-slate-200">
                      {item.label}
                      <span aria-hidden="true">▾</span>
                    </summary>
                    <div className="ml-3 mt-1 space-y-1 border-l-2 border-amber-200 pl-3">
                      {(item.columns || []).flatMap((col) => col.links || []).map((l) => (
                        <GoLink
                          key={l.id}
                          url={itemUrl({ ...l, type: l.type || "link" }, state)}
                          onNavigate={() => setMobileOpen(false)}
                          className="block rounded-lg px-2 py-1.5 text-sm text-slate-600 hover:bg-amber-50 dark:text-slate-300"
                        >
                          {l.label}
                        </GoLink>
                      ))}
                    </div>
                  </details>
                ) : (
                  <GoLink
                    url={itemUrl(item, state)}
                    onNavigate={() => setMobileOpen(false)}
                    className="block rounded-lg px-3 py-2 text-sm font-medium text-slate-700 hover:bg-amber-50 dark:text-slate-200"
                  >
                    {item.label}
                  </GoLink>
                )}
              </li>
            ))}
          </ul>
        </nav>
      )}
    </header>
  );
}

export default function PublicLayout({ state, children }) {
  return (
    <div className="flex min-h-screen flex-col">
      <a
        href="#conteudo-principal"
        className="sr-only focus:not-sr-only focus:absolute focus:z-50 focus:bg-amber-500 focus:px-4 focus:py-2 focus:text-white"
      >
        Pular para o conteúdo
      </a>
      {/* aceite obrigatório das políticas de privacidade também para quem está logado no site */}
      <PrivacyGate state={state} />
      <Header state={state} />
      <main id="conteudo-principal" className="flex-1">
        {children}
      </main>
      <Footer state={state} />
    </div>
  );
}

/* ------------------------------ Cards reutilizáveis ------------------------------ */

export function CategoryCard({ cat, count }) {
  return (
    <GoLink
      url={`/categoria/${cat.slug}`}
      className="group relative flex flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition-all hover:-translate-y-1 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900"
      style={{ borderTopColor: cat.color, borderTopWidth: 3 }}
    >
      <span
        className="mb-3 flex h-12 w-12 items-center justify-center rounded-xl text-2xl shadow-inner"
        style={{ background: `${cat.color}1f` }}
        aria-hidden="true"
      >
        {cat.icon}
      </span>
      <h3 className="text-base font-bold text-slate-900 group-hover:text-amber-600 dark:text-white">{cat.name}</h3>
      <p className="mt-1 line-clamp-2 flex-1 text-sm text-slate-500 dark:text-slate-400">{cat.description}</p>
      <p className="mt-3 text-xs font-semibold text-slate-400">
        {count} artigo{count === 1 ? "" : "s"} →
      </p>
    </GoLink>
  );
}

export function ArticleCard({ article }) {
  return (
    <GoLink
      url={articlePath(article)}
      className="group flex flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm transition-all hover:-translate-y-1 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900"
    >
      <div className="relative h-44 overflow-hidden bg-slate-100 dark:bg-slate-800">
        {article.cover ? (
          <img src={article.cover} alt="" loading="lazy" className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" />
        ) : (
          <span className="flex h-full w-full items-center justify-center text-5xl" aria-hidden="true">{TYPE_ICONS[article.type]}</span>
        )}
        <span className="absolute left-3 top-3 rounded-full bg-black/60 px-2 py-0.5 text-xs font-semibold text-white backdrop-blur">
          {TYPE_ICONS[article.type]} {TYPE_LABELS[article.type]}
        </span>
      </div>
      <div className="flex flex-1 flex-col p-4">
        <h3 className="font-bold leading-snug text-slate-900 group-hover:text-amber-600 dark:text-white">
          {article.title}
        </h3>
        <p className="mt-1.5 line-clamp-2 flex-1 text-sm text-slate-500 dark:text-slate-400">
          {article.excerpt || excerptFromHtml(article.content)}
        </p>
        <p className="mt-3 text-xs text-slate-400">{formatDate(article.date)} · {article.author}</p>
      </div>
    </GoLink>
  );
}
