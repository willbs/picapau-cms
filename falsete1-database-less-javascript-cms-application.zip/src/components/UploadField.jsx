// Botão de upload de arquivo (sem back-end): converte para DataURL e chama onUploaded.
// kind: "image" | "audio" | "video" — define compressão e validação.
import { useRef, useState } from "react";
import { imageFileToDataUrl, mediaFileToDataUrl } from "../upload.js";
import { cn } from "../utils.js";

export default function UploadField({
  kind = "image",
  accept,
  onUploaded,
  label = "Upload",
  maxDim,
  multiple = false,
  className,
}) {
  const ref = useRef(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const pick = async (e) => {
    const files = Array.from(e.target.files || []);
    e.target.value = "";
    if (!files.length) return;
    setBusy(true);
    setErr("");
    try {
      for (const f of files) {
        const data =
          kind === "image"
            ? await imageFileToDataUrl(f, maxDim ? { maxDim } : {})
            : await mediaFileToDataUrl(f);
        onUploaded(data, f);
      }
    } catch (err2) {
      setErr(err2.message || "Falha no upload.");
    }
    setBusy(false);
  };

  return (
    <div className={cn("flex flex-col items-start gap-1", className)}>
      <input
        ref={ref}
        type="file"
        className="hidden"
        accept={accept || (kind === "image" ? "image/*" : kind === "audio" ? "audio/*" : "video/*")}
        multiple={multiple}
        onChange={pick}
        aria-label={label}
      />
      <button
        type="button"
        disabled={busy}
        onClick={() => ref.current?.click()}
        className="inline-flex items-center gap-1.5 rounded-lg border border-dashed border-slate-500 bg-slate-800/60 px-3 py-2 text-xs font-semibold text-slate-300 transition hover:border-amber-500 hover:text-amber-300 disabled:opacity-50"
      >
        {busy ? "⏳ Enviando…" : `📤 ${label}`}
      </button>
      {err && (
        <p role="alert" className="max-w-72 text-xs text-rose-400">
          {err}
        </p>
      )}
    </div>
  );
}
