// Ícone oficial de rede social (SVG 24x24) + lista de links sociais para o rodapé.
import { NETWORK_BY_ID } from "../data/socialNetworks.js";

export function SocialIcon({ network, className = "h-5 w-5", color }) {
  const n = NETWORK_BY_ID[network];
  if (!n) return null;
  const fill = color || "currentColor";
  if (n.path === "BUSINESS") {
    // WhatsApp Business: balão do WhatsApp com o "B" característico
    return (
      <svg viewBox="0 0 24 24" className={className} role="img" aria-hidden="true">
        <path fill={fill} d="M12 0C5.373 0 0 5.373 0 12c0 2.117.549 4.106 1.512 5.833L0 24l6.335-1.652A11.95 11.95 0 0 0 12 24c6.627 0 12-5.373 12-12S18.627 0 12 0z" />
        <path fill="#fff" d="M8.6 6.4h4.2c1.9 0 3.1.95 3.1 2.5 0 1.05-.6 1.8-1.5 2.1 1.15.25 1.9 1.1 1.9 2.3 0 1.75-1.35 2.8-3.45 2.8H8.6V6.4zm2.1 1.75v2.35h1.85c.8 0 1.25-.45 1.25-1.2 0-.72-.45-1.15-1.25-1.15H10.7zm0 4v2.7h2.05c.92 0 1.45-.5 1.45-1.35 0-.85-.53-1.35-1.45-1.35H10.7z" />
      </svg>
    );
  }
  return (
    <svg viewBox="0 0 24 24" className={className} role="img" aria-hidden="true">
      <path fill={fill} d={n.path} />
    </svg>
  );
}

/** Links das redes sociais habilitadas (abrem em nova aba). */
export default function SocialLinks({ state, className = "", variant = "dark" }) {
  const variantCls = {
    dark: "h-9 w-9 rounded-lg bg-slate-800/80 text-slate-300",
    light: "h-9 w-9 rounded-lg bg-slate-200 text-slate-600",
    big: "h-12 w-12 rounded-full bg-slate-800 text-slate-200",
  }[variant] || "h-9 w-9 rounded-lg bg-slate-800/80 text-slate-300";
  const social = state.social;
  if (!social || social.enabled === false) return null;
  const items = (social.items || []).filter((i) => i.enabled && i.url && NETWORK_BY_ID[i.network]);
  if (!items.length) return null;
  return (
    <ul className={`flex flex-wrap gap-2 ${className}`} aria-label="Redes sociais" data-social-links>
      {items.map((i) => {
        const n = NETWORK_BY_ID[i.network];
        return (
          <li key={i.id}>
            <a
              href={i.url}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={`${n.name} (abre em nova aba)`}
              title={n.name}
              data-network={n.id}
              className={`group flex items-center justify-center transition hover:-translate-y-0.5 hover:text-white ${variantCls}`}
              style={{ "--brand": n.color }}
              onMouseEnter={(e) => { e.currentTarget.style.background = n.color; e.currentTarget.style.color = n.color === "#FFFC00" ? "#111" : "#fff"; }}
              onMouseLeave={(e) => { e.currentTarget.style.background = ""; e.currentTarget.style.color = ""; }}
            >
              <SocialIcon network={n.id} className={variant === "big" ? "h-6 w-6" : "h-[18px] w-[18px]"} />
            </a>
          </li>
        );
      })}
    </ul>
  );
}
