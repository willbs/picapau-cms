// Campos específicos de mídia por tipo de artigo (imagem, vídeo ou áudio).
// Cada campo aceita URL externa OU upload de arquivo (salvo como DataURL no LocalStorage).
import UploadField from "./UploadField.jsx";
import { TYPE_ICONS } from "../utils.js";
import { formatBytes as fb } from "../upload.js";

const inputCls =
  "w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 placeholder-slate-400 focus:border-amber-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white";
const labelCls = "mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400";

function Field({ label, children, hint }) {
  return (
    <div>
      <label className={labelCls}>{label}</label>
      {children}
      {hint && <p className="mt-1 text-xs text-slate-400">{hint}</p>}
    </div>
  );
}

/** Linha de URL + botão de upload + prévia + limpar. */
function UrlWithUpload({ value, onChange, kind, accept, placeholder, preview = "image" }) {
  return (
    <div>
      <div className="flex flex-wrap items-center gap-2">
        <input
          className={`${inputCls} min-w-0 flex-1`}
          value={value || ""}
          placeholder={placeholder}
          onChange={(e) => onChange(e.target.value)}
        />
        <UploadField kind={kind} accept={accept} label="Upload" onUploaded={(d) => onChange(d)} />
        {value && (
          <button
            type="button"
            onClick={() => onChange("")}
            className="rounded-lg border border-rose-500/40 px-2 py-2 text-xs text-rose-300 hover:bg-rose-500/10"
            title="Remover"
          >
            🗑
          </button>
        )}
      </div>
      {value && (
        <div className="mt-2">
          {preview === "image" && (
            <img src={value} alt="Prévia" className="h-24 rounded-lg border border-slate-700 object-cover" />
          )}
          {preview === "audio" && <audio controls src={value} className="w-full" style={{ height: 36 }} />}
          {preview === "video" && <video controls src={value} className="h-28 rounded-lg border border-slate-700" />}
          {String(value).startsWith("data:") && (
            <p className="mt-1 text-[11px] text-emerald-400">
              📦 arquivo enviado — {fb(Math.round((String(value).length * 3) / 4))} armazenado localmente
            </p>
          )}
        </div>
      )}
    </div>
  );
}

/**
 * media: objeto com as chaves image | video | audio (cada uma um sub-objeto).
 * type: "image" | "video" | "audio"
 */
export default function MediaFields({ type, media, onChange }) {
  const set = (patch) => onChange(type, { ...media[type], ...patch });
  const m = media[type] || {};

  if (type === "image") {
    return (
      <div className="grid gap-4 md:grid-cols-2">
        <div className="md:col-span-2">
          <Field label="URL da imagem ou upload" hint="Aceita URL externa, caminho local (/imagens/foto.jpg) ou arquivo enviado">
            <UrlWithUpload
              value={m.url}
              onChange={(v) => set({ url: v })}
              kind="image"
              placeholder="https://…/imagem.jpg"
              preview="image"
            />
          </Field>
        </div>
        <Field label="Texto alternativo (alt)">
          <input className={inputCls} value={m.alt || ""} placeholder="Descrição da imagem para leitores de tela"
            onChange={(e) => set({ alt: e.target.value })} />
        </Field>
        <Field label="Legenda">
          <input className={inputCls} value={m.caption || ""} placeholder="Legenda exibida abaixo da imagem"
            onChange={(e) => set({ caption: e.target.value })} />
        </Field>
        <div className="md:col-span-2">
          <Field label="Galeria opcional" hint="Uma URL por linha e/ou envie imagens (cada upload adiciona à galeria)">
            <div className="flex flex-wrap items-start gap-2">
              <textarea className={`${inputCls} min-w-0 flex-1`} rows={3}
                value={(m.gallery || []).join("\n")}
                placeholder={"https://…/foto-1.jpg\nhttps://…/foto-2.jpg"}
                onChange={(e) => set({ gallery: e.target.value.split("\n").map((s) => s.trim()).filter(Boolean) })} />
              <UploadField
                kind="image"
                accept="image/*"
                multiple
                label="+ imagens"
                onUploaded={(d) => set({ gallery: [...(m.gallery || []), d] })}
              />
            </div>
            {(m.gallery || []).length > 0 && (
              <div className="mt-2 flex flex-wrap gap-2">
                {(m.gallery || []).map((g, i) => (
                  <div key={i} className="relative">
                    <img src={g} alt="" className="h-16 w-16 rounded-lg border border-slate-700 object-cover" />
                    <button
                      type="button"
                      aria-label="Remover da galeria"
                      onClick={() => set({ gallery: m.gallery.filter((_, j) => j !== i) })}
                      className="absolute -right-1.5 -top-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-rose-500 text-[10px] text-white"
                    >
                      ✕
                    </button>
                  </div>
                ))}
              </div>
            )}
          </Field>
        </div>
      </div>
    );
  }

  if (type === "video") {
    return (
      <div className="grid gap-4 md:grid-cols-2">
        <div className="md:col-span-2">
          <Field label="Vídeo: URL (YouTube/Vimeo/arquivo) ou upload de vídeo"
            hint="YouTube, Vimeo, .mp4/.webm por URL — ou envie um arquivo de vídeo (limite de tamanho local)">
            <UrlWithUpload
              value={m.url}
              onChange={(v) => set({ url: v })}
              kind="video"
              accept="video/*"
              placeholder="https://www.youtube.com/watch?v=… ou https://…/video.mp4"
              preview="video"
            />
          </Field>
        </div>
        <Field label="Pôster / thumbnail (URL ou upload)">
          <UrlWithUpload
            value={m.poster}
            onChange={(v) => set({ poster: v })}
            kind="image"
            placeholder="https://…/thumb.jpg"
            preview="image"
          />
        </Field>
        <Field label="Duração (ex.: 12:34)">
          <input className={inputCls} value={m.duration || ""} placeholder="12:34"
            onChange={(e) => set({ duration: e.target.value })} />
        </Field>
        <div className="md:col-span-2">
          <Field label="Transcrição opcional" hint="Exibida no modelo 'Vídeo com transcrição'">
            <textarea className={inputCls} rows={4} value={m.transcript || ""}
              placeholder={"00:00 Introdução\n01:20 Tema principal\n…"}
              onChange={(e) => set({ transcript: e.target.value })} />
          </Field>
        </div>
      </div>
    );
  }

  // type === "audio"
  return (
    <div className="grid gap-4 md:grid-cols-2">
      <div className="md:col-span-2">
        <Field label="Áudio: URL ou upload de arquivo (MP3/WAV/OGG)"
          hint="Informe uma URL ou envie o arquivo de áudio (limite de tamanho local)">
          <UrlWithUpload
            value={m.url}
            onChange={(v) => set({ url: v })}
            kind="audio"
            accept="audio/*"
            placeholder="https://…/episodio.mp3"
            preview="audio"
          />
        </Field>
      </div>
      <Field label="Imagem de capa do player (URL ou upload)">
        <UrlWithUpload
          value={m.cover}
          onChange={(v) => set({ cover: v })}
          kind="image"
          placeholder="https://…/capa-800x800.jpg"
          preview="image"
        />
      </Field>
      <Field label="Duração (ex.: 32:10)">
        <input className={inputCls} value={m.duration || ""} placeholder="32:10"
          onChange={(e) => set({ duration: e.target.value })} />
      </Field>
      <div className="md:col-span-2">
        <Field label="Transcrição opcional">
          <textarea className={inputCls} rows={3} value={m.transcript || ""} placeholder="Texto completo do episódio…"
            onChange={(e) => set({ transcript: e.target.value })} />
        </Field>
      </div>
      <div className="md:col-span-2">
        <Field label="Timestamps (uma por linha: mm:ss — descrição)" hint="Usados no modelo 'Player com timestamps' — clicar pula para o trecho">
          <textarea className={inputCls} rows={4}
            value={(m.timestamps || []).map((t) => `${fmt(t.time)} — ${t.label}`).join("\n")}
            placeholder={"00:00 Abertura\n02:30 Primeiro tema\n10:15 Entrevista"}
            onChange={(e) => {
              const timestamps = e.target.value.split("\n").map((line) => {
                const mm = line.match(/^(\d{1,3}):(\d{2})\s*[-–—]?\s*(.*)$/);
                if (mm) return { time: Number(mm[1]) * 60 + Number(mm[2]), label: mm[3].trim() || "Trecho" };
                return null;
              }).filter(Boolean);
              set({ timestamps });
            }} />
        </Field>
      </div>
    </div>
  );
}

function fmt(sec) {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export function TypeBadge({ type }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2 py-0.5 text-xs font-medium text-slate-600 dark:bg-slate-800 dark:text-slate-300">
      {TYPE_ICONS[type] || "📄"} {type === "image" ? "Imagem" : type === "video" ? "Vídeo" : "Áudio"}
    </span>
  );
}
