// Coração vermelho discreto de "lista de desejos" nos produtos da loja.
// Usa o perfil escolhido em "Participar como" no fórum; o produto aparece em
// Perfil → Shop → Lista de desejos. Clicar de novo remove.
import { useState } from "react";
import { updateState } from "../store.js";
import { navigate } from "../router.js";
import { getMe } from "../pages/Forum.jsx";

export function inWishlist(profile, productId) {
  return !!profile && (profile.wishlist || []).includes(productId);
}

/** Adiciona/remove o produto da lista de desejos do perfil. Retorna true se adicionou. */
export function toggleWishlist(profileId, productId) {
  let added = false;
  updateState((s) => {
    const p = s.forum.profiles.find((x) => x.id === profileId);
    if (!p) return;
    p.wishlist = p.wishlist || [];
    if (p.wishlist.includes(productId)) p.wishlist = p.wishlist.filter((id) => id !== productId);
    else {
      p.wishlist = [productId, ...p.wishlist];
      added = true;
    }
  });
  return added;
}

export default function WishHeart({ state, product, className = "" }) {
  const me = getMe(state);
  const active = inWishlist(me, product.id);
  const [tip, setTip] = useState("");

  const click = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!me) {
      setTip("need");
      return;
    }
    const added = toggleWishlist(me.id, product.id);
    setTip(added ? "added" : "removed");
    setTimeout(() => setTip(""), 1800);
  };

  return (
    <span className={`z-10 ${className}`} data-wish-wrap>
      <button
        type="button"
        onClick={click}
        aria-pressed={active}
        aria-label={active ? "Remover da lista de desejos" : "Adicionar à lista de desejos"}
        title={active ? "Remover da lista de desejos" : "Adicionar à lista de desejos"}
        data-wish={product.id}
        className="flex h-8 w-8 items-center justify-center rounded-full bg-white/85 shadow-sm backdrop-blur transition hover:scale-110 dark:bg-slate-900/80"
      >
        <svg viewBox="0 0 24 24" className="h-4 w-4" aria-hidden="true">
          <path
            d="M12 21s-6.7-4.35-9.33-8.1C.6 9.9 1.9 5.5 5.6 4.6c2.1-.5 4.1.4 5.4 2.1l1 1.3 1-1.3c1.3-1.7 3.3-2.6 5.4-2.1 3.7.9 5 5.3 2.93 8.3C18.7 16.65 12 21 12 21z"
            fill={active ? "#ef4444" : "none"}
            stroke="#ef4444"
            strokeWidth="2"
            strokeLinejoin="round"
          />
        </svg>
      </button>
      {tip && (
        <span role="status" className="absolute right-0 top-10 w-56 rounded-lg bg-slate-900 px-3 py-2 text-left text-xs text-white shadow-xl">
          {tip === "added" && <>❤️ Adicionado à lista de desejos</>}
          {tip === "removed" && <>Removido da lista de desejos</>}
          {tip === "need" && (
            <>
              Escolha “Participar como” no fórum para usar a lista de desejos.{" "}
              <button type="button" className="font-semibold text-amber-300 underline" onClick={(e) => { e.stopPropagation(); navigate("/forum"); }}>
                Ir ao fórum
              </button>
            </>
          )}
        </span>
      )}
    </span>
  );
}
