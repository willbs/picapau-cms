// Seletor visual dos modelos (templates) de layout disponíveis para cada tipo de artigo.
import { TEMPLATES } from "../templates/ArticleView.jsx";
import { cn } from "../utils.js";

/** Miniatura esquemática do layout (desenhada com divs). */
function Schematic({ type, id }) {
  const bar = "h-1 rounded bg-slate-300 dark:bg-slate-600";
  const block = "rounded-sm bg-amber-400/80 dark:bg-amber-500/80";
  const media = type === "image" ? block : type === "video" ? "rounded-sm bg-indigo-400/80 dark:bg-indigo-500/80" : "rounded-sm bg-emerald-400/80 dark:bg-emerald-500/80";
  const box = "flex h-16 w-full gap-1 rounded-md border border-slate-200 bg-slate-50 p-1.5 dark:border-slate-700 dark:bg-slate-800/60";
  const col = "flex h-full flex-1 flex-col gap-1";
  const rows = (n) => Array.from({ length: n }, (_, i) => <div key={i} className={cn(bar, "w-full")} />);

  switch (id) {
    case "hero":
    case "top":
      return <div className={box}><div className="flex h-full w-full flex-col gap-1"><div className={cn(media, "h-1/2 w-full")} />{rows(3)}</div></div>;
    case "side":
      return <div className={box}><div className={cn(media, "h-full w-1/3")} /><div className={col}>{rows(4)}</div></div>;
    case "gallery":
      return <div className={box}><div className="flex h-full w-full flex-col gap-1"><div className={cn(media, "h-1/3 w-full")} /><div className="flex gap-1">{[0,1,2].map(i=><div key={i} className={cn(media, "h-3 flex-1")} />)}</div>{rows(1)}</div></div>;
    case "fullscreen":
    case "fullwidth":
      return <div className={box}><div className="relative h-full w-full"><div className={cn(media, "h-full w-full")} /><div className="absolute bottom-1 left-1 h-1 w-1/2 rounded bg-white/80" /></div></div>;
    case "inline":
      return <div className={box}><div className={col}>{rows(1)}<div className={cn(media, "h-2 w-full")} />{rows(2)}</div></div>;
    case "playlist":
      return <div className={box}><div className={col}><div className={cn(media, "h-1/2 w-full")} />{rows(1)}</div><div className="flex h-full w-1/3 flex-col gap-1">{[0,1,2].map(i=><div key={i} className={cn(media, "h-2.5 w-full opacity-60")} />)}</div></div>;
    case "transcript":
      return <div className={box}><div className="flex h-full w-full flex-col gap-1"><div className={cn(media, "h-1/2 w-full")} /><div className={cn(bar, "h-2 w-full bg-slate-200")} />{rows(2)}</div></div>;
    case "sticky":
      return <div className={box}><div className={col}>{rows(4)}<div className={cn(media, "h-2 w-full")} /></div></div>;
    case "cover":
      return <div className={box}><div className={cn(media, "h-full w-1/3")} /><div className={col}><div className={cn(bar, "h-1.5 w-2/3 bg-slate-400")} />{rows(3)}</div></div>;
    case "timestamps":
      return <div className={box}><div className="flex h-full w-full flex-col gap-1"><div className={cn(media, "h-1/3 w-full")} /><div className="flex flex-col gap-0.5">{[0,1,2].map(i=><div key={i} className={cn(bar, "h-1 w-3/4")} />)}</div></div></div>;
    default:
      return <div className={box}>{rows(4)}</div>;
  }
}

/** Grade de modelos para o tipo de artigo selecionado. */
export default function TemplatePicker({ type, value, onChange }) {
  const list = TEMPLATES[type] || [];
  return (
    <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
      {list.map((t) => {
        const active = value === t.id;
        return (
          <button
            key={t.id}
            type="button"
            onClick={() => onChange(t.id)}
            aria-pressed={active}
            className={cn(
              "rounded-xl border p-3 text-left transition-all",
              active
                ? "border-amber-500 bg-amber-50 ring-2 ring-amber-200 dark:bg-amber-500/10 dark:ring-amber-500/40"
                : "border-slate-200 bg-white hover:border-amber-300 hover:bg-amber-50/50 dark:border-slate-700 dark:bg-slate-800 dark:hover:border-amber-500/50"
            )}
          >
            <Schematic type={type} id={t.id} />
            <p className="mt-2 text-sm font-semibold text-slate-800 dark:text-slate-100">{t.name}</p>
            <p className="text-xs text-slate-500 dark:text-slate-400">{t.desc}</p>
          </button>
        );
      })}
    </div>
  );
}
