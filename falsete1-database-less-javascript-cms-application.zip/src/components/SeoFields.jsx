// Campos de SEO (por artigo/categoria) + preview de como aparece no Google.
import { useCmsState } from "../store.js";
import { articlePath } from "../permalink.js";

/** Prévia no estilo dos resultados do Google (SERP). */
export function GooglePreview({ title, url, description }) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-700 dark:bg-slate-800">
      <p className="mb-1 text-xs font-medium uppercase tracking-wide text-slate-400">Prévia no Google</p>
      <div className="rounded-lg border border-slate-100 bg-slate-50/60 p-3 dark:border-slate-700 dark:bg-slate-900/50">
        <p className="truncate text-sm text-slate-500 dark:text-slate-400">{url || "https://…"}</p>
        <p className="mt-0.5 truncate text-lg leading-snug text-blue-700 hover:underline dark:text-blue-400">
          {title || "Título da página"}
        </p>
        <p className="mt-1 line-clamp-2 text-sm text-slate-600 dark:text-slate-300">
          {description || "A meta description aparecerá aqui, com até ~160 caracteres."}
        </p>
      </div>
    </div>
  );
}

const inputCls =
  "w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 placeholder-slate-400 focus:border-amber-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white";
const labelCls = "mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400";

/**
 * Conjunto de campos de SEO reutilizável.
 * seo: {title, description, keywords, ogImage, canonical}
 */
export default function SeoFields({ seo, onChange, slug = "", path = "" }) {
  const state = useCmsState();
  const base = (state.seo.siteUrl || "").replace(/\/$/, "") || "https://seusite.com";
  const set = (k, v) => onChange({ ...seo, [k]: v });
  const url = `${base}${path || articlePath(slug || "seu-slug")}`;

  return (
    <div className="space-y-4">
      <div className="grid gap-4 md:grid-cols-2">
        <div>
          <label htmlFor="seo-title" className={labelCls}>Título SEO</label>
          <input id="seo-title" className={inputCls} value={seo.title || ""} maxLength={70}
            placeholder={seo.title ? "" : "Título otimizado (até 60–70 caracteres)"}
            onChange={(e) => set("title", e.target.value)} />
        </div>
        <div>
          <label htmlFor="seo-keywords" className={labelCls}>Palavras-chave</label>
          <input id="seo-keywords" className={inputCls} value={seo.keywords || ""}
            placeholder="palavra1, palavra2, palavra3"
            onChange={(e) => set("keywords", e.target.value)} />
        </div>
      </div>
      <div>
        <label htmlFor="seo-desc" className={labelCls}>Meta description</label>
        <textarea id="seo-desc" className={inputCls} rows={2} maxLength={170}
          value={seo.description || ""} placeholder="Resumo atrativo de até ~160 caracteres"
          onChange={(e) => set("description", e.target.value)} />
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        <div>
          <label htmlFor="seo-og" className={labelCls}>Imagem OG (Open Graph)</label>
          <input id="seo-og" className={inputCls} value={seo.ogImage || ""} placeholder="https://…/imagem-1200x630.jpg"
            onChange={(e) => set("ogImage", e.target.value)} />
        </div>
        <div>
          <label htmlFor="seo-canon" className={labelCls}>URL canônica (opcional)</label>
          <input id="seo-canon" className={inputCls} value={seo.canonical || ""} placeholder="Deixe vazio para usar a padrão"
            onChange={(e) => set("canonical", e.target.value)} />
        </div>
      </div>
      <GooglePreview title={seo.title} url={seo.canonical || url} description={seo.description} />
    </div>
  );
}
