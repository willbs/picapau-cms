// Incorporação universal de vídeos: YouTube, Vimeo, Dailymotion, X (Twitter),
// Facebook ou URL personalizada (arquivo .mp4/.webm, upload em DataURL ou página em iframe).

export const VIDEO_PLATFORMS = [
  { id: "youtube", label: "YouTube", icon: "▶️", placeholder: "https://www.youtube.com/watch?v=…" },
  { id: "vimeo", label: "Vimeo", icon: "🎞️", placeholder: "https://vimeo.com/123456789" },
  { id: "dailymotion", label: "Dailymotion", icon: "📺", placeholder: "https://www.dailymotion.com/video/x7tgad0" },
  { id: "x", label: "X (Twitter)", icon: "𝕏", placeholder: "https://x.com/usuario/status/1234567890" },
  { id: "facebook", label: "Facebook", icon: "📘", placeholder: "https://www.facebook.com/…/videos/123…" },
  { id: "custom", label: "URL personalizada", icon: "🔗", placeholder: "https://…/video.mp4 ou upload" },
];

/** Detecta a plataforma pela URL. */
export function detectPlatform(url = "") {
  if (/youtube\.com|youtu\.be/.test(url)) return "youtube";
  if (/vimeo\.com/.test(url)) return "vimeo";
  if (/dailymotion\.com|dai\.ly/.test(url)) return "dailymotion";
  if (/(^|\/\/)(www\.)?(x|twitter)\.com\//.test(url)) return "x";
  if (/facebook\.com|fb\.watch/.test(url)) return "facebook";
  return "custom";
}

/** Retorna { kind: "iframe" | "video" | "invalid", src }. */
export function getEmbed(url = "", platform) {
  const p = platform || detectPlatform(url);
  if (!url) return { kind: "invalid", src: "" };
  if (p === "youtube") {
    const m = url.match(/(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([A-Za-z0-9_-]{6,})/);
    return m ? { kind: "iframe", src: `https://www.youtube.com/embed/${m[1]}` } : { kind: "invalid", src: "" };
  }
  if (p === "vimeo") {
    const m = url.match(/vimeo\.com\/(?:video\/)?(\d+)/);
    return m ? { kind: "iframe", src: `https://player.vimeo.com/video/${m[1]}` } : { kind: "invalid", src: "" };
  }
  if (p === "dailymotion") {
    const m = url.match(/(?:dailymotion\.com\/(?:embed\/)?video\/|dai\.ly\/)([A-Za-z0-9]+)/);
    return m ? { kind: "iframe", src: `https://www.dailymotion.com/embed/video/${m[1]}` } : { kind: "invalid", src: "" };
  }
  if (p === "x") {
    const m = url.match(/(?:x|twitter)\.com\/[^/]+\/status\/(\d+)/);
    return m
      ? { kind: "iframe", src: `https://platform.twitter.com/embed/Tweet.html?id=${m[1]}` }
      : { kind: "invalid", src: "" };
  }
  if (p === "facebook") {
    return /facebook\.com|fb\.watch/.test(url)
      ? {
          kind: "iframe",
          src: `https://www.facebook.com/plugins/video.php?href=${encodeURIComponent(url)}&show_text=false`,
        }
      : { kind: "invalid", src: "" };
  }
  // URL personalizada: arquivo de vídeo/DataURL → <video>; outra página http(s) → iframe
  if (url.startsWith("data:video") || /\.(mp4|webm|ogg|ogv|mov|m4v)(\?.*)?$/i.test(url)) {
    return { kind: "video", src: url };
  }
  if (/^https?:\/\//.test(url)) return { kind: "iframe", src: url };
  return { kind: "invalid", src: "" };
}

export default function VideoEmbed({ url, platform, title = "Vídeo", className = "" }) {
  const e = getEmbed(url, platform);
  const p = platform || detectPlatform(url);
  const ratio = p === "x" ? "4 / 5" : "16 / 9";
  if (e.kind === "video") {
    return <video controls preload="metadata" src={e.src} className={`w-full rounded-xl bg-black ${className}`} />;
  }
  if (e.kind === "iframe") {
    return (
      <div className={`relative w-full overflow-hidden rounded-xl bg-black ${className}`} style={{ aspectRatio: ratio }}>
        <iframe
          src={e.src}
          title={title}
          className="absolute inset-0 h-full w-full"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          allowFullScreen
          loading="lazy"
        />
      </div>
    );
  }
  return (
    <div className={`flex aspect-video w-full items-center justify-center rounded-xl border-2 border-dashed border-slate-400/40 text-sm text-slate-400 ${className}`}>
      URL de vídeo inválida para esta plataforma
    </div>
  );
}
