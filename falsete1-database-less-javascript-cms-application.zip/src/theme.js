// Gerenciamento do tema claro/escuro (classe .dark no <html> + preferência no LocalStorage).
const THEME_KEY = "picapau_theme_v1";

/** Preferência salva: "light" | "dark" | "system" (padrão: system). */
export function getTheme() {
  return localStorage.getItem(THEME_KEY) || "system";
}

/** Tema efetivo considerando a preferência do sistema quando "system". */
export function effectiveTheme() {
  const t = getTheme();
  if (t === "system") {
    return window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches
      ? "dark"
      : "light";
  }
  return t;
}

/** Aplica a classe .dark no <html> conforme o tema efetivo. */
export function applyTheme() {
  const dark = effectiveTheme() === "dark";
  document.documentElement.classList.toggle("dark", dark);
  const meta = document.head.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute("content", dark ? "#020617" : "#f8fafc");
}

/** Define a preferência e aplica imediatamente. */
export function setTheme(t) {
  localStorage.setItem(THEME_KEY, t);
  applyTheme();
}

/** Alterna entre claro e escuro; retorna o novo tema efetivo. */
export function toggleTheme() {
  const next = effectiveTheme() === "dark" ? "light" : "dark";
  setTheme(next);
  return next;
}
