// Renderização pública dos artigos conforme o tipo (imagem/vídeo/áudio)
// e o modelo (template) escolhido no painel. Usado na página pública E no preview do editor.
import { useRef } from "react";
import {
  cn,
  videoEmbedUrl,
  isDirectVideo,
  formatDate,
  readingTime,
  injectAfterFirstParagraph,
  TYPE_LABELS,
  TYPE_ICONS,
} from "../utils.js";
import { navigate } from "../router.js";
import { articlePath } from "../permalink.js";

/** Catálogo de modelos disponíveis por tipo de artigo. */
export const TEMPLATES = {
  image: [
    { id: "hero", name: "Imagem no topo", desc: "Imagem de destaque em largura total acima do conteúdo." },
    { id: "side", name: "Imagem lateral", desc: "Imagem fixa ao lado do texto, em duas colunas." },
    { id: "gallery", name: "Galeria de imagens", desc: "Destaque + galeria de imagens + texto." },
    { id: "fullscreen", name: "Tela cheia com overlay", desc: "Imagem full-bleed com título sobreposto em gradiente." },
    { id: "inline", name: "Imagem entre blocos", desc: "Imagem inserida automaticamente após o primeiro parágrafo." },
  ],
  video: [
    { id: "top", name: "Vídeo no topo", desc: "Vídeo incorporado em destaque acima do texto." },
    { id: "side", name: "Vídeo lateral", desc: "Vídeo fixo ao lado do texto, em duas colunas." },
    { id: "fullwidth", name: "Vídeo full-width", desc: "Vídeo em largura total da tela, sem margens." },
    { id: "playlist", name: "Vídeo + playlist", desc: "Vídeo principal com lista de vídeos relacionados." },
    { id: "transcript", name: "Vídeo + transcrição", desc: "Vídeo seguido da transcrição completa abaixo." },
  ],
  audio: [
    { id: "top", name: "Player no topo", desc: "Player de áudio em destaque acima do conteúdo." },
    { id: "sticky", name: "Player fixo (sticky)", desc: "Player fixo no rodapé da página enquanto lê." },
    { id: "cover", name: "Player com capa", desc: "Capa grande + player + descrição do episódio." },
    { id: "playlist", name: "Playlist de episódios", desc: "Player + lista de episódios relacionados." },
    { id: "timestamps", name: "Player com timestamps", desc: "Player + marcadores clicáveis que pulam no áudio." },
  ],
};

/* ------------------------------ Blocos de mídia ------------------------------ */

function Figure({ url, alt, caption, className }) {
  if (!url) return null;
  return (
    <figure className={cn("overflow-hidden", className)}>
      <img src={url} alt={alt || ""} loading="lazy" className="h-auto w-full object-cover" />
      {caption && <figcaption className="text-center text-sm italic text-slate-500">{caption}</figcaption>}
    </figure>
  );
}

function VideoBlock({ media, className, title }) {
  const embed = videoEmbedUrl(media.url);
  if (embed) {
    return (
      <div className={cn("relative w-full overflow-hidden rounded-2xl bg-black shadow-xl", className)} style={{ aspectRatio: "16 / 9" }}>
        <iframe
          src={embed}
          title={title || "Vídeo incorporado"}
          className="absolute inset-0 h-full w-full"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          allowFullScreen
        />
      </div>
    );
  }
  if (isDirectVideo(media.url)) {
    return (
      <video controls preload="metadata" poster={media.poster || undefined} src={media.url}
        className={cn("w-full rounded-2xl bg-black shadow-xl", className)} />
    );
  }
  return (
    <div className={cn("flex aspect-video w-full items-center justify-center rounded-2xl border-2 border-dashed border-slate-300 bg-slate-100 text-sm text-slate-500", className)}>
      {media.url ? "Formato de vídeo não suportado" : "Nenhum vídeo informado"}
    </div>
  );
}

function AudioPlayer({ media, title, cover, className }) {
  if (!media.url) {
    return (
      <div className={cn("flex items-center gap-3 rounded-2xl border-2 border-dashed border-slate-300 bg-slate-100 p-4 text-sm text-slate-500", className)}>
        🎧 Nenhum arquivo de áudio informado.
      </div>
    );
  }
  return (
    <div className={cn("flex items-center gap-4 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-700 dark:bg-slate-800", className)}>
      {cover && (
        <img src={cover} alt="" className="h-16 w-16 shrink-0 rounded-xl object-cover shadow" loading="lazy" />
      )}
      <div className="min-w-0 flex-1">
        {title && <p className="mb-1 truncate text-sm font-semibold text-slate-800 dark:text-slate-100">{title}</p>}
        <audio controls preload="metadata" src={media.url} className="w-full" style={{ height: 40 }}>
          Seu navegador não suporta áudio HTML5.
        </audio>
        {media.duration && <p className="mt-1 text-xs text-slate-400">Duração: {media.duration}</p>}
      </div>
    </div>
  );
}

/** Player fixo no rodapé (modelo sticky) — no preview embutido vira bloco normal. */
function StickyAudio({ media, title, cover, embedded }) {
  const inner = (
    <div className="mx-auto flex max-w-4xl items-center gap-4 px-4">
      {cover && <img src={cover} alt="" className="h-12 w-12 rounded-lg object-cover" loading="lazy" />}
      <div className="min-w-0 flex-1">
        <p className="mb-1 truncate text-sm font-medium text-white">{title}</p>
        <audio controls preload="metadata" src={media.url} className="w-full" style={{ height: 32 }} />
      </div>
      <span className="hidden text-xs text-slate-400 sm:block">🎧 player fixo</span>
    </div>
  );
  if (embedded) {
    return <div className="rounded-2xl border border-slate-700 bg-slate-900 p-3">{inner}</div>;
  }
  return (
    <div className="fixed inset-x-0 bottom-0 z-40 border-t border-slate-700/60 bg-slate-900/95 py-2 shadow-2xl backdrop-blur">
      {inner}
    </div>
  );
}

function TimestampsPlayer({ media, title }) {
  const audioRef = useRef(null);
  const jump = (t) => {
    const a = audioRef.current;
    if (a) {
      a.currentTime = t;
      a.play().catch(() => {});
    }
  };
  const fmt = (sec) => `${String(Math.floor(sec / 60)).padStart(2, "0")}:${String(sec % 60).padStart(2, "0")}`;
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-700 dark:bg-slate-800">
      <audio ref={audioRef} controls preload="metadata" src={media.url} className="w-full" style={{ height: 40 }} />
      {(media.timestamps || []).length > 0 && (
        <ul className="mt-3 divide-y divide-slate-100 dark:divide-slate-700">
          {media.timestamps.map((t, i) => (
            <li key={i}>
              <button
                type="button"
                onClick={() => jump(t.time)}
                className="flex w-full items-center gap-3 py-2 text-left text-sm hover:bg-slate-50 dark:hover:bg-slate-700/50 rounded-lg px-2"
              >
                <span className="font-mono text-xs font-semibold text-amber-600 dark:text-amber-400">{fmt(t.time)}</span>
                <span className="text-slate-700 dark:text-slate-200">{t.label}</span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function RelatedList({ related, label }) {
  if (!related.length) return null;
  return (
    <aside>
      <h3 className="mb-3 text-sm font-bold uppercase tracking-wide text-slate-500">{label}</h3>
      <ul className="space-y-3">
        {related.map((r) => (
          <li key={r.id}>
            <button
              type="button"
              onClick={() => navigate(articlePath(r))}
              className="group flex w-full items-center gap-3 rounded-xl border border-slate-200 bg-white p-2 text-left hover:border-amber-400 hover:shadow-sm dark:border-slate-700 dark:bg-slate-800"
            >
              {r.cover ? (
                <img src={r.cover} alt="" className="h-12 w-16 shrink-0 rounded-lg object-cover" loading="lazy" />
              ) : (
                <span className="flex h-12 w-16 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-xl dark:bg-slate-700">
                  {TYPE_ICONS[r.type]}
                </span>
              )}
              <span className="min-w-0">
                <span className="block truncate text-sm font-semibold text-slate-800 group-hover:text-amber-600 dark:text-slate-100">
                  {r.title}
                </span>
                <span className="block text-xs text-slate-400">{formatDate(r.date)}</span>
              </span>
            </button>
          </li>
        ))}
      </ul>
    </aside>
  );
}

/* ------------------------------ Cabeçalho do artigo ------------------------------ */

function ArticleHeader({ article, categories }) {
  return (
    <header className="mb-8">
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <span className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-2.5 py-1 text-xs font-semibold text-amber-800 dark:bg-amber-500/15 dark:text-amber-300">
          {TYPE_ICONS[article.type]} Artigo com {TYPE_LABELS[article.type]}
        </span>
        {categories.map((c) => (
          <button
            key={c.slug}
            type="button"
            onClick={() => navigate(`/categoria/${c.slug}`)}
            className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-600 hover:bg-amber-100 hover:text-amber-800 dark:bg-slate-800 dark:text-slate-300"
          >
            {c.icon} {c.name}
          </button>
        ))}
      </div>
      <h1 className="text-3xl font-extrabold leading-tight tracking-tight text-slate-900 dark:text-white sm:text-4xl">
        {article.title}
      </h1>
      {article.excerpt && <p className="mt-3 text-lg text-slate-500 dark:text-slate-400">{article.excerpt}</p>}
      <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-slate-400">
        <span>✍️ {article.author}</span>
        <span>📅 {formatDate(article.date)}</span>
        <span>⏱️ {readingTime(article.content)}</span>
        {article.__views !== undefined && (
          <span className="text-xs opacity-70" title="Visualizações deste artigo" data-views>👁 {article.__views} visualizaç{article.__views === 1 ? "ão" : "ões"}</span>
        )}
      </div>
    </header>
  );
}

/* ------------------------------ Componente principal ------------------------------ */

/**
 * Renderiza o artigo conforme type + template.
 * embedded=true é usado no preview do editor (ex.: player sticky vira bloco normal).
 */
export default function ArticleView({ article, related = [], categories = [], embedded = false }) {
  const { type, template, media, content } = article;
  const imgUrl = media?.image?.url || article.cover;
  const figureHtml = imgUrl
    ? `<figure><img src="${imgUrl}" alt="${(media?.image?.alt || article.title || "").replace(/"/g, "&quot;")}" />${
        media?.image?.caption ? `<figcaption>${media.image.caption}</figcaption>` : ""
      }</figure>`
    : "";

  const body = (
    <div
      className="article-content"
      dangerouslySetInnerHTML={{
        __html:
          template === "inline" && type === "image"
            ? injectAfterFirstParagraph(content || "", figureHtml)
            : content || "",
      }}
    />
  );

  /* ------------------------------- IMAGEM ------------------------------- */
  if (type === "image") {
    if (template === "fullscreen") {
      return (
        <article>
          <div className="relative -mx-4 -mt-6 mb-8 flex h-[55vh] min-h-72 items-end overflow-hidden sm:rounded-3xl">
            {imgUrl && <img src={imgUrl} alt={media?.image?.alt || ""} className="absolute inset-0 h-full w-full object-cover" />}
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
            <div className="relative p-6 sm:p-10">
              <ArticleHeader article={article} categories={categories} />
            </div>
          </div>
          <div className="mx-auto max-w-3xl">{body}</div>
        </article>
      );
    }
    if (template === "side") {
      return (
        <article>
          <ArticleHeader article={article} categories={categories} />
          <div className="grid gap-8 lg:grid-cols-[340px_1fr]">
            <div className="lg:sticky lg:top-24 lg:self-start">
              <Figure url={imgUrl} alt={media?.image?.alt} caption={media?.image?.caption} className="rounded-2xl shadow-lg" />
            </div>
            <div>{body}</div>
          </div>
        </article>
      );
    }
    if (template === "gallery") {
      const gallery = media?.image?.gallery || [];
      return (
        <article>
          <ArticleHeader article={article} categories={categories} />
          <Figure url={imgUrl} alt={media?.image?.alt} caption={media?.image?.caption} className="mb-4 rounded-2xl shadow-lg" />
          {gallery.length > 0 && (
            <div className="mb-8 grid grid-cols-2 gap-3 sm:grid-cols-3">
              {gallery.map((g, i) => (
                <img key={i} src={g} alt="" loading="lazy" className="h-32 w-full rounded-xl object-cover shadow-sm sm:h-40" />
              ))}
            </div>
          )}
          {body}
        </article>
      );
    }
    // hero (padrão)
    return (
      <article>
        <ArticleHeader article={article} categories={categories} />
        <Figure url={imgUrl} alt={media?.image?.alt} caption={media?.image?.caption} className="mb-8 rounded-2xl shadow-lg" />
        {body}
      </article>
    );
  }

  /* ------------------------------- VÍDEO ------------------------------- */
  if (type === "video") {
    const v = media?.video || {};
    if (template === "side") {
      return (
        <article>
          <ArticleHeader article={article} categories={categories} />
          <div className="grid gap-8 lg:grid-cols-[1fr_340px]">
            <div>{body}</div>
            <div className="lg:sticky lg:top-24 lg:self-start">
              <VideoBlock media={v} title={article.title} />
              {v.duration && <p className="mt-2 text-center text-xs text-slate-400">Duração: {v.duration}</p>}
            </div>
          </div>
        </article>
      );
    }
    if (template === "fullwidth") {
      return (
        <article>
          <div className="-mx-4 -mt-6 mb-8 sm:rounded-3xl overflow-hidden">
            <VideoBlock media={v} title={article.title} className="rounded-none shadow-none" />
          </div>
          <div className="mx-auto max-w-3xl">
            <ArticleHeader article={article} categories={categories} />
            {body}
          </div>
        </article>
      );
    }
    if (template === "playlist") {
      return (
        <article>
          <ArticleHeader article={article} categories={categories} />
          <div className="grid gap-8 lg:grid-cols-[1fr_320px]">
            <div>
              <VideoBlock media={v} title={article.title} className="mb-6" />
              {body}
            </div>
            <RelatedList related={related} label="▶ Vídeos relacionados" />
          </div>
        </article>
      );
    }
    if (template === "transcript") {
      return (
        <article>
          <ArticleHeader article={article} categories={categories} />
          <VideoBlock media={v} title={article.title} className="mb-6" />
          {body}
          {v.transcript && (
            <section className="mt-10 rounded-2xl border border-slate-200 bg-slate-50 p-6 dark:border-slate-700 dark:bg-slate-800/60">
              <h2 className="mb-3 text-xl font-bold text-slate-900 dark:text-white">📝 Transcrição</h2>
              <pre className="whitespace-pre-wrap font-sans text-sm leading-relaxed text-slate-600 dark:text-slate-300">{v.transcript}</pre>
            </section>
          )}
        </article>
      );
    }
    // top (padrão)
    return (
      <article>
        <ArticleHeader article={article} categories={categories} />
        <VideoBlock media={v} title={article.title} className="mb-8" />
        {body}
      </article>
    );
  }

  /* ------------------------------- ÁUDIO ------------------------------- */
  const a = media?.audio || {};
  if (template === "sticky") {
    return (
      <article className={embedded ? "" : "pb-28"}>
        <ArticleHeader article={article} categories={categories} />
        {body}
        <StickyAudio media={a} title={article.title} cover={a.cover || article.cover} embedded={embedded} />
      </article>
    );
  }
  if (template === "cover") {
    return (
      <article>
        <ArticleHeader article={article} categories={categories} />
        <div className="mb-8 flex flex-col items-center gap-6 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-700 dark:bg-slate-800 sm:flex-row">
          {(a.cover || article.cover) && (
            <img src={a.cover || article.cover} alt="" className="h-40 w-40 rounded-2xl object-cover shadow-lg sm:h-48 sm:w-48" loading="lazy" />
          )}
          <div className="w-full flex-1">
            <AudioPlayer media={a} title={article.title} className="!border-0 !bg-transparent !p-0 !shadow-none" />
          </div>
        </div>
        {body}
      </article>
    );
  }
  if (template === "playlist") {
    return (
      <article>
        <ArticleHeader article={article} categories={categories} />
        <div className="grid gap-8 lg:grid-cols-[1fr_320px]">
          <div>
            <AudioPlayer media={a} title={article.title} cover={a.cover || article.cover} className="mb-6" />
            {body}
          </div>
          <RelatedList related={related} label="🎙 Episódios relacionados" />
        </div>
      </article>
    );
  }
  if (template === "timestamps") {
    return (
      <article>
        <ArticleHeader article={article} categories={categories} />
        <TimestampsPlayer media={a} title={article.title} />
        <div className="mt-8">{body}</div>
        {a.transcript && (
          <section className="mt-10 rounded-2xl border border-slate-200 bg-slate-50 p-6 dark:border-slate-700 dark:bg-slate-800/60">
            <h2 className="mb-3 text-xl font-bold text-slate-900 dark:text-white">📝 Transcrição</h2>
            <pre className="whitespace-pre-wrap font-sans text-sm leading-relaxed text-slate-600 dark:text-slate-300">{a.transcript}</pre>
          </section>
        )}
      </article>
    );
  }
  // top (padrão)
  return (
    <article>
      <ArticleHeader article={article} categories={categories} />
      <AudioPlayer media={a} title={article.title} cover={a.cover || article.cover} className="mb-8" />
      {body}
    </article>
  );
}
