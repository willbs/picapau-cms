// Backup do CMS (Painel → Segurança → Backup).
// - Local: download de arquivo .json e cópias guardadas no navegador (IndexedDB, mais espaço que o LocalStorage)
// - Google Drive: OAuth 2.0 via Google Identity Services (escopo drive.file) + upload multipart na Drive API v3
// - Automático: agendamento por frequência; roda enquanto o painel estiver aberto (não há servidor)
import { loadState, updateState } from "./store.js";
import { uid, download } from "./utils.js";

const DB_NAME = "picapau_backups";
const STORE = "snapshots";
const SKIP_KEYS = ["picapau_session_v1", "picapau_attempts_v1"];

export const FREQUENCIES = [
  { id: "1h", label: "A cada hora", ms: 3600e3 },
  { id: "6h", label: "A cada 6 horas", ms: 6 * 3600e3 },
  { id: "12h", label: "A cada 12 horas", ms: 12 * 3600e3 },
  { id: "daily", label: "Diariamente", ms: 24 * 3600e3 },
  { id: "weekly", label: "Semanalmente", ms: 7 * 24 * 3600e3 },
];

export const DEFAULT_BACKUP = {
  auto: { enabled: false, frequency: "daily", local: true, drive: false, keep: 10 },
  drive: { clientId: "" },
  lastAuto: 0,
  history: [],
};

export function backupConfig(state) {
  const b = state.backup || {};
  return { ...DEFAULT_BACKUP, ...b, auto: { ...DEFAULT_BACKUP.auto, ...(b.auto || {}) }, drive: { ...DEFAULT_BACKUP.drive, ...(b.drive || {}) } };
}

/* ------------------------- geração / restauração ------------------------- */

/** Monta o backup com todos os dados do CMS (exceto sessão e tentativas de login). */
export function buildBackup() {
  const data = {};
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i);
    if (k && k.startsWith("picapau_") && !SKIP_KEYS.includes(k)) data[k] = localStorage.getItem(k);
  }
  return { app: "pica-pau-cms", version: 1, createdAt: new Date().toISOString(), data };
}

export function backupFileName(date = new Date()) {
  const p = (n) => String(n).padStart(2, "0");
  return `picapau-backup-${date.getFullYear()}-${p(date.getMonth() + 1)}-${p(date.getDate())}_${p(date.getHours())}-${p(date.getMinutes())}.json`;
}

export function downloadBackup(backup = buildBackup()) {
  download(backupFileName(new Date(backup.createdAt)), JSON.stringify(backup, null, 2), "application/json");
}

/** Restaura um backup (substitui os dados atuais; mantém a sessão do administrador). */
export function restoreBackup(obj) {
  if (!obj || obj.app !== "pica-pau-cms" || !obj.data || !obj.data.picapau_cms_state_v1) {
    throw new Error("Arquivo inválido: não é um backup do Pica-Pau CMS.");
  }
  JSON.parse(obj.data.picapau_cms_state_v1); // valida o JSON principal
  const remove = [];
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i);
    if (k && k.startsWith("picapau_") && !SKIP_KEYS.includes(k)) remove.push(k);
  }
  remove.forEach((k) => localStorage.removeItem(k));
  Object.entries(obj.data).forEach(([k, v]) => localStorage.setItem(k, v));
  window.dispatchEvent(new Event("cms:changed"));
}

export const sizeOf = (backup) => new Blob([JSON.stringify(backup)]).size;

/* ------------------------- cópias no navegador (IndexedDB) ------------------------- */

function openDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE, { keyPath: "id" });
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function run(mode, fn) {
  return openDb().then(
    (db) =>
      new Promise((resolve, reject) => {
        const tx = db.transaction(STORE, mode);
        const req = fn(tx.objectStore(STORE));
        tx.oncomplete = () => resolve(req ? req.result : undefined);
        tx.onerror = () => reject(tx.error);
      })
  );
}

export async function listSnapshots() {
  const all = (await run("readonly", (s) => s.getAll())) || [];
  return all.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export async function saveSnapshot(backup, origin, keep = 10) {
  const snap = { id: uid(), createdAt: backup.createdAt, origin, size: sizeOf(backup), payload: JSON.stringify(backup) };
  await run("readwrite", (s) => s.put(snap));
  const all = await listSnapshots();
  for (const old of all.slice(Math.max(1, keep))) await run("readwrite", (s) => s.delete(old.id));
  return snap;
}

export const deleteSnapshot = (id) => run("readwrite", (s) => s.delete(id));
export const getSnapshot = (id) => run("readonly", (s) => s.get(id));

/* ------------------------- Google Drive ------------------------- */

let gisPromise = null;
let token = null;
let tokenExp = 0;
let tokenClientId = "";

function loadGis() {
  if (window.google?.accounts?.oauth2) return Promise.resolve();
  if (!gisPromise) {
    gisPromise = new Promise((resolve, reject) => {
      const s = document.createElement("script");
      s.src = "https://accounts.google.com/gsi/client";
      s.async = true;
      s.onload = () => resolve();
      s.onerror = () => {
        gisPromise = null;
        reject(new Error("Não foi possível carregar o login do Google (verifique a internet)."));
      };
      document.head.appendChild(s);
    });
  }
  return gisPromise;
}

export const driveConnected = () => !!token && Date.now() < tokenExp;

/** Obtém um token de acesso (interactive = abre a janela do Google se necessário). */
export async function driveToken(clientId, interactive = true) {
  if (!clientId) throw new Error("Informe o Client ID do Google (OAuth) nas configurações do Google Drive.");
  if (token && Date.now() < tokenExp && tokenClientId === clientId) return token;
  await loadGis();
  return new Promise((resolve, reject) => {
    const client = window.google.accounts.oauth2.initTokenClient({
      client_id: clientId,
      scope: "https://www.googleapis.com/auth/drive.file",
      callback: (resp) => {
        if (resp.error) return reject(new Error(`Google: ${resp.error}`));
        token = resp.access_token;
        tokenExp = Date.now() + (Number(resp.expires_in) || 3600) * 1000 - 60e3;
        tokenClientId = clientId;
        resolve(token);
      },
      error_callback: (err) => reject(new Error(`Google: ${err?.type || "falha na autorização"}`)),
    });
    client.requestAccessToken({ prompt: interactive ? "" : "none" });
  });
}

export function driveDisconnect() {
  if (token && window.google?.accounts?.oauth2) window.google.accounts.oauth2.revoke(token, () => {});
  token = null;
  tokenExp = 0;
}

/** Envia o backup para o Google Drive (arquivo .json na raiz do Drive do usuário). */
export async function driveUpload(clientId, backup = buildBackup(), interactive = true) {
  const t = await driveToken(clientId, interactive);
  const boundary = "picapau" + Date.now();
  const meta = { name: backupFileName(new Date(backup.createdAt)), mimeType: "application/json", description: "Backup do Pica-Pau CMS" };
  const body =
    `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify(meta)}\r\n` +
    `--${boundary}\r\nContent-Type: application/json\r\n\r\n${JSON.stringify(backup)}\r\n--${boundary}--`;
  const res = await fetch("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,webViewLink", {
    method: "POST",
    headers: { Authorization: `Bearer ${t}`, "Content-Type": `multipart/related; boundary=${boundary}` },
    body,
  });
  if (res.status === 401) {
    token = null;
    throw new Error("Sessão do Google expirada — conecte novamente.");
  }
  if (!res.ok) throw new Error(`Google Drive respondeu ${res.status}.`);
  return res.json();
}

/* ------------------------- histórico e agendamento ------------------------- */

export function logBackup(entry) {
  updateState((s) => {
    s.backup = backupConfig(s);
    s.backup.history = [{ id: uid(), at: new Date().toISOString(), ...entry }, ...s.backup.history].slice(0, 30);
  });
}

let running = false;

/** Executa o backup automático se estiver na hora (chamado periodicamente com o painel aberto). */
export async function runScheduledBackup({ force = false } = {}) {
  if (running) return null;
  const cfg = backupConfig(loadState());
  if (!cfg.auto.enabled && !force) return null;
  const freq = FREQUENCIES.find((f) => f.id === cfg.auto.frequency) || FREQUENCIES[3];
  if (!force && Date.now() - (cfg.lastAuto || 0) < freq.ms) return null;
  running = true;
  try {
    updateState((s) => {
      s.backup = backupConfig(s);
      s.backup.lastAuto = Date.now();
    });
    const backup = buildBackup();
    const results = [];
    if (cfg.auto.local) {
      try {
        await saveSnapshot(backup, "automático", cfg.auto.keep);
        results.push({ target: "local", ok: true });
        logBackup({ type: "automático", target: "local", ok: true, size: sizeOf(backup) });
      } catch (e) {
        logBackup({ type: "automático", target: "local", ok: false, error: e.message });
      }
    }
    if (cfg.auto.drive) {
      try {
        const f = await driveUpload(cfg.drive.clientId, backup, false);
        results.push({ target: "drive", ok: true });
        logBackup({ type: "automático", target: "drive", ok: true, size: sizeOf(backup), file: f.name });
      } catch (e) {
        logBackup({ type: "automático", target: "drive", ok: false, error: e.message });
      }
    }
    return results;
  } finally {
    running = false;
  }
}

export function nextRunAt(state) {
  const cfg = backupConfig(state);
  if (!cfg.auto.enabled) return null;
  const freq = FREQUENCIES.find((f) => f.id === cfg.auto.frequency) || FREQUENCIES[3];
  return new Date((cfg.lastAuto || Date.now()) + freq.ms);
}
