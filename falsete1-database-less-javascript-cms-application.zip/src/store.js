// Camada de persistência: todo o estado do CMS vive no LocalStorage.
// Não há banco de dados — na primeira carga, os dados de exemplo são semeados.
import { useEffect, useState } from "react";
import { seedState, seedLoja, seedForum, seedHtml, seedSocial, seedPodcastCategories, SEED_PODCAST_MAP, seedFooter } from "./data/seed.js";
import { uid } from "./utils.js";

const STATE_KEY = "picapau_cms_state_v1";
const CHANGE_EVENT = "cms:changed";

/** Carrega o estado do LocalStorage (ou semeia na primeira vez). */
export function loadState() {
  try {
    const raw = localStorage.getItem(STATE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && parsed.version === 1 && Array.isArray(parsed.articles)) {
        let changed = false;
        // Migração 1: credenciais padrão antigas "admin/admin123" viram o e-mail atual.
        if (
          parsed.security &&
          parsed.security.user === "admin" &&
          parsed.security.passwordHash ===
            "86c81d54f83a058d5892e7a1cb7959d222ddd73a1e29992b9f85e552bd37759c"
        ) {
          parsed.security.user = "demo@demo.com";
          parsed.security.passwordHash =
            "c751c8ee0e638035bc80e7c51c7f88e9653968f339f088758f2f97a5e38af3f0";
          changed = true;
        }
        // Migração 2: modelo antigo de usuário único vira lista de usuários.
        if (parsed.security && !Array.isArray(parsed.security.users)) {
          parsed.security.users = [
            {
              id: uid(),
              email: parsed.security.user || "demo@demo.com",
              passwordHash:
                parsed.security.passwordHash ||
                "c751c8ee0e638035bc80e7c51c7f88e9653968f339f088758f2f97a5e38af3f0",
              role: "admin",
              active: true,
              createdAt: new Date().toISOString(),
            },
          ];
          changed = true;
        }
        // Migração 3: garante branding, features e allowRegistration.
        if (!parsed.branding) {
          parsed.branding = {
            siteName: parsed.seo?.ogSiteName || "Pica-Pau",
            logo: "",
            favicon: parsed.seo?.favicon || "/favicon.svg",
          };
          changed = true;
        }
        if (!parsed.features) {
          parsed.features = { podcast: true };
          changed = true;
        }
        if (parsed.security && parsed.security.allowRegistration === undefined) {
          parsed.security.allowRegistration = false;
          changed = true;
        }
        // Migração 4: garante as sessões Loja Virtual e Fórum.
        if (!parsed.loja) {
          parsed.loja = seedLoja();
          changed = true;
        }
        if (!parsed.forum) {
          parsed.forum = seedForum();
          changed = true;
        }
        // Migração 5: toggles de loja/fórum, layouts e perfis do fórum.
        if (parsed.features.loja === undefined) { parsed.features.loja = true; changed = true; }
        if (parsed.features.forum === undefined) { parsed.features.forum = true; changed = true; }
        if (!parsed.loja.template) { parsed.loja.template = "grade"; changed = true; }
        if (!parsed.forum.template) { parsed.forum.template = "classico"; changed = true; }
        if (!Array.isArray(parsed.forum.profiles)) {
          parsed.forum.profiles = seedForum().profiles;
          changed = true;
        }
        // Migração 6: estrutura de permalinks (padrão: somente o título, sem "/artigo/").
        if (!parsed.seo.permalink) {
          parsed.seo.permalink = { structure: "titulo", base: "" };
          const ia = parsed.categories.find((c) => c.slug === "ia");
          if (ia && ia.parent === undefined) ia.parent = "tecnologia";
          changed = true;
        }
        // Migração 7: sessão HTML, comentários, visualizações e página principal.
        if (!parsed.html) { parsed.html = seedHtml(); changed = true; }
        if (!Array.isArray(parsed.comments)) { parsed.comments = []; changed = true; }
        if (!parsed.views) { parsed.views = {}; changed = true; }
        if (!parsed.seo.homepage) { parsed.seo.homepage = "home"; changed = true; }
        // Migração 8: categorias de podcast e redes sociais.
        if (!parsed.podcast) {
          parsed.podcast = { categories: seedPodcastCategories() };
          parsed.articles.forEach((a) => { if (SEED_PODCAST_MAP[a.slug] && !a.podcastCategory) a.podcastCategory = SEED_PODCAST_MAP[a.slug]; });
          changed = true;
        }
        if (!parsed.social) { parsed.social = seedSocial(); changed = true; }
        // Migração 9: rodapé configurável.
        if (!parsed.footer) { parsed.footer = seedFooter(); changed = true; }
        // Migração 10: sessão Comentários (aprovação obrigatória por padrão; "oculto" → "reprovado").
        if (!parsed.commentsModerationV2) {
          parsed.commentsModerationV2 = true;
          parsed.html.comments = { ...(parsed.html.comments || {}), enabled: parsed.html.comments?.enabled !== false, requireApproval: true };
          (parsed.comments || []).forEach((c) => { if (c.status === "oculto") c.status = "reprovado"; });
          changed = true;
        }
        // Migração 11: sessão Tradução.
        if (!parsed.i18n) {
          parsed.i18n = { enabled: true, default: "pt-BR", languages: { "pt-BR": true, en: true, es: true, it: true, fr: true }, auto: true, phrases: {} };
          changed = true;
        }
        // Migração 12: remove links para a antiga seção "Sobre este portal" (/#sobre).
        if (!parsed.aboutSectionRemoved) {
          parsed.aboutSectionRemoved = true;
          const strip = (items) => (items || []).filter((i) => i.url !== "/#sobre").map((i) => ({ ...i, children: strip(i.children) }));
          (parsed.menus || []).forEach((m) => { m.items = strip(m.items); });
          if (parsed.footer?.bottomMenu) parsed.footer.bottomMenu = parsed.footer.bottomMenu.filter((i) => i.url !== "/#sobre");
          changed = true;
        }
                // Migração 13: backup e políticas de privacidade.
        if (!parsed.backup) {
          parsed.backup = { auto: { enabled: false, frequency: "daily", local: true, drive: false, keep: 10 }, drive: { clientId: "" }, lastAuto: 0, history: [] };
          changed = true;
        }
        if (parsed.security.privacyUrl === undefined) { parsed.security.privacyUrl = ""; parsed.security.privacyVersion = 0; changed = true; }
        // Migração 14: SMTP.
        if (!parsed.smtp) {
          parsed.smtp = { enabled: false, host: "", port: 587, security: "starttls", user: "", pass: "", fromName: "", fromEmail: "", replyTo: "", adminEmail: "", notifyNewAccounts: true, relayUrl: "http://localhost:3001/send", relayKey: "", log: [] };
          changed = true;
        }
        // Migração 15: login em /login (robots.txt editável passa a bloquear /login).
        if (parsed.seo.robotsTxt && !/Disallow: \/login/.test(parsed.seo.robotsTxt)) {
          parsed.seo.robotsTxt = parsed.seo.robotsTxt.replace("Disallow: /pica-pau", "Disallow: /login\nDisallow: /pica-pau");
          if (!/Disallow: \/login/.test(parsed.seo.robotsTxt)) parsed.seo.robotsTxt = "Disallow: /login\n" + parsed.seo.robotsTxt;
          changed = true;
        }
                // Migração 16: tema da página inicial.
        if (!parsed.theme) { parsed.theme = { template: "original", blocks: ["hero","destaques","categorias","ultimos","porCategoria","maisLidos","videos","audios","loja","forum"].map((id) => ({ id, enabled: !["loja", "forum"].includes(id) })), featuredCategories: [], featuredArticles: [] }; changed = true; }
        // Migração 17: liga a conta de login do administrador ao perfil público "willie" do fórum.
        if (!parsed.profileLinkV1) {
          parsed.profileLinkV1 = true;
          const admin = (parsed.security.users || []).find((u) => u.email === "demo@demo.com");
          const prof = (parsed.forum?.profiles || []).find((p) => p.username === "willie" && !p.userId);
          if (admin && prof) prof.userId = admin.id;
          changed = true;
        }
        // Migração 18: o administrador antigo é removido e substituído por demo@demo.com / Demo123.
        if (!parsed.demoAdminV1) {
          parsed.demoAdminV1 = true;
          const users = parsed.security.users || [];
          const old = users.find((u) => u.email === "willie.bruno20@gmail.com");
          const demo = users.find((u) => u.email === "demo@demo.com");
          if (old && !demo) {
            // mantém o mesmo id para preservar os vínculos (perfil público etc.)
            Object.assign(old, { email: "demo@demo.com", passwordHash: "c751c8ee0e638035bc80e7c51c7f88e9653968f339f088758f2f97a5e38af3f0", role: "admin", active: true, emailVerified: true, verifyToken: null, verifyExpires: null, privacyAccepted: null });
          } else if (old) {
            parsed.security.users = users.filter((u) => u.id !== old.id);
          } else if (!demo) {
            users.push({ id: uid(), email: "demo@demo.com", passwordHash: "c751c8ee0e638035bc80e7c51c7f88e9653968f339f088758f2f97a5e38af3f0", role: "admin", active: true, emailVerified: true, createdAt: new Date().toISOString() });
          }
          localStorage.removeItem("picapau_session_v1"); // sessão do usuário removido é encerrada
          localStorage.removeItem("picapau_reset_v1");
          changed = true;
        }
                if (changed) saveState(parsed);
        return parsed;
      }
    }
  } catch (err) {
    console.warn("Estado corrompido, reseeding…", err);
  }
  const fresh = seedState();
  saveState(fresh);
  return fresh;
}

/** Persiste o estado no LocalStorage e avisa os componentes. */
export function saveState(state) {
  localStorage.setItem(STATE_KEY, JSON.stringify(state));
  window.dispatchEvent(new Event(CHANGE_EVENT));
}

/** Aplica uma mutação no estado e persiste. */
export function updateState(mutator) {
  const state = loadState();
  mutator(state);
  saveState(state);
  return state;
}

/** Apaga tudo (útil para testes) e semeia novamente. */
export function resetState() {
  localStorage.removeItem(STATE_KEY);
  const fresh = seedState();
  saveState(fresh);
  return fresh;
}

/** Hook React que acompanha o estado global do CMS. */
export function useCmsState() {
  const [state, setState] = useState(loadState);
  useEffect(() => {
    const handler = () => setState(loadState());
    window.addEventListener(CHANGE_EVENT, handler);
    window.addEventListener("storage", handler);
    return () => {
      window.removeEventListener(CHANGE_EVENT, handler);
      window.removeEventListener("storage", handler);
    };
  }, []);
  return state;
}
