// Motor de tradução do blog (idioma de origem: pt-BR).
// 1) Dicionário revisado (interface + conteúdo de exemplo) e traduções manuais do painel.
// 2) Tradutor de DOM: percorre a página pública, traduz textos e atributos (placeholder, aria-label,
//    title) e reage às mudanças do React via MutationObserver (guarda os textos originais).
// 3) Tradução automática opcional (API MyMemory) para conteúdo sem tradução, com cache local.
import { DICT } from "./data/i18nDict.js";

export const LANGUAGES = [
  { code: "pt-BR", name: "Português (Brasil)", short: "PT", flag: "🇧🇷", locale: "pt-BR", api: "pt-BR" },
  { code: "en", name: "English", short: "EN", flag: "🇺🇸", locale: "en-US", api: "en-US" },
  { code: "es", name: "Español", short: "ES", flag: "🇪🇸", locale: "es-ES", api: "es-ES" },
  { code: "it", name: "Italiano", short: "IT", flag: "🇮🇹", locale: "it-IT", api: "it-IT" },
  { code: "fr", name: "Français", short: "FR", flag: "🇫🇷", locale: "fr-FR", api: "fr-FR" },
];
export const SOURCE_LANG = "pt-BR";
const IDX = { en: 0, es: 1, it: 2, fr: 3 };
const LANG_KEY = "picapau_lang_v1";
const CACHE_KEY = "picapau_i18n_cache_v1";

let current = SOURCE_LANG;

/* ------------------------- idioma atual ------------------------- */

export function getLang() {
  return current;
}
export function setLangRaw(code) {
  current = LANGUAGES.some((l) => l.code === code) ? code : SOURCE_LANG;
}
export function getLocale() {
  return LANGUAGES.find((l) => l.code === current)?.locale || "pt-BR";
}
export function enabledLanguages(state) {
  const cfg = state.i18n;
  if (!cfg || cfg.enabled === false) return LANGUAGES.filter((l) => l.code === SOURCE_LANG);
  return LANGUAGES.filter((l) => cfg.languages?.[l.code]);
}
/** Idioma que o visitante vê: escolha salva (se habilitada) → padrão → primeiro habilitado. */
export function resolveLang(state) {
  const cfg = state.i18n;
  if (!cfg || cfg.enabled === false) return SOURCE_LANG;
  const on = (c) => !!cfg.languages?.[c];
  const saved = localStorage.getItem(LANG_KEY);
  if (saved && on(saved)) return saved;
  if (on(cfg.default)) return cfg.default;
  return enabledLanguages(state)[0]?.code || SOURCE_LANG;
}
/** Troca de idioma pelo seletor do menu superior. */
export function chooseLang(code) {
  localStorage.setItem(LANG_KEY, code);
  window.dispatchEvent(new Event("cms:changed"));
}

/* ------------------------- tradução de textos ------------------------- */

let overrides = {}; // traduções manuais do painel para o idioma atual
let autoOn = false;
const cacheAll = (() => {
  try {
    return JSON.parse(localStorage.getItem(CACHE_KEY)) || {};
  } catch {
    return {};
  }
})();
const cache = (lang) => (cacheAll[lang] = cacheAll[lang] || {});

function look(s) {
  if (current === SOURCE_LANG) return null;
  if (overrides[s]) return overrides[s];
  const d = DICT[s];
  if (d && d[IDX[current]]) return d[IDX[current]];
  return cache(current)[s] || null;
}

const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const TEMPLATES = Object.keys(DICT)
  .filter((k) => k.includes("{x}"))
  .map((k) => ({ key: k, re: new RegExp("^" + esc(k).replace("\\{x\\}", "(.+)") + "$", "s") }));
const DECO = "[\\s\\p{Extended_Pictographic}\\uFE0F\\u200D→←↑↓↗▶·—–*＋+✓✔•]";
const DECO_RE = new RegExp(`^(${DECO}*)(.*?)(${DECO}*)$`, "su");

/** Traduz uma string (retorna a própria string se não houver tradução). */
export function translateText(s, depth = 0) {
  if (current === SOURCE_LANG || s == null) return s;
  const str = String(s);
  const t = str.trim();
  if (!t || !/\p{L}/u.test(t) || depth > 5) return str;
  const lead = str.match(/^\s*/)[0];
  const trail = str.match(/\s*$/)[0];
  const wrap = (x) => lead + x + trail;

  let r = look(t);
  if (r != null) return wrap(r);

  // várias linhas: traduz linha a linha (ex.: transcrições com tempos)
  if (t.includes("\n")) {
    const lines = t.split("\n");
    const tr = lines.map((l) => translateText(l, depth + 1));
    if (tr.some((l, i) => l !== lines[i])) return wrap(tr.join("\n"));
  }
  // tempo/número no início da linha ("02:30 Abertura")
  const tm = t.match(/^(\d+(?:[:.,]\d+)*\s+)(\D.*)$/s);
  if (tm) {
    const inner = translateText(tm[2], depth + 1);
    if (inner !== tm[2]) return wrap(tm[1] + inner);
  }
  // pontuação final ("categoria Ciência.")
  const pm = t.match(/^(.*?\p{L}.*?)([.!?:;,…]+)$/su);
  if (pm) {
    const inner = translateText(pm[1], depth + 1);
    if (inner !== pm[1]) return wrap(inner + pm[2]);
  }

  // emojis/símbolos nas pontas: traduz só o núcleo
  const m = t.match(DECO_RE);
  if (m && (m[1] || m[3]) && m[2] && /\p{L}/u.test(m[2])) {
    const inner = translateText(m[2], depth + 1);
    if (inner !== m[2]) return wrap(m[1] + inner + m[3]);
  }
  // modelos com trecho variável {x}
  for (const tp of TEMPLATES) {
    const mm = t.match(tp.re);
    if (mm) {
      const out = look(tp.key);
      if (out != null) return wrap(out.replace("{x}", translateText(mm[1], depth + 1).trim()));
    }
  }
  // modelos numéricos {0}, {1}
  const nums = [];
  const tmpl = t.replace(/\d+(?:[.,:]\d+)*/g, (n) => {
    nums.push(n);
    return `{${nums.length - 1}}`;
  });
  if (nums.length) {
    const o = look(tmpl);
    if (o != null) return wrap(o.replace(/\{(\d+)\}/g, (_, i) => nums[i]));
  }
  // partes separadas por " · " ou " — "
  for (const sep of [" · ", " — "]) {
    if (t.includes(sep)) {
      const parts = t.split(sep);
      const tr = parts.map((p) => translateText(p, depth + 1));
      if (tr.some((p, i) => p !== parts[i])) return wrap(tr.join(sep));
    }
  }
  if (autoOn && depth === 0) queueAuto(t);
  return str;
}

/* ------------------------- tradução automática (MyMemory) ------------------------- */

const pending = new Set();
const failed = new Set();
let timer = null;
let onAutoDone = () => {};

function queueAuto(t) {
  // apenas frases (3+ palavras) — rótulos curtos vêm do dicionário
  if (t.split(/\s+/).length < 3 || t.length > 2000) return;
  const key = current + "|" + t;
  if (failed.has(key) || pending.has(key)) return;
  pending.add(key);
  clearTimeout(timer);
  timer = setTimeout(flushAuto, 400);
}

function chunks(text) {
  if (text.length <= 450) return [text];
  const out = [];
  let buf = "";
  for (const s of text.split(/(?<=[.!?;])\s+/)) {
    if ((buf + " " + s).length > 450 && buf) {
      out.push(buf);
      buf = s;
    } else buf = buf ? buf + " " + s : s;
  }
  if (buf) out.push(buf);
  return out;
}

async function translateRemote(text, lang) {
  const target = LANGUAGES.find((l) => l.code === lang)?.api || lang;
  const parts = [];
  for (const c of chunks(text)) {
    const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(c)}&langpair=pt-BR|${target}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error("HTTP " + res.status);
    const data = await res.json();
    const tr = data?.responseData?.translatedText;
    if (!tr || data.responseStatus >= 400 || /MYMEMORY WARNING|QUERY LENGTH LIMIT/i.test(tr)) throw new Error("limite");
    parts.push(tr);
  }
  return parts.join(" ");
}

async function flushAuto() {
  const items = [...pending];
  pending.clear();
  let changed = false;
  const queue = items.slice(0, 40); // limite por lote
  const worker = async () => {
    while (queue.length) {
      const key = queue.shift();
      const [lang, ...rest] = key.split("|");
      const text = rest.join("|");
      try {
        cache(lang)[text] = await translateRemote(text, lang);
        changed = true;
      } catch {
        failed.add(key);
      }
    }
  };
  await Promise.all([worker(), worker(), worker()]);
  if (changed) {
    try {
      localStorage.setItem(CACHE_KEY, JSON.stringify(cacheAll));
    } catch {
      /* armazenamento cheio: mantém só em memória */
    }
    onAutoDone();
  }
}

export function clearAutoCache() {
  Object.keys(cacheAll).forEach((k) => delete cacheAll[k]);
  failed.clear();
  localStorage.removeItem(CACHE_KEY);
}
export function autoCacheSize() {
  return Object.values(cacheAll).reduce((n, m) => n + Object.keys(m).length, 0);
}
/** Tradução automática de um texto (usada no painel para preencher traduções). */
export async function autoTranslate(text, lang) {
  return translateRemote(text, lang);
}

/* ------------------------- tradutor de DOM ------------------------- */

const ORIG = new WeakMap(); // nó de texto → texto original
const WROTE = new WeakMap(); // nó de texto → último valor escrito por nós
const ATTRS = ["placeholder", "aria-label", "title"];
const AORIG = new WeakMap(); // elemento → { atributo: original }
const AWROTE = new WeakMap();
let root = null;
let observer = null;

const skip = (el) =>
  !el ||
  el.nodeType !== 1 ||
  ["SCRIPT", "STYLE", "TEXTAREA", "svg", "CODE"].includes(el.tagName) ||
  el.isContentEditable ||
  el.closest("[data-no-translate]");

function applyGroup(nodes) {
  nodes.forEach((n) => {
    // primeiro contato, ou o React alterou o texto depois da nossa última escrita
    if (!ORIG.has(n) || n.nodeValue !== WROTE.get(n)) ORIG.set(n, n.nodeValue);
  });
  const src = nodes.map((n) => ORIG.get(n)).join("");
  const out = current === SOURCE_LANG ? src : translateText(src);
  const write = (n, v) => {
    if (n.nodeValue !== v) n.nodeValue = v;
    WROTE.set(n, v);
  };
  if (out === src) nodes.forEach((n) => write(n, ORIG.get(n)));
  else {
    write(nodes[0], out);
    nodes.slice(1).forEach((n) => write(n, ""));
  }
}

function applyAttrs(el) {
  const orig = AORIG.get(el) || {};
  const wrote = AWROTE.get(el) || {};
  for (const a of ATTRS) {
    const v = el.getAttribute(a);
    if (v == null) continue;
    if (!(a in orig) || v !== wrote[a]) orig[a] = v;
    const out = current === SOURCE_LANG ? orig[a] : translateText(orig[a]);
    if (v !== out) el.setAttribute(a, out);
    wrote[a] = out;
  }
  AORIG.set(el, orig);
  AWROTE.set(el, wrote);
}

function processEl(el) {
  if (skip(el)) return;
  const kids = [...el.childNodes];
  const allText = kids.length > 0 && kids.every((k) => k.nodeType === 3);
  if (allText) applyGroup(kids);
  else
    kids.forEach((k) => {
      if (k.nodeType === 3) applyGroup([k]);
      else if (k.nodeType === 1) processEl(k);
    });
  applyAttrs(el);
}

function onMutations(records) {
  const els = new Set();
  for (const r of records) {
    if (r.type === "characterData") {
      const n = r.target;
      if (WROTE.has(n) && n.nodeValue === WROTE.get(n)) continue; // nossa própria escrita
      if (r.target.parentElement) els.add(r.target.parentElement);
    } else if (r.type === "attributes") {
      const el = r.target;
      if ((AWROTE.get(el) || {})[r.attributeName] === el.getAttribute(r.attributeName)) continue;
      els.add(el);
    } else {
      r.addedNodes.forEach((n) => els.add(n.nodeType === 3 ? n.parentElement : n));
    }
  }
  els.forEach((el) => el && root?.contains(el) && processEl(el));
}

/** Liga o tradutor na raiz (páginas públicas) com as configurações atuais. */
export function startTranslator(rootEl, { lang, manual = {}, auto = false }) {
  setLangRaw(lang);
  overrides = manual || {};
  autoOn = auto && lang !== SOURCE_LANG;
  onAutoDone = () => root && processEl(root);
  if (root !== rootEl) {
    observer?.disconnect();
    root = rootEl;
    observer = new MutationObserver(onMutations);
    observer.observe(root, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ATTRS });
  }
  processEl(root);
}

/** Desliga o tradutor (painel administrativo sempre em pt-BR). */
export function stopTranslator() {
  if (root) {
    const r = root;
    setLangRaw(SOURCE_LANG);
    autoOn = false;
    processEl(r); // restaura os originais ainda na tela
  }
  observer?.disconnect();
  observer = null;
  root = null;
}
