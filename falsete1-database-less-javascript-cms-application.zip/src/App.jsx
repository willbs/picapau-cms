// App raiz: roteamento (JS puro), guardas de rota, SEO dinâmico por página,
// logout automático por inatividade, modo manutenção, tema claro/escuro.
import { useEffect } from "react";
import { useRoute, matchRoute, navigate } from "./router.js";
import { useCmsState } from "./store.js";
import { applySeo } from "./seo.js";
import { applyTheme, getTheme } from "./theme.js";
import { resolveArticle } from "./permalink.js";
import { runScheduledBackup } from "./backup.js";
import { resolveLang, setLangRaw, startTranslator, stopTranslator, translateText, getLocale, SOURCE_LANG } from "./i18n.js";
import {
  isAuthenticated,
  getSession,
  getCurrentUser,
  isAdmin,
  touchSession,
  checkInactivity,
  destroySession,
  addLog,
} from "./auth.js";

import Home from "./pages/Home.jsx";
import MagazineHome from "./pages/MagazineHome.jsx";
import CategoryPage from "./pages/CategoryPage.jsx";
import ArticlePage from "./pages/ArticlePage.jsx";
import Podcasts from "./pages/Podcasts.jsx";
import Feed from "./pages/Feed.jsx";
import Loja from "./pages/Loja.jsx";
import { ForumIndex, ForumNew, ForumTopic } from "./pages/Forum.jsx";
import ForumProfile from "./pages/ForumProfile.jsx";
import NotFound from "./pages/NotFound.jsx";
import Maintenance from "./pages/Maintenance.jsx";
import Login from "./pages/Login.jsx";
import ResetPassword from "./pages/ResetPassword.jsx";
import Register from "./pages/Register.jsx";
import ConfirmEmail from "./pages/ConfirmEmail.jsx";

import AdminLayout from "./admin/AdminLayout.jsx";
import Dashboard from "./admin/Dashboard.jsx";
import ArticlesList from "./admin/ArticlesList.jsx";
import ArticleEditor from "./admin/ArticleEditor.jsx";
import CategoriesAdmin from "./admin/CategoriesAdmin.jsx";
import SeoAdmin from "./admin/SeoAdmin.jsx";
import SecurityAdmin from "./admin/SecurityAdmin.jsx";
import MenusAdmin from "./admin/MenusAdmin.jsx";
import PodcastsAdmin from "./admin/PodcastsAdmin.jsx";
import BrandingAdmin from "./admin/BrandingAdmin.jsx";
import LojaAdmin from "./admin/LojaAdmin.jsx";
import ForumAdmin from "./admin/ForumAdmin.jsx";
import TranslationAdmin from "./admin/TranslationAdmin.jsx";
import ThemeAdmin from "./admin/ThemeAdmin.jsx";
import HtmlAdmin from "./admin/HtmlAdmin.jsx";
import SocialAdmin from "./admin/SocialAdmin.jsx";
import FooterAdmin from "./admin/FooterAdmin.jsx";
import CommentsAdmin from "./admin/CommentsAdmin.jsx";

export default function App() {
  const route = useRoute();
  const state = useCmsState();

  // Idioma: páginas públicas usam o idioma do visitante; login e painel ficam em pt-BR.
  const isRestrictedRoute = route === "/login" || route.startsWith("/login/") || route.startsWith("/admin");
  const lang = isRestrictedRoute ? SOURCE_LANG : resolveLang(state);
  setLangRaw(lang); // antes de renderizar: datas e moedas no formato do idioma

  /* ---- Backup automático pré-programado (roda com o administrador logado) ---- */
  useEffect(() => {
    const tick = () => { if (isAuthenticated()) runScheduledBackup().catch(() => {}); };
    const first = setTimeout(tick, 3000);
    const iv = setInterval(tick, 60000);
    return () => { clearTimeout(first); clearInterval(iv); };
  }, []);

  /* ---- Tradutor do blog (DOM) ---- */
  useEffect(() => {
    const rootEl = document.getElementById("root");
    if (isRestrictedRoute) stopTranslator();
    else
      startTranslator(rootEl, {
        lang,
        manual: state.i18n?.phrases?.[lang] || {},
        auto: state.i18n?.auto !== false,
      });
  }, [route, lang, state, isRestrictedRoute]);

  /* ---- Tema claro/escuro: aplica na carga e reage à preferência do sistema ---- */
  useEffect(() => {
    applyTheme();
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const onChange = () => {
      if (getTheme() === "system") applyTheme();
    };
    mq.addEventListener?.("change", onChange);
    return () => mq.removeEventListener?.("change", onChange);
  }, []);

  /* ---- Sessão: registra atividade e faz logout automático por inatividade ---- */
  useEffect(() => {
    const onActivity = () => touchSession();
    ["pointerdown", "keydown", "scroll", "touchstart"].forEach((ev) =>
      window.addEventListener(ev, onActivity, { passive: true })
    );
    const iv = setInterval(() => {
      if (checkInactivity()) {
        addLog("logout", "Sessão encerrada por inatividade");
        destroySession();
        if (getRouteSafe().startsWith("/admin")) navigate("/");
      }
    }, 15000);
    return () => {
      ["pointerdown", "keydown", "scroll", "touchstart"].forEach((ev) =>
        window.removeEventListener(ev, onActivity)
      );
      clearInterval(iv);
    };
  }, [route]);

  /* ---- SEO dinâmico por rota ---- */
  useEffect(() => {
    const isRestricted =
      route === "/login" ||
      route.startsWith("/login/") ||
      route.startsWith("/admin");
    if (isRestricted) {
      // Login/recuperação e painel não são indexáveis.
      applySeo(state.seo, { title: "Área restrita" }, true);
      return;
    }
    const over = { path: route };
    if (route === "/podcasts") {
      over.title = `Podcasts | ${state.seo.title}`;
      over.description = "Todos os episódios de podcast do portal, organizados por categoria.";
      over.keywords = "podcast, episódios, áudio";
    }
    if (route === "/feed" || route.startsWith("/feed/")) {
      over.title = `Feed | ${state.seo.title}`;
      over.description = "Imagens, vídeos e áudios publicados pelos usuários.";
    }
    if (route === "/loja") {
      over.title = `Loja | ${state.seo.title}`;
      over.description = "Produtos oficiais da loja virtual do portal.";
      over.keywords = "loja, produtos, comprar";
    }
    if (route === "/forum" || route.startsWith("/forum/")) {
      over.title = `Fórum | ${state.seo.title}`;
      over.description = "Fórum da comunidade: tópicos, dúvidas e ideias.";
      over.keywords = "fórum, comunidade, tópicos";
    }
    const mCat = matchRoute(route, "/categoria/:slug");
    if (mCat) {
      const cat = state.categories.find((c) => c.slug === mCat.slug);
      if (cat) {
        over.title = cat.seo?.title || `${cat.name} | ${state.seo.title}`;
        over.description = cat.seo?.description || cat.description;
        over.keywords = cat.seo?.keywords || "";
        over.ogImage = cat.seo?.ogImage || cat.image || state.seo.ogImage;
      }
    }
    const mArt = !mCat ? resolveArticle(route, state) : null;
    if (mArt) {
      const art = mArt.article;
      over.path = mArt.canonical;
      if (art) {
        over.title = art.seo?.title || art.title;
        over.description = art.seo?.description || art.excerpt;
        over.keywords = art.seo?.keywords || "";
        over.ogImage = art.seo?.ogImage || art.cover || state.seo.ogImage;
        over.canonical = art.seo?.canonical || "";
        over.ogType = "article";
      }
    }
    // título/descrição traduzidos + atributo lang do documento
    const seoT = { ...state.seo, title: translateText(state.seo.title), description: translateText(state.seo.description) };
    if (over.title) over.title = translateText(over.title);
    if (over.description) over.description = translateText(over.description);
    applySeo(seoT, over, false);
    document.documentElement.lang = getLocale();
  }, [route, state, lang]);

  /* ------------------------------ roteamento ------------------------------ */
  // Endereço antigo do login (/pica-pau…) redireciona para /login… (links antigos continuam funcionando)
  if (route === "/pica-pau" || route.startsWith("/pica-pau/")) return <Redirect to={route.replace(/^\/pica-pau/, "/login")} />;

  // Redefinição de senha via link: /login/redefinir/:token (ou #/login/redefinir/:token)
  const mReset = matchRoute(route, "/login/redefinir/:token");
  if (mReset) return <ResetPassword token={mReset.token} />;

  // Confirmação de e-mail do cadastro: /login/confirmar/:token
  const mConfirm = matchRoute(route, "/login/confirmar/:token");
  if (mConfirm) return <ConfirmEmail token={mConfirm.token} />;

  // Criação de conta pública — só existe se habilitada na sessão Segurança
  if (route === "/login/registrar") {
    return state.security.allowRegistration ? <Register /> : <NotFound />;
  }

  // Login — rota /login (também alcançável por #/login em servidores sem fallback)
  if (route === "/login") return <Login />;

  // Rotas administrativas: sem sessão válida → 404 (não revela o painel)
  if (route.startsWith("/admin")) {
    if (!isAuthenticated() || !getSession()) return <NotFound />;
    const user = getCurrentUser();
    if (!user || !user.active) {
      destroySession();
      return <NotFound />;
    }
    // Perfil Editor não acessa o back-end (somente o site/front-end)
    if (user.role !== "admin") return <NotFound state={state} />;
    return (
      <AdminLayout state={state} route={route}>
        <AdminRoutes route={route} state={state} />
      </AdminLayout>
    );
  }

  // Modo manutenção bloqueia o site público (painel e login continuam acessíveis)
  if (state.security.maintenance) return <Maintenance state={state} />;

  const mCat = matchRoute(route, "/categoria/:slug");
  const mForum = matchRoute(route, "/forum/:id");
  const mProfile = matchRoute(route, "/forum/u/:username");
  // Página principal configurável em Painel → SEO: home, loja ou fórum.
  // A home original continua acessível em /inicio.
  // Página inicial: tema escolhido em Painel → Tema (Original ou um dos 10 modelos de Revista Digital)
  const HomePage = state.theme?.template && state.theme.template !== "original" ? MagazineHome : Home;
  if (route === "/") {
    const hp = state.seo?.homepage || "home";
    if (hp === "loja" && state.features?.loja !== false) return <Loja state={state} />;
    if (hp === "forum" && state.features?.forum !== false) return <ForumIndex state={state} />;
    return <HomePage state={state} />;
  }
  if (route === "/inicio") return <HomePage state={state} />;
  if (route === "/podcasts") return <Podcasts state={state} />;
  if (route === "/feed") return <Feed state={state} tab="imagens" />;
  const mFeed = matchRoute(route, "/feed/:tab");
  if (mFeed) return <Feed state={state} tab={mFeed.tab} />;
  if (route === "/loja") return <Loja state={state} />;
  if (route === "/forum") return <ForumIndex state={state} />;
  if (mProfile) return <ForumProfile state={state} username={mProfile.username} />;
  if (route === "/forum/novo") return <ForumNew state={state} />;
  if (mForum && mForum.id !== "novo") return <ForumTopic state={state} id={mForum.id} />;
  if (mCat) return <CategoryPage state={state} slug={mCat.slug} />;
  // Artigos: URL conforme a estrutura escolhida em Painel → SEO (sem "/artigo/" por padrão).
  // URLs antigas/alternativas (ex.: /artigo/slug) redirecionam para a canônica.
  const resolved = resolveArticle(route, state);
  if (resolved) {
    if (resolved.redirect) return <Redirect to={resolved.canonical} />;
    return <ArticlePage state={state} slug={resolved.article.slug} />;
  }
  return <NotFound state={state} />;
}

/** Redireciona (replace) para a URL canônica. */
function Redirect({ to }) {
  useEffect(() => {
    window.history.replaceState({}, "", to);
    // adia o evento: efeitos de filhos rodam antes do listener de rota do App ser registrado
    const t = setTimeout(() => window.dispatchEvent(new Event("routechange")), 0);
    return () => clearTimeout(t);
  }, [to]);
  return null;
}

function getRouteSafe() {
  try {
    const h = window.location.hash;
    if (h && h.length > 1) return h.slice(1);
    return window.location.pathname || "/";
  } catch {
    return "/";
  }
}

/** Sub-rotas do painel administrativo. */
function AdminRoutes({ route, state }) {
  // A sessão Segurança (gerenciar usuários) é restrita a administradores.
  if (route.startsWith("/admin/seguranca") && !isAdmin()) return <Dashboard state={state} />;
  if (route === "/admin") return <Dashboard state={state} />;
  if (route === "/admin/artigos") return <ArticlesList state={state} />;
  if (route === "/admin/artigos/novo") return <ArticleEditor state={state} id={null} />;
  const mEdit = matchRoute(route, "/admin/artigos/editar/:id");
  if (mEdit) return <ArticleEditor state={state} id={mEdit.id} />;
  if (route === "/admin/categorias") return <CategoriesAdmin state={state} />;
  if (route === "/admin/seo") return <SeoAdmin state={state} />;
  if (route === "/admin/seguranca") return <SecurityAdmin state={state} />;
  if (route === "/admin/menus") return <MenusAdmin state={state} />;
  if (route === "/admin/podcasts") return <PodcastsAdmin state={state} />;
  if (route === "/admin/marca") return <BrandingAdmin state={state} />;
  if (route === "/admin/loja") return <LojaAdmin state={state} />;
  if (route === "/admin/forum") return <ForumAdmin state={state} />;
  if (route === "/admin/traducao") return <TranslationAdmin state={state} />;
  if (route === "/admin/tema") return <ThemeAdmin state={state} />;
  if (route === "/admin/html") return <HtmlAdmin state={state} />;
  if (route === "/admin/redes-sociais") return <SocialAdmin state={state} />;
  if (route === "/admin/rodape") return <FooterAdmin state={state} />;
  if (route === "/admin/comentarios") return <CommentsAdmin state={state} />;
  return <NotFound />;
}
