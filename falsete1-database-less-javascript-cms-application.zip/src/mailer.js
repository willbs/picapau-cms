// Envio de e-mails do site (Painel → Segurança → SMTP).
// O navegador envia a mensagem + configurações SMTP para o servidor de envio (smtp-relay/),
// que fala SMTP com o seu provedor (Gmail, Outlook, Zoho, Hostinger, SendGrid, etc.).
import { loadState, updateState } from "./store.js";
import { uid } from "./utils.js";

export const DEFAULT_SMTP = {
  enabled: false,
  host: "",
  port: 587,
  security: "starttls", // "starttls" (587) | "ssl" (465) | "none"
  user: "",
  pass: "",
  fromName: "",
  fromEmail: "",
  replyTo: "",
  adminEmail: "", // recebe avisos do site (ex.: nova conta criada)
  notifyNewAccounts: true,
  relayUrl: "http://localhost:3001/send",
  relayKey: "",
  log: [],
};

export function smtpConfig(state) {
  return { ...DEFAULT_SMTP, ...(state.smtp || {}) };
}

/** SMTP habilitado e minimamente configurado? */
export function smtpReady(state = loadState()) {
  const c = smtpConfig(state);
  return !!(c.enabled && c.host && c.fromEmail && c.relayUrl);
}

function logMail(entry) {
  updateState((s) => {
    s.smtp = smtpConfig(s);
    s.smtp.log = [{ id: uid(), at: new Date().toISOString(), ...entry }, ...s.smtp.log].slice(0, 40);
  });
}

/** Envia um e-mail. Lança erro com mensagem amigável em caso de falha. */
export async function sendMail({ to, subject, html, text, kind = "geral" }) {
  const c = smtpConfig(loadState());
  if (!c.enabled) throw new Error("O envio de e-mails (SMTP) está desativado.");
  if (!c.host || !c.fromEmail) throw new Error("Configure o servidor SMTP e o e-mail do remetente.");
  if (!c.relayUrl) throw new Error("Informe o endereço do servidor de envio.");
  let res;
  try {
    res = await fetch(c.relayUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Relay-Key": c.relayKey || "" },
      body: JSON.stringify({
        smtp: { host: c.host, port: Number(c.port), security: c.security, user: c.user, pass: c.pass },
        message: { fromName: c.fromName, fromEmail: c.fromEmail, replyTo: c.replyTo, to: [to], subject, html, text },
      }),
    });
  } catch {
    const err = `Não foi possível falar com o servidor de envio em ${c.relayUrl}. Ele está rodando?`;
    logMail({ kind, to, subject, ok: false, error: err });
    throw new Error(err);
  }
  let data = {};
  try { data = await res.json(); } catch { /* resposta sem JSON */ }
  if (!res.ok || !data.ok) {
    const err = data.error || `Servidor de envio respondeu ${res.status}.`;
    logMail({ kind, to, subject, ok: false, error: err });
    throw new Error(err);
  }
  logMail({ kind, to, subject, ok: true });
  return data;
}

/** Verifica se o servidor de envio está no ar (GET /health). */
export async function relayHealth(relayUrl) {
  const url = String(relayUrl || "").replace(/\/send\/?$/, "") + "/health";
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Respondeu ${res.status}`);
  return res.json();
}

/* ------------------------------ modelos de e-mail ------------------------------ */

const site = () => {
  const s = loadState();
  return s.branding?.siteName || s.seo?.title || "Pica-Pau";
};

function layout(title, body) {
  return `<!doctype html><html><body style="margin:0;background:#f1f5f9;font-family:Arial,Helvetica,sans-serif;color:#0f172a">
<div style="max-width:560px;margin:24px auto;background:#fff;border-radius:14px;overflow:hidden;border:1px solid #e2e8f0">
<div style="background:#0f172a;color:#fff;padding:18px 24px;font-weight:bold;font-size:18px">${site()}</div>
<div style="padding:24px"><h1 style="font-size:20px;margin:0 0 12px">${title}</h1>${body}</div>
<div style="padding:14px 24px;background:#f8fafc;color:#64748b;font-size:12px">Mensagem automática enviada por ${site()}.</div>
</div></body></html>`;
}
const button = (href, label) =>
  `<p style="margin:22px 0"><a href="${href}" style="background:#f59e0b;color:#0f172a;text-decoration:none;font-weight:bold;padding:12px 20px;border-radius:10px;display:inline-block">${label}</a></p>`;

export function resetPasswordEmail(link) {
  return {
    subject: `Redefinição de senha — ${site()}`,
    html: layout("Redefinição de senha", `<p>Recebemos um pedido para redefinir a senha da sua conta.</p>${button(link, "Redefinir minha senha")}
<p style="font-size:13px;color:#475569">Ou copie e cole no navegador:<br><a href="${link}">${link}</a></p>
<p style="font-size:13px;color:#475569">O link vale por 30 minutos e só pode ser usado uma vez. Se não foi você, ignore este e-mail.</p>`),
  };
}

export function welcomeEmail(email, loginUrl) {
  return {
    subject: `Bem-vindo(a) ao ${site()}!`,
    html: layout("Sua conta foi criada 🎉", `<p>Olá! A conta <strong>${email}</strong> foi criada com sucesso.</p>${button(loginUrl, "Acessar minha conta")}
<p style="font-size:13px;color:#475569">Se você não criou esta conta, responda este e-mail.</p>`),
  };
}

export function newAccountAdminEmail(email) {
  return {
    subject: `Nova conta criada no ${site()}`,
    html: layout("Nova conta criada", `<p>Um novo usuário se cadastrou no site:</p><p style="font-size:16px"><strong>${email}</strong></p>
<p style="font-size:13px;color:#475569">Gerencie os usuários em Painel → Segurança → Usuários cadastrados.</p>`),
  };
}

export function confirmEmail(link) {
  return {
    subject: `Confirme seu e-mail — ${site()}`,
    html: layout("Confirme seu e-mail", `<p>Obrigado por criar sua conta! Para ativá-la, confirme seu endereço de e-mail:</p>${button(link, "Confirmar meu e-mail")}
<p style="font-size:13px;color:#475569">Ou copie e cole no navegador:<br><a href="${link}">${link}</a></p>
<p style="font-size:13px;color:#475569">O link vale por 48 horas. Você só conseguirá entrar no site depois de confirmar. Se não foi você, ignore este e-mail.</p>`),
  };
}

export function testEmail(message) {
  return {
    subject: `E-mail de teste — ${site()}`,
    html: layout("✅ SMTP funcionando", `<p>${String(message || "Este é um e-mail de teste enviado pelas configurações SMTP do painel.").replace(/</g, "&lt;").replace(/\n/g, "<br>")}</p>
<p style="font-size:13px;color:#475569">Enviado em ${new Date().toLocaleString("pt-BR")}.</p>`),
  };
}
