import { articlePath } from "./permalink.js";

// Aplica as configurações de SEO no <head> do documento dinamicamente.

function setMeta(attr, key, content) {
  if (!content) return;
  let el = document.head.querySelector(`meta[${attr}="${key}"]`);
  if (!el) {
    el = document.createElement("meta");
    el.setAttribute(attr, key);
    document.head.appendChild(el);
  }
  el.setAttribute("content", content);
}

function setLink(rel, href) {
  if (!href) return;
  let el = document.head.querySelector(`link[rel="${rel}"]`);
  if (!el) {
    el = document.createElement("link");
    el.setAttribute("rel", rel);
    document.head.appendChild(el);
  }
  el.setAttribute("href", href);
}

/**
 * Aplica o SEO no documento.
 * @param {object} seo   SEO global salvo no estado.
 * @param {object} over  Sobrescritas por página (title, description, canonical, ogImage...).
 * @param {boolean} noindex  Se true, aplica noindex, nofollow (login/painel).
 */
export function applySeo(seo, over = {}, noindex = false) {
  const siteUrl = (seo.siteUrl || "").replace(/\/$/, "");
  const title = over.title || seo.title || "Pica-Pau CMS";
  const description = over.description || seo.description || "";
  const keywords = over.keywords || seo.keywords || "";
  const canonical = over.canonical || (siteUrl ? `${siteUrl}${over.path || "/"}` : over.path || "");
  const ogImage = over.ogImage || seo.ogImage || "";
  const robots = noindex ? "noindex, nofollow" : seo.robots || "index, follow";

  document.title = title;
  document.documentElement.lang = seo.language || "pt-BR";
  setMeta("name", "description", description);
  setMeta("name", "keywords", keywords);
  setMeta("name", "robots", robots);
  setMeta("name", "author", seo.author || "Equipe Pica-Pau");
  setMeta("property", "og:title", title);
  setMeta("property", "og:description", description);
  setMeta("property", "og:type", over.ogType || seo.ogType || "website");
  setMeta("property", "og:site_name", seo.ogSiteName || seo.title || "Pica-Pau");
  if (canonical) setMeta("property", "og:url", canonical);
  if (ogImage) setMeta("property", "og:image", ogImage);
  setMeta("name", "twitter:card", seo.twitterCard || "summary_large_image");
  if (seo.twitterSite) setMeta("name", "twitter:site", seo.twitterSite);
  setMeta("name", "twitter:title", title);
  setMeta("name", "twitter:description", description);
  if (ogImage) setMeta("name", "twitter:image", ogImage);
  if (canonical) setLink("canonical", canonical);
  if (seo.favicon) setLink("icon", seo.favicon);
}

/** Gera o conteúdo do sitemap.xml a partir do estado. */
export function buildSitemap(state) {
  const base = (state.seo.siteUrl || "https://example.com").replace(/\/$/, "");
  const urls = [
    { loc: `${base}/`, changefreq: "daily", priority: "1.0" },
    ...state.categories.map((c) => ({
      loc: `${base}/categoria/${c.slug}`,
      changefreq: "weekly",
      priority: "0.8",
    })),
    ...state.articles
      .filter((a) => a.status === "publicado")
      .map((a) => ({
        loc: `${base}${articlePath(a, state)}`,
        changefreq: "monthly",
        priority: "0.7",
        lastmod: (a.updatedAt || a.date || "").slice(0, 10),
      })),
  ];
  const items = urls
    .map(
      (u) => `  <url>\n    <loc>${u.loc}</loc>\n    <changefreq>${u.changefreq}</changefreq>\n    <priority>${u.priority}</priority>${
        u.lastmod ? `\n    <lastmod>${u.lastmod}</lastmod>` : ""
      }\n  </url>`
    )
    .join("\n");
  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${items}\n</urlset>\n`;
}
