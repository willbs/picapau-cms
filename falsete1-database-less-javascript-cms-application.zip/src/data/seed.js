// Dados de exemplo (seed) — usados apenas na primeira execução.
// Tudo fica persistido no LocalStorage depois disso.
import { uid } from "../utils.js";
import { SOCIAL_NETWORKS } from "./socialNetworks.js";

const img = (seed, w = 1200, h = 700) => `https://picsum.photos/seed/${seed}/${w}/${h}`;

const CATS = [
  { slug: "tecnologia", name: "Tecnologia", icon: "💻", color: "#3b82f6", description: "Novidades, análises e tutoriais sobre o mundo da tecnologia." },
  { slug: "ia", parent: "tecnologia", name: "Inteligência Artificial", icon: "🤖", color: "#8b5cf6", description: "Modelos de linguagem, automação e o futuro da IA." },
  { slug: "design", name: "Design", icon: "🎨", color: "#ec4899", description: "UI, UX, tipografia e processos criativos." },
  { slug: "marketing", name: "Marketing Digital", icon: "📣", color: "#f59e0b", description: "Estratégias de crescimento, SEO e conteúdo." },
  { slug: "games", name: "Games", icon: "🎮", color: "#10b981", description: "Lançamentos, reviews e bastidores da indústria de jogos." },
  { slug: "cinema", name: "Cinema & Séries", icon: "🎬", color: "#ef4444", description: "Filmes, séries e tudo sobre entertainment." },
  { slug: "musica", name: "Música", icon: "🎵", color: "#06b6d4", description: "Novos lançamentos, playlists e podcasts." },
  { slug: "esportes", name: "Esportes", icon: "⚽", color: "#22c55e", description: "Cobertura de campeonatos e análises." },
  { slug: "viagens", name: "Viagens", icon: "✈️", color: "#0ea5e9", description: "Roteiros, dicas e destinos incríveis." },
  { slug: "gastronomia", name: "Gastronomia", icon: "🍽️", color: "#f97316", description: "Receitas, restaurantes e cultura gastronômica." },
  { slug: "moda", name: "Moda", icon: "👗", color: "#d946ef", description: "Tendências, estilo e mercado da moda." },
  { slug: "ciencia", name: "Ciência", icon: "🔬", color: "#6366f1", description: "Descobertas e pesquisas que moldam o futuro." },
  { slug: "saude", name: "Saúde", icon: "💪", color: "#14b8a6", description: "Bem-estar, medicina e qualidade de vida." },
  { slug: "educacao", name: "Educação", icon: "📚", color: "#eab308", description: "Aprendizado, cursos e desenvolvimento pessoal." },
  { slug: "sustentabilidade", name: "Sustentabilidade", icon: "🌱", color: "#84cc16", description: "Meio ambiente, energia limpa e consumo consciente." },
];

const now = Date.now();
const daysAgo = (d) => new Date(now - d * 86400000).toISOString();

function article(partial) {
  return {
    id: uid(),
    type: "image",
    template: "hero",
    title: "",
    slug: "",
    excerpt: "",
    content: "",
    cover: "",
    author: "Equipe Pica-Pau",
    date: new Date().toISOString(),
    scheduledAt: "",
    status: "publicado",
    categories: [],
    seo: { title: "", description: "", keywords: "", ogImage: "", canonical: "" },
    media: {
      image: { url: "", alt: "", caption: "", gallery: [] },
      video: { url: "", poster: "", duration: "", transcript: "" },
      audio: { url: "", cover: "", duration: "", transcript: "", timestamps: [] },
    },
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    ...partial,
  };
}

function seedArticles() {
  return [
    /* ------------------------- ARTIGOS COM IMAGEM ------------------------- */
    article({
      type: "image",
      template: "hero",
      title: "IA generativa está redesenhando a criação de conteúdo",
      slug: "ia-generativa-redesenhando-conteudo",
      excerpt: "Como modelos de linguagem estão mudando a forma como produzimos textos, imagens e código.",
      categories: ["ia", "tecnologia"],
      cover: img("ia-hero", 1600, 900),
      date: daysAgo(1),
      content: `<p>A inteligência artificial generativa deixou de ser curiosidade de laboratório e virou ferramenta do dia a dia de redações, estúdios e equipes de produto. Modelos capable de escrever, resumir e até gerar imagens mudaram o ritmo da produção de conteúdo.</p>
<p>O ponto central não é substituir profissionais, mas <strong>ampliar o alcance criativo</strong>: rascunhos em segundos, testes de títulos em escala e personalização de mensagens para diferentes públicos.</p>
<h2>Onde a IA já faz diferença</h2>
<ul><li>Geração de rascunhos e resumos executivos</li><li>Assistência em código e depuração</li><li>Criação de variações de copy para testes A/B</li><li>Transcrição e legendagem automática de vídeos</li></ul>
<blockquote>“A IA não pensa pelo autor — ela devolve tempo para o autor pensar.”</blockquote>
<p>Ainda assim, o olhar humano segue essencial: curadoria, fato checado e voz editorial são o que separam conteúdo genérico de conteúdo memorável.</p>`,
      media: {
        image: { url: img("ia-hero", 1600, 900), alt: "Rede neural abstrata representando IA generativa", caption: "IA generativa: criação aumentada por algoritmos.", gallery: [img("ia-g1", 800, 600), img("ia-g2", 800, 600), img("ia-g3", 800, 600)] },
        video: { url: "", poster: "", duration: "", transcript: "" },
        audio: { url: "", cover: "", duration: "", transcript: "", timestamps: [] },
      },
      seo: {
        title: "IA generativa e conteúdo: o que muda para criadores | Pica-Pau",
        description: "Entenda como a IA generativa está transformando a produção de conteúdo e por que o olhar humano continua essencial.",
        keywords: "inteligência artificial, IA generativa, conteúdo, automação",
        ogImage: img("ia-hero", 1200, 630),
        canonical: "",
      },
    }),
    article({
      type: "image",
      template: "gallery",
      title: "Design systems escaláveis: lições de times grandes",
      slug: "design-systems-escalaveis",
      excerpt: "Componentes reutilizáveis, tokens de design e governança leve são a base de um design system que cresce com o produto.",
      categories: ["design", "tecnologia"],
      cover: img("design-cover", 1600, 900),
      date: daysAgo(3),
      content: `<p>Todo produto que cresce reencontra o mesmo problema: decisões de design inconsistentes entre telas. O design system resolve isso tratando a interface como um <em>produto dentro do produto</em>.</p>
<h2>Os três pilares</h2>
<ol><li><strong>Tokens</strong>: cores, espaçamentos e tipografia como variáveis únicas.</li><li><strong>Componentes</strong>: botões, campos e cards com API previsível.</li><li><strong>Governança</strong>: processos leves para propor, aprovar e versionar mudanças.</li></ol>
<p>O segredo não é a ferramenta, e sim o acordo entre design e engenharia.</p>`,
      media: {
        image: { url: img("design-cover", 1600, 900), alt: "Componentes de interface de um design system", caption: "Componentes reutilizáveis são o núcleo de um design system.", gallery: [img("ds-1", 800, 600), img("ds-2", 800, 600), img("ds-3", 800, 600), img("ds-4", 800, 600)] },
        video: { url: "", poster: "", duration: "", transcript: "" },
        audio: { url: "", cover: "", duration: "", transcript: "", timestamps: [] },
      },
      seo: {
        title: "Design systems escaláveis: guia prático | Pica-Pau",
        description: "Tokens, componentes e governança: os três pilares de um design system que escala com o produto.",
        keywords: "design system, UI, UX, componentes, tokens",
        ogImage: img("design-cover", 1200, 630),
        canonical: "",
      },
    }),
    article({
      type: "image",
      template: "fullscreen",
      title: "Patagônia em 10 dias: o roteiro completo",
      slug: "patagonia-roteiro-10-dias",
      excerpt: "Torres del Paine, glaciar Perito Moreno e a Carretera Austral em um roteiro testado de 10 dias.",
      categories: ["viagens"],
      cover: img("patagonia", 1920, 1080),
      date: daysAgo(5),
      content: `<p>A Patagônia é daquelas regiões que parecemPhotoshop da vida real: ventos de 100 km/h, montanhas de granito e lagos de um azul irreal.</p>
<h2>Dias 1–3: Torres del Paine</h2>
<p>Base em Puerto Natales e trilhas como a do Mirante Las Torres. Leve casaco corta-vento <strong>obrigatoriamente</strong>.</p>
<h2>Dias 4–7: El Calafate</h2>
<p>O glaciar Perito Moreno é o cartão-postal da região — faça o minitrekking no gelo.</p>
<h2>Dias 8–10: Carretera Austral</h2>
<p>Estrada de cascalho, cavernas de mármore e pouquíssima gente. Perfeito para desacelerar.</p>`,
      media: {
        image: { url: img("patagonia", 1920, 1080), alt: "Montanhas da Patagônia ao amanhecer", caption: "Torres del Paine, Chile.", gallery: [img("pat-1", 800, 600), img("pat-2", 800, 600)] },
        video: { url: "", poster: "", duration: "", transcript: "" },
        audio: { url: "", cover: "", duration: "", transcript: "", timestamps: [] },
      },
      seo: {
        title: "Patagônia em 10 dias: roteiro completo | Pica-Pau Viagens",
        description: "Roteiro completo de 10 dias pela Patagônia: Torres del Paine, glaciar Perito Moreno e a Carretera Austral.",
        keywords: "patagônia, viagem, roteiro, torres del paine, el calafate",
        ogImage: img("patagonia", 1200, 630),
        canonical: "",
      },
    }),

    /* ------------------------- ARTIGOS COM VÍDEO ------------------------- */
    article({
      type: "video",
      template: "top",
      title: "React do zero: construa sua primeira aplicação em 30 minutos",
      slug: "react-do-zero-primeira-app",
      excerpt: "Um tutorial em vídeo completo para sair do zero e publicar um app React.",
      categories: ["tecnologia", "educacao"],
      cover: img("react-tut", 1600, 900),
      date: daysAgo(2),
      content: `<p>Neste vídeo, passo a passo você cria um projeto React, entende componentes e publica o resultado. É o melhor ponto de partida para quem está começando.</p>
<h2>O que você vai aprender</h2>
<ul><li>Estrutura de um projeto moderno com Vite</li><li>Componentes e props</li><li>Estado com hooks</li><li>Publicação gratuita</li></ul>
<p>Assista ao vídeo abaixo e acompanhe o código no seu ritmo.</p>`,
      media: {
        image: { url: "", alt: "", caption: "", gallery: [] },
        video: { url: "https://www.youtube.com/watch?v=aqz-KE-bpKQ", poster: img("react-tut", 1280, 720), duration: "10:24", transcript: "00:00 Introdução ao React\n02:10 Criando o projeto com Vite\n05:40 Componentes e props\n08:15 Estado com useState\n10:00 Publicando o app" },
        audio: { url: "", cover: "", duration: "", transcript: "", timestamps: [] },
      },
      seo: {
        title: "React do zero em 30 minutos (vídeo) | Pica-Pau",
        description: "Tutorial em vídeo: crie e publique sua primeira aplicação React do zero em 30 minutos.",
        keywords: "react, tutorial, vídeo, javascript, vite",
        ogImage: img("react-tut", 1200, 630),
        canonical: "",
      },
    }),
    article({
      type: "video",
      template: "playlist",
      title: "Vida selvagem em 4K: documentários para maratonar",
      slug: "documentarios-vida-selvagem-4k",
      excerpt: "Uma seleção de documentários em alta definição sobre a natureza — com playlist de vídeos relacionados.",
      categories: ["ciencia", "cinema"],
      cover: img("wildlife", 1600, 900),
      date: daysAgo(4),
      content: `<p>Nadafascinante como ver a natureza de perto. Reunimos documentários em 4K que valem cada minuto da sua maratona.</p>
<p>Comece pelo vídeo abaixo e continue pelos relacionados na playlist ao lado.</p>`,
      media: {
        image: { url: "", alt: "", caption: "", gallery: [] },
        video: { url: "https://www.youtube.com/watch?v=LXb3EKWsInQ", poster: img("wildlife", 1280, 720), duration: "52:16", transcript: "" },
        audio: { url: "", cover: "", duration: "", transcript: "", timestamps: [] },
      },
      seo: {
        title: "Documentários de vida selvagem em 4K | Pica-Pau",
        description: "Maratone os melhores documentários sobre natureza em 4K, com playlist de vídeos relacionados.",
        keywords: "documentário, natureza, 4K, vida selvagem, vídeo",
        ogImage: img("wildlife", 1200, 630),
        canonical: "",
      },
    }),
    article({
      type: "video",
      template: "side",
      title: "Entrevista: como é criar um jogo indie no Brasil",
      slug: "entrevista-game-dev-indie-brasil",
      excerpt: "Conversamos com um estúdio independente sobre os desafios de lançar um jogo no mercado brasileiro.",
      categories: ["games", "cinema"],
      cover: img("gamedev", 1600, 900),
      date: daysAgo(6),
      content: `<p>Criar um jogo indie no Brasil é um ato de resistência e paixãão. Nesta entrevista, o time conta como foi do protótipo ao lançamento na Steam.</p>
<h2>Principais aprendizados</h2>
<ul><li>Comece pequeno: um loop de jogo divertido vale mais que dez mecânicas</li><li>Comunidade é marketing gratuito</li><li>Planeje o lançamento com antecedência</li></ul>
<p>Assista à entrevista completa no vídeo ao lado.</p>`,
      media: {
        image: { url: "", alt: "", caption: "", gallery: [] },
        video: { url: "https://www.youtube.com/watch?v=ScMzIvxBSi4", poster: img("gamedev", 1280, 720), duration: "18:42", transcript: "" },
        audio: { url: "", cover: "", duration: "", transcript: "", timestamps: [] },
      },
      seo: {
        title: "Criar um jogo indie no Brasil: entrevista | Pica-Pau Games",
        description: "Entrevista em vídeo com um estúdio indie brasileiro sobre os desafios de lançar um jogo.",
        keywords: "games, indie, entrevista, desenvolvimento de jogos, brasil",
        ogImage: img("gamedev", 1200, 630),
        canonical: "",
      },
    }),

    /* ------------------------- ARTIGOS COM ÁUDIO ------------------------- */
    article({
      type: "audio",
      template: "cover",
      title: "Podcast Pica-Pau #01 — O futuro da inteligência artificial",
      slug: "podcast-futuro-da-ia",
      excerpt: "Episódio de estreia do nosso podcast: o que esperar da IA nos próximos 10 anos.",
      categories: ["ia", "musica"],
      cover: img("podcast-cover", 1600, 900),
      date: daysAgo(1),
      content: `<p>No episódio de estreia do <strong>Podcast Pica-Pau</strong> conversamos sobre o futuro da inteligência artificial: o que já é real, o que é exagero e como se preparar.</p>
<h2>Temas do episódio</h2>
<ul><li>IA no trabalho: ferramenta ou ameaça?</li><li>Regulação e ética</li><li>Como estudar IA hoje</li></ul>
<p>Ouça agora no player abaixo.</p>`,
      media: {
        image: { url: "", alt: "", caption: "", gallery: [] },
        video: { url: "", poster: "", duration: "", transcript: "" },
        audio: {
          url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
          cover: img("podcast-cover", 800, 800),
          duration: "32:10",
          transcript: "Transcrição do episódio 01 disponível em breve.",
          timestamps: [],
        },
      },
      seo: {
        title: "Podcast #01 — O futuro da IA | Pica-Pau",
        description: "Episódio de estreia do Podcast Pica-Pau sobre o futuro da inteligência artificial. Ouça agora.",
        keywords: "podcast, IA, inteligência artificial, episódio",
        ogImage: img("podcast-cover", 1200, 630),
        canonical: "",
      },
    }),
    article({
      type: "audio",
      template: "timestamps",
      title: "Podcast Pica-Pau #02 — Empreender com pouco recurso",
      slug: "podcast-empreender-com-pouco-recurso",
      excerpt: "Como começar um negócio com pouco dinheiro: evite os erros comuns e siga um plano realista.",
      categories: ["marketing", "educacao"],
      cover: img("podcast-2", 1600, 900),
      date: daysAgo(7),
      content: `<p>Neste episódio, falamos sobre <strong>empreender com pouco recurso</strong>: valide antes de investir, use o que você já tem e fuja dos erros que quebram pequenos negócios.</p>
<p>Use os marcadores de tempo abaixo para pular direto para o trecho que te interessa.</p>`,
      media: {
        image: { url: "", alt: "", caption: "", gallery: [] },
        video: { url: "", poster: "", duration: "", transcript: "" },
        audio: {
          url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
          cover: img("podcast-2", 800, 800),
          duration: "27:45",
          transcript: "00:00 Abertura\n02:30 Validar antes de investir\n09:15 Erros comuns de quem começa\n16:40 Marketing com pouco dinheiro\n22:30 Plano de 90 dias\n27:00 Encerramento",
          timestamps: [
            { time: 0, label: "Abertura" },
            { time: 150, label: "Validar antes de investir" },
            { time: 555, label: "Erros comuns de quem começa" },
            { time: 1000, label: "Marketing com pouco dinheiro" },
            { time: 1350, label: "Plano de 90 dias" },
            { time: 1620, label: "Encerramento" },
          ],
        },
      },
      seo: {
        title: "Podcast #02 — Empreender com pouco recurso | Pica-Pau",
        description: "Episódio com timestamps sobre como começar um negócio com pouco recurso e evitar erros comuns.",
        keywords: "podcast, empreendedorismo, negócios, episódio",
        ogImage: img("podcast-2", 1200, 630),
        canonical: "",
      },
    }),
    article({
      type: "audio",
      template: "sticky",
      title: "Trilha sonora para foco: mix de 40 minutos",
      slug: "trilha-sonora-para-foco",
      excerpt: "Um mix instrumental contínuo para manter o foco durante estudos e trabalho. Player fixo na página.",
      categories: ["musica", "saude"],
      cover: img("focus-mix", 1600, 900),
      date: daysAgo(8),
      content: `<p>Algumas pessoas precisam de silêncio; outras, de música. Se você é do segundo grupo, este mix foi feito para acompanhar sessões longas de foco.</p>
<p>O player fica <strong>fixo no rodapé da página</strong> enquanto você lê — é só dar play e continuar rolando.</p>
<h2>Dica</h2>
<p>Use fones de ouvido e mantenha o volume baixo: o objetivo é presença, não distração.</p>`,
      media: {
        image: { url: "", alt: "", caption: "", gallery: [] },
        video: { url: "", poster: "", duration: "", transcript: "" },
        audio: {
          url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
          cover: img("focus-mix", 800, 800),
          duration: "40:00",
          transcript: "",
          timestamps: [],
        },
      },
      seo: {
        title: "Trilha sonora para foco (mix 40 min) | Pica-Pau Música",
        description: "Mix instrumental de 40 minutos com player fixo para acompanhar seus estudos e trabalho com foco.",
        keywords: "música para foco, lo-fi, playlist, estudo",
        ogImage: img("focus-mix", 1200, 630),
        canonical: "",
      },
    }),
  ];
}

function seedMenus() {
  const catLink = (slug, label, desc = "") => ({
    id: uid(),
    label,
    type: "category",
    categorySlug: slug,
    url: `/categoria/${slug}`,
    desc,
    image: "",
  });
  return [
    {
      id: uid(),
      name: "Principal",
      location: "header",
      isMain: true,
      items: [
        { id: uid(), label: "Início", type: "link", url: "/", children: [] },
        {
          id: uid(),
          label: "Categorias",
          type: "mega",
          mega: true,
          columns: [
            {
              id: uid(),
              title: "Explorar",
              links: [
                catLink("tecnologia", "Tecnologia", "Novidades e tutoriais de tech"),
                catLink("ia", "Inteligência Artificial", "O futuro da IA no dia a dia"),
                catLink("design", "Design", "UI, UX e processos criativos"),
                catLink("games", "Games", "Lançamentos e reviews"),
                catLink("ciencia", "Ciência", "Descobertas que moldam o futuro"),
                catLink("viagens", "Viagens", "Roteiros e destinos incríveis"),
              ],
            },
            {
              id: uid(),
              title: "Em alta",
              links: [
                catLink("marketing", "Marketing Digital", "Crescimento e conteúdo"),
                catLink("cinema", "Cinema & Séries", "Filmes e séries"),
                catLink("musica", "Música", "Lançamentos e podcasts"),
                catLink("gastronomia", "Gastronomia", "Receitas e restaurantes"),
                catLink("sustentabilidade", "Sustentabilidade", "Meio ambiente e energia limpa"),
              ],
            },
            {
              id: uid(),
              title: "Destaque",
              links: [
                {
                  id: uid(),
                  label: "IA generativa e conteúdo",
                  type: "article",
                  articleSlug: "ia-generativa-redesenhando-conteudo",
                  url: "/artigo/ia-generativa-redesenhando-conteudo",
                  desc: "Como a IA está mudando a criação de conteúdo",
                  image: img("ia-hero", 600, 400),
                },
              ],
            },
          ],
        },
        {
          id: uid(),
          label: "Tecnologia",
          type: "category",
          categorySlug: "tecnologia",
          url: "/categoria/tecnologia",
          children: [
            { id: uid(), label: "Inteligência Artificial", type: "category", categorySlug: "ia", url: "/categoria/ia", children: [] },
            { id: uid(), label: "Games", type: "category", categorySlug: "games", url: "/categoria/games", children: [
              { id: uid(), label: "Entrevistas", type: "article", articleSlug: "entrevista-game-dev-indie-brasil", url: "/artigo/entrevista-game-dev-indie-brasil", children: [] },
            ] },
          ],
        },
      ],
    },
    {
      id: uid(),
      name: "Rodapé",
      location: "footer",
      isMain: false,
      items: [
        catLink("tecnologia", "Tecnologia"),
        catLink("ia", "IA"),
        catLink("design", "Design"),
        catLink("games", "Games"),
        catLink("viagens", "Viagens"),
      ],
    },
  ];
}

/** Dados de exemplo da Loja Virtual. */
export function seedLoja() {
  const products = [
    {
      id: uid(), name: "Camiseta Pica-Pau Preta", slug: "camiseta-pica-pau-preta",
      price: 79.9, description: "Algodão premium 100%, estampa frontal do pica-pau.",
      image: img("produto-camiseta", 800, 800), category: "Camisetas", stock: 12, active: true, createdAt: daysAgo(9),
    },
    {
      id: uid(), name: "Caneca térmica 350ml", slug: "caneca-termica-350ml",
      price: 49.9, description: "Aço inox de parede dupla — mantém a temperatura por horas.",
      image: img("produto-caneca", 800, 800), category: "Canecas", stock: 20, active: true, createdAt: daysAgo(8),
    },
    {
      id: uid(), name: "Kit de adesivos", slug: "kit-de-adesivos",
      price: 19.9, description: "6 adesivos em vinil à prova d'água, tamanho variado.",
      image: img("produto-adesivos", 800, 800), category: "Adesivos", stock: 0, active: true, createdAt: daysAgo(7),
    },
    {
      id: uid(), name: "Caderno de anotações", slug: "caderno-de-anotacoes",
      price: 34.9, description: "Capa dura, 160 páginas pautadas, elástico.",
      image: img("produto-caderno", 800, 800), category: "Papelaria", stock: 30, active: true, createdAt: daysAgo(6),
    },
  ];
  // Produto de afiliado: o botão "Comprar" redireciona para o site parceiro
  products.push({
    id: uid(), name: "Fone Bluetooth com cancelamento de ruído", slug: "fone-bluetooth-afiliado",
    price: 299.9, oldPrice: 399.9, description: "Indicação da equipe — compra feita no site parceiro.",
    image: img("produto-fone", 800, 800), category: "Afiliados", stock: null, active: true,
    kind: "afiliado", affiliateUrl: "https://www.amazon.com.br/", affiliateStore: "Amazon",
    createdAt: daysAgo(5),
  });
  const orders = [
    {
      id: uid(),
      items: [{ productId: products[0].id, name: products[0].name, price: products[0].price, qty: 1 }],
      total: products[0].price,
      customer: { name: "Cliente demo", email: "cliente@exemplo.com" },
      createdAt: daysAgo(2),
      status: "enviado",
    },
  ];
  products.forEach((p) => { if (!p.kind) p.kind = "proprio"; });
  return { products, orders, template: "grade" };
}

/** Dados de exemplo do Fórum. */
export function seedForum() {
  const categories = [
    { id: uid(), slug: "geral", name: "Geral", icon: "💬", description: "Conversa sobre qualquer assunto do portal." },
    { id: uid(), slug: "duvidas", name: "Dúvidas", icon: "❓", description: "Tire dúvidas sobre artigos, tutoriais e vídeos." },
    { id: uid(), slug: "ideias", name: "Ideias & projetos", icon: "💡", description: "Compartilhe ideias, projetos e sugestões de pauta." },
  ];
  const topics = [
    {
      id: uid(),
      title: "Bem-vindos ao fórum do portal! 👋",
      body: "Este é o espaço para trocar ideias sobre os artigos, podcasts e vídeos publicados aqui. Seja gentil e divirta-se!",
      author: "Equipe Pica-Pau", category: "geral",
      createdAt: daysAgo(3), pinned: true, locked: false,
      replies: [
        { id: uid(), author: "Leitor anônimo", body: "Ótimo portal! Já li vários artigos. 👏", createdAt: daysAgo(2) },
        { id: uid(), author: "Maria", body: "Adorei a página de podcasts, os episódios estão ótimos.", createdAt: daysAgo(1) },
      ],
    },
    {
      id: uid(),
      title: "Que tema vocês gostariam de ouvir no próximo podcast?",
      body: "Estamos planejando o próximo episódio e queremos a opinión da comunidade. Comentem aqui!",
      author: "Equipe Pica-Pau", category: "ideias",
      createdAt: daysAgo(2), pinned: false, locked: false,
      replies: [
        { id: uid(), author: "João", body: "Queria um episódio sobre produtividade com IA.", createdAt: daysAgo(1) },
      ],
    },
    {
      id: uid(),
      title: "Como faço para incorporar um vídeo do YouTube no artigo?",
      body: "Criei um artigo do tipo vídeo e coloquei a URL do YouTube, mas não consigo ver o player. Alguém pode ajudar?",
      author: "Ana", category: "duvidas",
      createdAt: daysAgo(1), pinned: false, locked: false,
      replies: [
        { id: uid(), author: "Suporte", body: "Basta colar a URL completa do YouTube (watch?v=...) no campo de vídeo — o CMS converte para embed automaticamente.", createdAt: daysAgo(1) },
      ],
    },
  ];
  // Perfis de usuários do fórum (página de perfil personalizável)
  const idW = uid(), idM = uid(), idJ = uid();
  const profiles = [
    {
      id: idW, username: "willie", name: "Willie Bruno",
      bio: "Criador do portal. Fala sobre tecnologia, IA e podcasts. 🎙️",
      avatar: img("avatar-willie", 300, 300), cover: img("capa-willie", 1600, 500),
      template: "moderno", following: [idM], createdAt: daysAgo(10),
      videos: [
        { id: uid(), platform: "youtube", url: "https://www.youtube.com/watch?v=aqz-KE-bpKQ", title: "Big Buck Bunny (YouTube)" },
        { id: uid(), platform: "vimeo", url: "https://vimeo.com/76979871", title: "Vimeo — player demo" },
        { id: uid(), platform: "dailymotion", url: "https://www.dailymotion.com/video/x7tgad0", title: "Dailymotion demo" },
      ],
    },
    {
      id: idM, username: "maria", name: "Maria Souza",
      bio: "Designer e ouvinte assídua dos podcasts. Amo UI e música.",
      avatar: img("avatar-maria", 300, 300), cover: img("capa-maria", 1600, 500),
      template: "neon", following: [idW, idJ], createdAt: daysAgo(8),
      videos: [
        { id: uid(), platform: "youtube", url: "https://www.youtube.com/watch?v=LXb3EKWsInQ", title: "Natureza em 4K" },
      ],
    },
    {
      id: idJ, username: "joao", name: "João Lima",
      bio: "Dev indie e gamer. Sempre testando coisas novas.",
      avatar: img("avatar-joao", 300, 300), cover: img("capa-joao", 1600, 500),
      template: "minimal", following: [idW], createdAt: daysAgo(6),
      videos: [],
    },
  ];
  return { categories, topics, profiles, template: "classico" };
}

/** Sessão HTML: blocos de início/fim dos artigos, comentários e visualizações. */
export function seedHtml() {
  return {
    before: {
      enabled: true,
      mode: "html",
      content: '<div style="border-left:4px solid #f59e0b;background:#fffbeb;padding:10px 14px;border-radius:10px;color:#78350f;font-size:14px">📢 Você está lendo <strong>{{titulo}}</strong> — categoria {{categoria}}.</div>',
    },
    after: {
      enabled: true,
      mode: "html",
      content: '<div style="background:#0f172a;color:#e2e8f0;padding:18px;border-radius:14px;text-align:center"><strong>Gostou deste conteúdo?</strong><br/>Compartilhe com os amigos e acompanhe as novidades do {{site}}! 🚀</div>',
    },
    comments: { enabled: true, requireApproval: true }, // moderação em Painel → Comentários
    showViews: true,
    share: true,
    layout: "none", // "none" | "left" | "right" | "two-left" | "two-right"
  };
}

/** Redes sociais padrão (todas as 24, links oficiais, habilitadas). */
export function seedSocial() {
  return {
    enabled: true,
    items: SOCIAL_NETWORKS.map((n) => ({ id: uid(), network: n.id, url: n.url, enabled: true })),
  };
}

/** Rodapé padrão (Painel → Rodapé). */
export function seedFooter() {
  return {
    template: "classico",
    show: { brand: true, description: true, social: true, menus: true, bottomMenu: true, copyright: true, access: true, backToTop: false },
    copyright: "© {{ano}} {{site}}. CMS sem banco de dados — dados salvos no navegador.",
    bottomMenu: [
      { id: uid(), label: "🏠 Início", url: "/" },
      { id: uid(), label: "🎧 Podcasts", url: "/podcasts" },
      { id: uid(), label: "🛒 Loja", url: "/loja" },
      { id: uid(), label: "💬 Fórum", url: "/forum" },
    ],
  };
}

/** Categorias exclusivas de podcast. */
export function seedPodcastCategories() {
  return [
    { id: uid(), slug: "tecnologia-ia", name: "Tecnologia & IA", icon: "🤖", color: "#8b5cf6" },
    { id: uid(), slug: "negocios", name: "Negócios", icon: "💼", color: "#f59e0b" },
    { id: uid(), slug: "musica-foco", name: "Música & Foco", icon: "🎵", color: "#06b6d4" },
    { id: uid(), slug: "entrevistas", name: "Entrevistas", icon: "🎙️", color: "#6366f1" },
  ];
}
export const SEED_PODCAST_MAP = {
  "podcast-futuro-da-ia": "tecnologia-ia",
  "podcast-empreender-com-pouco-recurso": "negocios",
  "trilha-sonora-para-foco": "musica-foco",
};

/** Estado inicial completo do CMS (semeado no LocalStorage). */
export function seedState() {
  return {
    version: 1,
    createdAt: new Date().toISOString(),
    seo: {
      title: "Pica-Pau — Portal de Conteúdo",
      description:
        "Pica-Pau é um portal de conteúdo demo gerenciado por um CMS sem banco de dados: artigos com imagem, vídeo e áudio, tudo salvo no navegador.",
      keywords: "cms, portal, artigos, imagem, vídeo, áudio, localStorage",
      siteUrl: "https://login.exemplo.com",
      canonical: "",
      ogImage: img("og-site", 1200, 630),
      ogType: "website",
      ogSiteName: "Pica-Pau",
      twitterCard: "summary_large_image",
      twitterSite: "@picapau",
      favicon: "/favicon.svg",
      robots: "index, follow",
      language: "pt-BR",
      author: "Equipe Pica-Pau",
      homepage: "home", // página principal: "home" | "loja" | "forum"
      permalink: { structure: "titulo", base: "" }, // sem "/artigo/" por padrão
      robotsTxt:
        "User-agent: *\nDisallow: /login\nDisallow: /admin\n\nSitemap: /sitemap.xml\n",
    },
    // Marca do site: título exibido, logo e favicon (gerenciados em Painel → Marca)
    branding: {
      siteName: "Pica-Pau",
      logo: "",
      favicon: "/favicon.svg",
    },
    // Feature flags (ex.: página de podcasts habilitada/desabilitada)
    features: {
      podcast: true,
      loja: true, // botão habilitar/desabilitar em Painel → Loja
      forum: true, // botão habilitar/desabilitar em Painel → Fórum
    },
    categories: CATS.map((c) => ({
      id: uid(),
      ...c,
      image: "",
      seo: {
        title: `${c.name} | Pica-Pau`,
        description: c.description,
        keywords: c.name.toLowerCase(),
        ogImage: "",
      },
    })),
    articles: seedArticles().map((a) => (SEED_PODCAST_MAP[a.slug] ? { ...a, podcastCategory: SEED_PODCAST_MAP[a.slug] } : a)),
    podcast: { categories: seedPodcastCategories() },
    social: seedSocial(),
    footer: seedFooter(),
    // Tema da página inicial (Painel → Tema): "original" ou um dos 10 modelos de Revista Digital
    theme: { template: "original", blocks: ["hero","destaques","categorias","ultimos","porCategoria","maisLidos","videos","audios","loja","forum"].map((id) => ({ id, enabled: !["loja", "forum"].includes(id) })), featuredCategories: [], featuredArticles: [] },
    // SMTP (Painel → Segurança → SMTP): configuração manual do envio de e-mails
    smtp: { enabled: false, host: "", port: 587, security: "starttls", user: "", pass: "", fromName: "", fromEmail: "", replyTo: "", adminEmail: "", notifyNewAccounts: true, relayUrl: "http://localhost:3001/send", relayKey: "", log: [] },
    backup: { auto: { enabled: false, frequency: "daily", local: true, drive: false, keep: 10 }, drive: { clientId: "" }, lastAuto: 0, history: [] },
    // Tradução (Painel → Tradução): idiomas habilitados, padrão, automática e traduções manuais
    i18n: { enabled: true, default: "pt-BR", languages: { "pt-BR": true, en: true, es: true, it: true, fr: true }, auto: true, phrases: {} },
    menus: seedMenus(),
    html: seedHtml(),
    comments: [],
    views: {},
    loja: seedLoja(),
    forum: seedForum(),
    security: {
      // Vários usuários cadastrados (login por e-mail + hash SHA-256)
      users: [
        {
          id: uid(),
          email: "demo@demo.com",
          // SHA-256("pica-pau-cms-v1::Demo123") — credenciais: demo@demo.com / Demo123
          passwordHash: "c751c8ee0e638035bc80e7c51c7f88e9653968f339f088758f2f97a5e38af3f0",
          role: "admin",
          active: true,
          emailVerified: true,
          createdAt: new Date().toISOString(),
        },
      ],
      sessionMinutes: 30,
      rateLimit: true,
      lockout: true,
      maintenance: false,
      allowRegistration: false, // habilita/desabilita criação de novas contas no login
      privacyUrl: "", // link das políticas de privacidade (aceite obrigatório ao entrar)
      privacyVersion: 0,
      logs: [
        {
          id: uid(),
          time: new Date().toISOString(),
          type: "sistema",
          message: "CMS inicializado com dados de exemplo (15 categorias, 9 artigos).",
        },
      ],
    },
  };
}
