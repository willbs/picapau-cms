# 🪵 Pica-Pau CMS

CMS (Gerenciador de Conteúdo) completo **sem banco de dados** e **sem TypeScript** —
todo o código é **JavaScript puro (ES6+)** em `.js`/`.jsx`, e toda a persistência
acontece no navegador via **LocalStorage**. O projeto usa **React 19 + Vite + Tailwind CSS v4**
(configurado em modo JavaScript).

## 🚀 Como executar

```bash
npm install
npm run dev      # desenvolvimento
npm run build    # gera dist/ (arquivo único, pronto para publicar)
npm run preview  # serve o build localmente
```

Publique o conteúdo de `dist/` em qualquer hospedagem estática (Vercel, Netlify, GitHub Pages…).

## 🔐 Como acessar o login

- **Rota de login:** navegue diretamente para **`/login`** (o antigo `/pica-pau` redireciona para cá) (também funciona como `/#/login`
  em servidores estáticos sem fallback de SPA — há um redirecionamento automático em
  `public/pica-pau/index.html`).
- **Botão discreto no rodapé:** na página pública, no canto inferior direito do rodapé,
  existe um botão discreto chamado **"Acesso"**, que leva à mesma página de login.
- A rota é **noindex, nofollow** (meta tag aplicada dinamicamente) e bloqueada no
  `robots.txt` (`Disallow: /login` e `Disallow: /admin`).

### Credenciais iniciais

| Usuário | Senha   |
|---------|---------|
| `admin` | `admin123` |

> A senha é guardada apenas como **hash SHA-256** (salt + senha) no LocalStorage — nunca em texto puro.
> Altere a senha em **Painel → Segurança → Alterar senha**.

### Proteções de acesso

- **Rate limiting:** após 3 tentativas falhas em 60s, é preciso aguardar.
- **Bloqueio:** após 5 falhas em 60s, o login fica bloqueado por 5 minutos.
- **Sessão persistente** via token no LocalStorage, com **logout automático por inatividade**
  (padrão 30 min, ajustável no painel).
- Acesso direto a `/admin*` sem sessão válida retorna **404** (o painel não é revelado).
- Todas as tentativas de login (sucesso/falha) ficam registradas em **Painel → Segurança → Logs**.

## 🎧 Página de Podcasts (`/podcasts`)

- Página dedicada que reúne **todos os artigos do tipo áudio (episódios) publicados, separados por categoria**, com episódio em destaque (player) e cards com capa, duração e botão "Ouvir".
- No painel (**Painel → Podcasts**) há um **botão de habilitar/desabilitar** a opção de podcast: desligado, `/podcasts` vira 404 e o link sai do menu. Nessa mesma sessão há o formulário **"+ Adicionar podcast"** (título, categoria obrigatória, URL do MP3, capa, duração, modelo do player, status) — o episódio é criado como artigo de áudio e vai direto para `/podcasts`.

## 🎨 Marca do site (Painel → Marca)

- Nova sessão para mudar o **título do site**, a **logo** (cabeçalho/rodapé do site público) e a **favicon** — com prévia ao vivo e aplicação imediata (título da aba, `og:site_name` e `rel="icon"`).

## 🔑 Recuperação de senha ("Esqueci a senha")

- Na página de login (`/login`) há o link **"Esqueci a senha"**: informe o e-mail cadastrado e um **link de redefinição** é gerado (token salvo no LocalStorage, válido por 30 min, uso único). Como o CMS é 100% local (sem servidor de e-mail), o "e-mail enviado" é exibido na própria tela em modo demo, com o link clicável para `/login/redefinir/:token`, onde se define a nova senha.

## 👥 Usuários e Segurança (Painel → Segurança)

- A sessão Segurança agora **gerencia usuários cadastrados**: cadastrar manualmente (e-mail + senha + perfil admin/editor + ativo), ativar/desativar, redefinir senha e excluir (com proteção para não remover o último admin ativo).
- Toggle **"Criação de novas contas"**: quando ligada, aparece o link **"Criar conta"** no login (`/login/registrar`, novos usuários entram como *editor*); quando desligada, a rota de registro retorna 404.
- Perfis: **admin** tem acesso total; **editor** não acessa a sessão Segurança.
- Mantidos: troca de senha (hash SHA-256), sessão com expiração por inatividade, rate limit, bloqueio por tentativas, modo manutenção e logs de acesso.

## 📤 Upload de arquivos (sem back-end)

- Na sessão **Artigos**, cada campo de mídia aceita **URL ou upload de arquivo**:
  imagem (URL/upload/galeria), vídeo (YouTube/Vimeo/URL `.mp4` **ou upload de vídeo**) e
  áudio (URL **ou upload de MP3**), além da **capa do artigo** com upload.
- Em **Painel → Marca**, a **logo** e a **favicon** aceitam upload de imagem
  (imagens são comprimidas/redimensionadas via canvas; favicon vira 64px).
- Em **Painel → Podcasts**, o episódio aceita **upload de áudio e de capa**.
- Como não há servidor, os arquivos são convertidos para **DataURL e salvos no LocalStorage**
  (imagens comprimidas; áudio/vídeo com limite de ~2,5 MB — acima disso, use URL externa).

## 🛒 Loja Virtual (painel → Loja + página `/loja`)

- Admin (`/admin/loja`): cadastrar/editar/excluir **produtos** (nome, slug, preço, descrição,
  categoria, estoque, ativo, **imagem por URL ou upload**) e acompanhar **pedidos** (status, total, cliente).
- Público (`/loja`): grade de produtos ativos com preços em R$, **carrinho** (quantidade, total)
  e finalização de compra, que registra o pedido no CMS (visível no painel).

## 💬 Fórum (painel → Fórum + página `/forum`)

- Público: `/forum` lista tópicos (fixados primeiro) com filtro por categoria e busca;
  `/forum/novo` cria tópico (autor, categoria, título, conteúdo); `/forum/:id` mostra o tópico
  e permite responder (bloqueado quando o tópico está locked).
- Admin (`/admin/forum`): **fixar/bloquear/excluir tópicos**, excluir respostas e
  **gerenciar categorias** do fórum (criar/editar/excluir).

## 🔀 Toggles, layouts, afiliados e perfis

- **Painel → Loja**: botão **habilitar/desabilitar a sessão Loja** (desligada → `/loja` 404 e link some do menu);
  escolha entre **5 páginas de produtos** (Grade clássica, Lista detalhada, Vitrine com destaque, Minimalista,
  Revista zigue-zague); botão **"+ Produto de afiliado"**: o visitante clica em **"Comprar na {loja} ↗"** e é
  redirecionado (nova aba, `rel="sponsored nofollow"`) para o site parceiro.
- **Painel → Fórum**: botão **habilitar/desabilitar a sessão Fórum**; escolha entre **5 páginas de fórum**
  (Clássico, Cards, Tabela compacta, Quadro por categoria, Feed social); área **Páginas de usuários** para
  personalizar perfis com **5 modelos** (Clássico, Moderno, Minimal, Neon, Revista), **foto de perfil**,
  **foto de capa** (URL ou upload) e bio.
- **Perfil público `/forum/u/:usuario`**: **seguir / deixar de seguir**, abas **Seguidores** e **Seguindo**
  (o dono pode **remover seguidores**), tópicos do usuário e **vídeos** alternando entre **YouTube, Vimeo,
  Dailymotion, X (Twitter), Facebook ou URL personalizada** (com upload de vídeo). No fórum, o visitante
  escolhe **"Participar como"** um perfil (ou cria o seu) e pode personalizar a própria página.

## 🔗 Estrutura de links dos artigos (Painel → SEO)

- O padrão agora é **somente o título**: `/titulo-do-artigo` (a base `/artigo/` foi removida).
- Em **Painel → SEO → Estrutura de links** é possível alternar entre:
  **Somente o título** (`/titulo`), **Categoria / título** (`/tecnologia/titulo`) e
  **Categoria / subcategoria / título** (`/tecnologia/ia/titulo`), com **prefixo opcional** (ex.: `/blog/...`).
  Há uma prévia com artigos reais; prefixos reservados (`/categoria`, `/admin`, `/forum`, `/loja`…) são bloqueados.
- Subcategorias: em **Painel → Categorias**, defina a **categoria-mãe** (ex.: IA é subcategoria de Tecnologia).
  Se a categoria principal não tiver mãe, usa-se a 2ª categoria marcada no artigo.
- Links antigos (`/artigo/slug`) ou de outra estrutura **redirecionam automaticamente** para a URL canônica;
  menus, cards, sitemap e canonical seguem a estrutura escolhida.

## </> Sessão HTML, comentários, visualizações e página principal

- **Painel → HTML**: campos para **código HTML ou texto alternativo** exibidos no **início** e no **final de
  cada artigo** (liga/desliga, prévia ao vivo e variáveis `{{titulo}}`, `{{autor}}`, `{{data}}`,
  `{{categoria}}`, `{{url}}`, `{{site}}`). Também configura e **modera os comentários**
  (permitir, exigir aprovação, aprovar/ocultar/excluir) e o **contador de visualizações** (exibir, ranking, zerar).
- **Comentários**: formulário no final de cada artigo (nome + comentário, com anti-spam invisível).
- **Visualizações**: cada acesso ao artigo soma 1; o total aparece discretamente no cabeçalho (`👁 N visualizações`)
  e na lista de artigos do painel.
- **Painel → SEO → Página principal**: alterna o que aparece em `/` entre **página principal**, **loja virtual**
  ou **fórum** (a home original fica em `/inicio`; se a sessão escolhida estiver desabilitada, usa a home).

## 🌐 Redes Sociais e categorias de podcast

- **Painel → Redes Sociais**: 24 redes com **ícones oficiais** — GitHub, GitLab, Instagram, Telegram,
  WhatsApp Channel, WhatsApp Business, TikTok, Facebook, YouTube, WeChat, Snapchat, Reddit, Douyin,
  X (antigo Twitter), Pinterest, Threads, LinkedIn, Bluesky, Mastodon, VK, Kwai, Discord, Badoo e Twitch TV.
  Cada linha permite colar o link oficial do perfil, **trocar a rede por outra**, reordenar, remover,
  adicionar novas e **habilitar/desabilitar individualmente**; há também o **toggle geral**.
  Os ícones aparecem no **rodapé esquerdo** e abrem em **nova aba** (`target="_blank"`, `rel="noopener noreferrer"`).
  Ícones: paths SVG oficiais do projeto Simple Icons (CC0), gerados estaticamente em `src/data/socialNetworks.js`.
- **Painel → Podcasts → Categorias de podcast**: adicionar e remover categorias **exclusivas de podcast**
  (independentes das categorias do site). A página `/podcasts` agrupa os episódios por elas; cada episódio
  escolhe sua categoria no formulário ou direto na lista; episódios sem categoria ficam em "Outros".

## 🦶 Rodapé (Painel → Rodapé)

- **8 modelos**: Clássico escuro, Centralizado, Minimal (uma linha), Mega colunas, Clássico claro,
  Cartão flutuante, Dividido e Foco nas redes — com miniaturas e **prévia ao vivo**.
- **O que colocar/retirar**: logo e nome, descrição, **ícones das redes sociais**, menus do rodapé,
  menu inferior, direitos autorais, botão discreto “Acesso” e botão voltar ao topo.
- **Direitos autorais** editáveis (variáveis `{{ano}}` e `{{site}}`) e **menu inferior** editável
  (adicionar, remover, reordenar; links externos abrem em nova aba; links de sessões desabilitadas somem sozinhos).

## 🔗 Compartilhamento e layout de artigo

- **Compartilhamento social** no **início e no final de cada artigo**, com ícones oficiais: Facebook,
  X (antigo Twitter), Mastodon, Bluesky, Telegram, WhatsApp, Reddit, Pinterest, Tumblr e **copiar link**
  (área de transferência, com fallback). Os links abrem em nova aba; pode ser desligado em Painel → HTML.
- **Painel → HTML → Layout do artigo**: sem sidebar, sidebar à esquerda, sidebar à direita, duas sidebars
  à esquerda ou duas à direita. Sidebar 1: mais lidos + categorias; sidebar 2: últimos artigos + redes
  sociais. No celular as sidebars ficam abaixo do conteúdo.

## 💬 Comentários (Painel → Comentários)

- No final de cada artigo, o leitor comenta com **nome, e-mail e comentário** (todos obrigatórios;
  e-mail validado e **nunca exibido publicamente**; anti-spam invisível).
- Por padrão todo comentário entra como **pendente**. Na sessão **Comentários** você **aprova** (vai para o site),
  **reprova** (não aparece) ou exclui; há filtros (pendentes/aprovados/reprovados/todos), filtro por artigo,
  busca por nome/e-mail/texto, "aprovar todos os pendentes" e o contador de pendentes no menu do painel.
- Configurações na mesma sessão: permitir comentários e exigir aprovação.

## 🌍 Tradução (Painel → Tradução)

- Idiomas: **português do Brasil, inglês, espanhol, italiano e francês** — cada um com botão
  **habilitar/desabilitar**, escolha do **idioma padrão** e um toggle geral da tradução.
- **Seletor de idiomas no menu superior**, à parte do menu principal (bandeira + sigla); mostra só os habilitados
  e lembra a escolha do visitante.
- **O blog inteiro é traduzido**: toda a interface pública (menus, home, categorias, artigos, compartilhamento,
  comentários, sidebars, podcasts, loja, fórum, perfis, rodapé, 404, manutenção), além de datas e preços no
  formato do idioma, título da aba e `<html lang>`. Como funciona:
  1. **Dicionário revisado** (`src/data/i18nDict.js`) com a interface e o conteúdo de exemplo (categorias,
     menus, títulos e resumos de artigos, produtos, fórum, podcasts) — aplicado por um tradutor de DOM
     (`src/i18n.js`) que acompanha as mudanças da página.
  2. **Traduções manuais** do conteúdo cadastrado, editáveis na sessão (com preenchimento automático opcional).
  3. **Tradução automática** opcional (API gratuita MyMemory, com cache no navegador) para conteúdo sem
     tradução revisada — por exemplo, o corpo dos artigos e posts do fórum. Requer internet e tem limite diário.
- O login e o painel administrativo continuam em português.

## 💾 Backup e 🔏 Políticas de privacidade (Painel → Segurança)

- **Backup manual**: baixar arquivo `.json` com todo o site, salvar cópia no navegador (IndexedDB),
  enviar para o **Google Drive** e **restaurar** de arquivo ou de uma cópia local.
- **Backup automático pré-programado**: a cada 1h/6h/12h, diário ou semanal, para cópia local e/ou Google Drive,
  mantendo as últimas N cópias; histórico com sucesso/falha. Como não há servidor, o agendamento roda no
  navegador enquanto o administrador estiver logado (o backup atrasado é feito ao abrir o painel).
- **Google Drive**: login oficial do Google (Google Identity Services, escopo `drive.file` — o site só acessa os
  arquivos que ele mesmo cria) e upload pela Drive API v3. Requer um **Client ID OAuth** próprio (passo a passo
  na tela). O acesso do Google dura ~1h; o automático tenta renovar sem janela e, se não conseguir, registra
  “reconecte” no histórico.
- **Políticas de privacidade**: campo único para colar o link da página. Com o link definido, ao entrar no site
  (login) o usuário vê uma janela obrigatória com o link e precisa marcar “Li e aceito” → **Aceitar e continuar**
  (ou **Recusar e sair**). O aceite fica registrado por usuário e é pedido de novo se o link mudar.

## 🗂️ Ações em massa nos artigos (Painel → Artigos)

- Caixa de seleção em cada artigo + “Selecionar todos” (respeita os filtros); ações **Mover para rascunho**
  e **Excluir selecionados** (com confirmação), com contador de selecionados.

## ✉️ SMTP (Painel → Segurança → SMTP)

- Configuração **manual**: servidor (host), porta, criptografia (STARTTLS 587 / SSL 465 / nenhuma), usuário,
  senha (ou senha de app), nome e e-mail do remetente, “responder para”, e-mail do administrador para avisos;
  atalhos para Gmail, Outlook, Zoho, Hostinger e SendGrid. Campo de **envio de e-mail de teste** e registro de envios.
- Uso no site: **redefinição de senha** (o link vai por e-mail e não aparece mais na tela), **boas-vindas** a quem
  cria conta e **aviso ao administrador** sobre novas contas. Respostas dos usuários chegam no “responder para”.
- **Servidor de envio (relay)**: navegadores não falam SMTP, então o projeto inclui `smtp-relay/` — Node.js puro,
  **sem dependências** — que recebe o e-mail do site e entrega ao seu provedor:
  ```bash
  RELAY_KEY=uma-chave-secreta ALLOWED_ORIGIN=https://seusite.com PORT=3001 node smtp-relay/server.js
  ```
  Hospede-o em qualquer serviço Node (VPS, Render, Railway…) com HTTPS e informe a URL (`https://…/send`)
  e a mesma chave no painel. Rotas: `POST /send`, `GET /health`. Limite de 30 envios/min por IP.
- Observação: a senha SMTP fica salva no navegador do administrador e só é enviada ao seu servidor de envio.
  Para **receber** e-mails, use a caixa do “responder para” / administrador (SMTP serve apenas para envio).

## 🛍️ Shop e lista de desejos (perfil do fórum + loja)

- Nos produtos da loja (todos os 5 layouts) há um **coração vermelho discreto**: com um perfil escolhido em
  “Participar como” no fórum, clicar adiciona o produto à lista de desejos (preenchido) e clicar de novo remove.
  Sem perfil, um aviso leva ao fórum.
- Na página do usuário (`/forum/u/:usuario`) há a área **Shop** com o sub menu **Lista de desejos**: produtos com
  imagem, preço, botão de compra (afiliado abre o site parceiro; próprio leva à loja) e “Remover” para o dono do perfil.
  No painel (Fórum → Páginas de usuários) aparece quantos itens cada perfil tem na lista.
- O login agora fica em **`/login`** (o antigo `/pica-pau` redireciona automaticamente).

## 🖌️ Tema da página inicial (Painel → Tema)

- **10 modelos de Revista Digital**: Manchete, Grade clássica, Mosaico, Edição noturna, Minimalista, Carrossel,
  Jornal, Tech, Lifestyle e Portal (com barra lateral) — além da página **Original**. Cada modelo tem seu próprio
  estilo de capa (manchete dividida, tela cheia, mosaico, carrossel, lista numerada ou cabeçalho de jornal),
  de cards, cores e tipografia.
- **Blocos**: destaque principal, postagens em destaque, categorias em destaque, últimas postagens, seções por
  categoria, mais lidos, vídeos, podcasts e áudios, vitrine da loja e do fórum — cada um pode ser
  **adicionado/retirado** e **reordenado**.
- **Categorias e postagens em destaque** escolhidas no painel (com ordem); sem escolha, usa todas as categorias e as
  postagens mais recentes. Prévia ao vivo em miniatura; tudo é salvo na hora.

## 👤 Perfil Editor e confirmação de e-mail

- Contas criadas pelo cadastro público (`/login/registrar`) entram automaticamente como **Editor**.
- **Editores não acessam o back-end**: ao entrar, vão para o site (front-end); `/admin` retorna 404 para eles.
  No cabeçalho do site aparece o usuário logado com **👤 Meu perfil** (vai para a página do usuário dentro do site,
  `/forum/u/:usuario`, criada automaticamente no primeiro acesso), **⚙️ Painel** (somente administradores) e **Sair**
  — também no menu do celular.
  A janela de aceite das políticas de privacidade também aparece no site.
- **Confirmação de e-mail**: ao criar a conta, o usuário recebe um e-mail com link (`/login/confirmar/:token`,
  válido por 48h) e **só consegue entrar depois de confirmar**. No login há “Reenviar e-mail de confirmação”.
  Sem SMTP configurado, o link aparece na tela (modo demonstração).
- Em Segurança → Usuários cadastrados: selo de e-mail confirmado/não confirmado, **Confirmar e-mail** manualmente
  e **Reenviar confirmação**. Contas criadas pelo administrador já entram confirmadas.

## 📡 Feed e mídias do perfil

- Na página de perfil, o campo **Vídeos** aceita YouTube, Vimeo, Dailymotion, X e Facebook (a opção “URL personalizada” foi retirada).
- Novos campos **Imagens** e **Áudios** no perfil: o dono envia arquivos de **até 15 MB cada** (com validação de tipo e
  tamanho), com título; imagens abrem ampliadas e áudios têm player. Os arquivos ficam no **IndexedDB** do navegador
  (o LocalStorage não comporta arquivos desse tamanho); por isso não entram no backup `.json`.
- Nova página **Feed** (`/feed`): link no rodapé ao lado de “Acesso” e no botão **Explorar** do cabeçalho. Sub menus
  **Imagens**, **Vídeos** e **Áudios** (`/feed/imagens`, `/feed/videos`, `/feed/audios`) reúnem o que os usuários
  publicaram, com o autor de cada item.
- **3 layouts por tipo, escolhidos pelo leitor** (a escolha fica salva no navegador): Imagens — Grade, Mosaico e Galeria;
  Vídeos — Grade, Lista e Cinema (player grande + fila); Áudios — Lista, Cartões e Playlist (player único que avança sozinho).

## 🏠 Página pública

- Home com hero, **grade de 15 categorias** e últimos artigos (sem a antiga seção “Sobre este portal”). Home com **grade de 15 categorias** (cards com ícone, nome, descrição e nº de artigos),
  responsiva (mobile/tablet/desktop).
- **Botão de tema claro/escuro** no cabeçalho da página principal (☀️/🌙) — a escolha fica
  salva no LocalStorage e é aplicada via classe `.dark` no `<html>` (Tailwind em modo classe).
- Páginas de categoria (`/categoria/:slug`) e de artigo (URL conforme a estrutura de links do SEO).
- Header com **menu principal + mega menu** (gerenciados no painel) e rodapé com menus
  secundários + botão discreto "Acesso".
- Modo manutenção opcional (Painel → Segurança).

## 🛠️ Painel administrativo (`/admin`)

| Seção | O que faz |
|-------|-----------|
| **Painel** | Estatísticas (artigos por tipo/status, categorias, menus) e acesso rápido. |
| **Artigos** | Lista com busca e filtros por **tipo (imagem/vídeo/áudio), categoria e status**; ações de **editar, duplicar e excluir**. |
| **Artigos → Novo/Editar** | Seletor de **tipo de artigo** (🖼️ imagem / 🎬 vídeo / 🎧 áudio) + **5 modelos de layout por tipo** com **preview em tempo real**; editor rico (negrito, itálico, listas, links, imagens, títulos); campos de mídia por tipo (imagem/alt/legenda/galeria, vídeo YouTube/Vimeo/arquivo + pôster + transcrição, áudio MP3 + capa + timestamps); **SEO por artigo** com prévia no Google; **categoria obrigatória (múltiplas)**; status rascunho/publicado/agendado. |
| **Categorias** | Criar, editar (nome, slug, ícone, cor, descrição, SEO), **reordenar por arrastar e soltar** e excluir. |
| **Menus** | Criar menus para **header/footer**, definir o **menu principal**, itens simples com até **3 níveis**, **mega menu com colunas** (links com descrição e imagem/banner), **arrastar e soltar** para reordenar e **preview antes de salvar**. |
| **SEO** | Título, meta description, palavras-chave, Open Graph, Twitter Cards, URL canônica base, favicon, meta robots, edição de **robots.txt** e **sitemap.xml gerado dinamicamente** (com download). |
| **Segurança** | Trocar senha do admin, tempo de expiração da sessão, ativar/desativar **rate limit** e **bloqueio por tentativas**, **modo manutenção**, logs de acesso eencerrar sessão. |

### Modelos de layout disponíveis

- **Imagem:** topo · lateral · galeria · tela cheia com overlay · imagem entre blocos de texto
- **Vídeo:** topo · lateral · full-width · com playlist de relacionados · com transcrição
- **Áudio:** player no topo · player fixo (sticky) · com capa e descrição · playlist de episódios · com timestamps clicáveis

## 💾 Persistência (sem banco de dados)

Todo o estado (SEO, categorias, artigos, menus e segurança) fica em
`localStorage` na chave `picapau_cms_state_v1`. **Nenhum dado se perde ao recarregar.**
Na primeira execução, o app semeia **15 categorias** e **9 artigos demo** (3 de imagem,
3 de vídeo e 3 de áudio, com modelos diferentes). Para resetar tudo, limpe o LocalStorage
do navegador (ou use o console: `localStorage.clear()` e recarregue).

## 📁 Estrutura de pastas

```
├── index.html                  # entrada (aponta para src/main.jsx)
├── vite.config.js              # config em JS puro (React + Tailwind v4 + singlefile)
├── public/
│   ├── robots.txt              # bloqueia /login e /admin
│   ├── sitemap.xml             # sitemap estático inicial
│   ├── favicon.svg
│   └── pica-pau/index.html     # fallback que garante a rota /login
├── src/
│   ├── main.jsx                # bootstrap React
│   ├── App.jsx                 # rotas, guardas, SEO dinâmico, inatividade
│   ├── router.js               # mini roteador (path + hash)
│   ├── store.js                # persistência LocalStorage + hook useCmsState
│   ├── auth.js                 # SHA-256, sessão, rate limit, logs
│   ├── seo.js                  # aplica SEO no <head> + gera sitemap
│   ├── utils.js                # utilitários (slug, datas, embed de vídeo…)
│   ├── data/seed.js            # dados de exemplo (15 categorias, 9 artigos, menus)
│   ├── components/             # Layout (header/mega menu/footer), Modal, RichEditor, SeoFields, MediaFields, TemplatePicker
│   ├── templates/ArticleView.jsx  # os 15 modelos de artigo (preview = página pública)
│   ├── pages/                  # Home, CategoryPage, ArticlePage, Login, NotFound, Maintenance
│   └── admin/                  # painel: Dashboard, ArticlesList, ArticleEditor, CategoriesAdmin, SeoAdmin, SecurityAdmin, MenusAdmin
```

## ✅ Observações técnicas

- **Zero arquivos TypeScript** (`tsc`/`tsconfig` foram removidos; só existem `.js`/`.jsx`).
- Sem banco de dados e sem backend: toda "validação de back-end" acontece na camada
  `auth.js`/`store.js` (hash de senha, sessão, rate limit, logs).
- Acessível: ARIA nos menus/modais, navegação por teclado, contraste e link "pular para o conteúdo".
- Responsivo com Tailwind (breakpoints mobile → desktop).
